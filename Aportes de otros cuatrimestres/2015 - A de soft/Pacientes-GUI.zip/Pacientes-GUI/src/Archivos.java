
public class Archivos {

	
	public  String datospac(){
				
		return "/home/pablo/workspace/datopac.txt";
	}
	
	
	public String datosmed(){
		
		return "/home/pablo/workspace/datomed.txt";
	}
	
	
	public String situpac(){
		
		return "/home/pablo/workspace/situpac.txt";
	}
	
}
