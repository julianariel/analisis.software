import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class IngresoDatos extends JFrame  {
	public IngresoDatos() {
		setTitle("Ingreso Datos");
		getContentPane().setLayout(null);
		this.setBounds(380, 200, 400, 300);
		
		JButton btnDatosPaciente = new JButton("Datos Paciente");
		btnDatosPaciente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DatosPaciente datopac = new DatosPaciente();
				
				datopac.show();
				
			}
		});
		btnDatosPaciente.setBounds(156, 32, 142, 25);
		getContentPane().add(btnDatosPaciente);
		
		JButton btnSituacinDelPaciente = new JButton("Situación del Paciente");
		btnSituacinDelPaciente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			SituacionPaciente situpac = new SituacionPaciente();
			
			situpac.show();
			}
		});
		btnSituacinDelPaciente.setBounds(156, 70, 142, 25);
		getContentPane().add(btnSituacinDelPaciente);
		
		JButton btnDatosDelMdico = new JButton("Datos del médico");
		btnDatosDelMdico.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DatosMedico datmed = new DatosMedico();
				
				datmed.show();
				
			}
		});
		btnDatosDelMdico.setBounds(156, 104, 142, 25);
		getContentPane().add(btnDatosDelMdico);
		
		JButton btnNewButton = new JButton("Salir");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			  
				dispose();
			
			}
		});
		btnNewButton.setBounds(156, 137, 142, 25);
		getContentPane().add(btnNewButton);
	}

	/*public static void main(String[] args){
		IngresoDatos ingredat = new IngresoDatos();
		ingredat.show();
	
}*/

}
