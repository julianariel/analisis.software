

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


public class DatosPaciente extends JFrame {
	private JTextField codPaciente;
	private JTextField nombPaciente;
	private JTextField apePaciente;
	public DatosPaciente() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setTitle("Datos Paciente");
		getContentPane().setLayout(null);
		this.setBounds(380, 200, 400, 300);
		codPaciente = new JTextField();
		codPaciente.setBounds(211, 42, 114, 19);
		getContentPane().add(codPaciente);
		codPaciente.setColumns(10);
		
		nombPaciente = new JTextField();
		nombPaciente.setBounds(211, 100, 114, 19);
		getContentPane().add(nombPaciente);
		nombPaciente.setColumns(10);
		
		JButton btnRegistrarPaciente = new JButton("Registrar Paciente");
		btnRegistrarPaciente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String codPac = new String();
				String nomPac = new String();
				String apePac = new String();
				int error=0;
				BufferedWriter fichero = null;
		        PrintWriter pw = null;
		        String regex = "^[a-zA-Z]+$";
				Archivos arch = new Archivos();
				
			     try {
			    	 
			    	 fichero=new BufferedWriter(new FileWriter(arch.datospac(), true));
			    	 pw = new PrintWriter(fichero);
			     
					
				
			       codPac=codPaciente.getText();    
			       
			       try{
			       Integer.parseInt(codPac);
			       }catch(Exception e){
			    	   
			    	   error=1;
			       }
			       if(error== 1 || Integer.parseInt(codPac) < 1 || Integer.parseInt(codPac) > 10000){
			    	   
			    	   JOptionPane.showMessageDialog(null,"El código ingresado no es válido"); 
			    	
			    	   codPaciente.setText("");
			    	   nombPaciente.setText("");
				       apePaciente.setText("");
				       error=0;
			       }
			       else{
			       
			       nomPac=nombPaciente.getText();
			       
			       apePac= apePaciente.getText();
			       
			       if (nomPac.matches(regex)==false || apePac.matches(regex)==false || nomPac.equals("") || apePac.equals("")) { 
			       
			    	   JOptionPane.showMessageDialog(null,"Nombre y/o Apellido inválido"); 
				    	
			    	   codPaciente.setText("");
			    	   nombPaciente.setText("");
				       apePaciente.setText("");
			       
			       }
			       
			       else{
			       
			       pw.println(codPac+" "+nomPac+" "+apePac);
			       
			       JOptionPane.showMessageDialog(null,"Se han registrado los datos correctamente");
			       
			    	
		    	   codPaciente.setText("");
		    	   nombPaciente.setText("");
			       apePaciente.setText("");
			       }
			       
			       }
			       
			     } catch (Exception e) {
			            e.printStackTrace();
			        } finally {
			           try {
			          
			           if (null != fichero)
			              fichero.close();
			           } catch (Exception e2) {
			              e2.printStackTrace();
			           }
			        }
				
				
			     	
			}
			
			
			
			
		});
		btnRegistrarPaciente.setBounds(89, 212, 155, 25);
		getContentPane().add(btnRegistrarPaciente);
		
		JLabel lblIngrese = new JLabel("Código de paciente");
		lblIngrese.setBounds(22, 44, 171, 15);
		getContentPane().add(lblIngrese);
		
		JLabel lblIngreseNombreDe = new JLabel("Nombre de paciente");
		lblIngreseNombreDe.setBounds(22, 102, 163, 15);
		getContentPane().add(lblIngreseNombreDe);
		
		apePaciente = new JTextField();
		apePaciente.setBounds(221, 141, 114, 19);
		getContentPane().add(apePaciente);
		apePaciente.setColumns(10);
		
		JLabel lblApellidoDePaciente = new JLabel("Apellido de paciente");
		lblApellidoDePaciente.setBounds(32, 129, 70, 15);
		getContentPane().add(lblApellidoDePaciente);
		
		JButton btnSalir = new JButton("Salir");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
			dispose();
			}
		});
		btnSalir.setBounds(278, 201, 117, 25);
		getContentPane().add(btnSalir);
	}
	

}



