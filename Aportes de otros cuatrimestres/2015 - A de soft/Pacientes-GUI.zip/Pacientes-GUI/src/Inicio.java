
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;




public class Inicio extends JFrame  {
	

	 
	
	public Inicio() {
		setTitle("Centro Médico");
		
		this.setBounds(380, 300, 400, 300);
		getContentPane().setLayout(null);
		
		JButton btnIngDatos = new JButton("Ingreso de Datos");
		btnIngDatos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				IngresoDatos ingdato = new IngresoDatos();
				
				ingdato.show();
				
			}
		});
		btnIngDatos.setBounds(156, 32, 142, 25);
		getContentPane().add(btnIngDatos);
		
		JButton btnInformes = new JButton("Informes");
		btnInformes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			Informes informes = new Informes();
			
			informes.show();
			}
		});
		btnInformes.setBounds(156, 70, 142, 25);
		getContentPane().add(btnInformes);
		
		JButton btnNewButton = new JButton("Salir");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			  
				dispose();
			
			}
		});
		btnNewButton.setBounds(156, 137, 142, 25);
		getContentPane().add(btnNewButton);
	}

	public static void main(String[] args){
		Inicio ingredat = new Inicio();
		ingredat.show();
	
}

}

