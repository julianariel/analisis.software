

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


public class DatosMedico extends JFrame {
	private JTextField codMedico;
	private JTextField nombMedico;
	private JTextField apeMedico;
	private JTextField especialidad;
	public DatosMedico() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setTitle("Datos Médico");
		getContentPane().setLayout(null);
		this.setBounds(380, 200, 400, 300);
		codMedico = new JTextField();
		codMedico.setBounds(211, 42, 114, 19);
		getContentPane().add(codMedico);
		codMedico.setColumns(10);
		
		nombMedico = new JTextField();
		nombMedico.setBounds(211, 100, 114, 19);
		getContentPane().add(nombMedico);
		nombMedico.setColumns(10);
		
		JButton btnRegistrarMedico = new JButton("Registrar Médico");
		btnRegistrarMedico.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String codMed = new String();
				String nomMed = new String();
				String apeMed = new String();
				String espec = new String();
				int error=0;
				BufferedWriter fichero = null;
		        PrintWriter pw = null;
		        String regex = "^[a-zA-Z]+$";
		        Archivos arch = new Archivos();
				
			     try {
			    	 
			    	 fichero=new BufferedWriter(new FileWriter(arch.datosmed(), true));
			    	 pw = new PrintWriter(fichero);
			     
					
				
			       codMed=codMedico.getText();    
			       
			       try{
			       Integer.parseInt(codMed);
			       }catch(Exception e){
			    	   
			    	   error=1;
			       }
			       if(error== 1 || Integer.parseInt(codMed) < 1 || Integer.parseInt(codMed) > 10000){
			    	   
			    	   JOptionPane.showMessageDialog(null,"El código ingresado no es válido"); 
			    	
			    	   codMedico.setText("");
			    	   nombMedico.setText("");
				       apeMedico.setText("");
				       especialidad.setText("");
				       error=0;
			       }
			       else{
			       
			       nomMed=nombMedico.getText();
			       
			       apeMed= apeMedico.getText();
			       
			       if (nomMed.matches(regex)==false || apeMed.matches(regex)==false || nomMed.equals("") || apeMed.equals("")) { 
			       
			    	   JOptionPane.showMessageDialog(null,"Nombre y/o Apellido inválido"); 
				    	
			    	   codMedico.setText("");
			    	   nombMedico.setText("");
				       apeMedico.setText("");
				       especialidad.setText("");
			       }
			       
			       else{
			       
			    	   
			    	   espec= especialidad.getText();
				       
				       if (espec.matches(regex)==false || espec.equals("")) { 
				       
				    	   JOptionPane.showMessageDialog(null,"Especialidad inválida"); 
					    	
				    	   codMedico.setText("");
				    	   nombMedico.setText("");
					       apeMedico.setText("");
					       especialidad.setText("");
				       }
				       else {
			       pw.println(codMed+" "+nomMed+" "+apeMed+" "+espec);
			       
			       JOptionPane.showMessageDialog(null,"Se han registrado los datos correctamente");
			       
			    	
		    	   codMedico.setText("");
		    	   nombMedico.setText("");
			       apeMedico.setText("");
			       especialidad.setText("");
				       }
				       }
			       
			       }
			       
			     } catch (Exception e) {
			            e.printStackTrace();
			        } finally {
			           try {
			          
			           if (null != fichero)
			              fichero.close();
			           } catch (Exception e2) {
			              e2.printStackTrace();
			           }
			        }
				
				
			     	
			}
			
			
			
			
		});
		btnRegistrarMedico.setBounds(89, 212, 155, 25);
		getContentPane().add(btnRegistrarMedico);
		
		JLabel lblIngrese = new JLabel("Código de médico");
		lblIngrese.setBounds(22, 44, 171, 15);
		getContentPane().add(lblIngrese);
		
		JLabel lblIngreseNombreDe = new JLabel("Nombre de médico");
		lblIngreseNombreDe.setBounds(22, 102, 163, 15);
		getContentPane().add(lblIngreseNombreDe);
		
		apeMedico = new JTextField();
		apeMedico.setBounds(221, 141, 114, 19);
		getContentPane().add(apeMedico);
		apeMedico.setColumns(10);
		
		JLabel lblApellidoDePaciente = new JLabel("Apellido de médico");
		lblApellidoDePaciente.setBounds(32, 129, 70, 15);
		getContentPane().add(lblApellidoDePaciente);
		
		JButton btnSalir = new JButton("Salir");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
			dispose();
			}
		});
		btnSalir.setBounds(278, 201, 117, 25);
		getContentPane().add(btnSalir);
		
		especialidad = new JTextField();
		especialidad.setBounds(211, 159, 114, 19);
		getContentPane().add(especialidad);
		especialidad.setColumns(10);
		
		JLabel lblEspecialidad = new JLabel("Especialidad");
		lblEspecialidad.setBounds(42, 161, 70, 15);
		getContentPane().add(lblEspecialidad);
	}
	

}




