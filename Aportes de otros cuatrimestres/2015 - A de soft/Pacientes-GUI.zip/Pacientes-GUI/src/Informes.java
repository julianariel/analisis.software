import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Informes extends JFrame  {
	public Informes() {
		setTitle("Informes");
		getContentPane().setLayout(null);
		this.setBounds(380, 200, 400, 300);
		JButton btnPacMed = new JButton("Listado Pacientes por médico");
		btnPacMed.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ListadoPacMed pacmed = new ListadoPacMed();
				
				pacmed.show();
				
			}
		});
		btnPacMed.setBounds(156, 32, 142, 25);
		getContentPane().add(btnPacMed);
		
		JButton btnEnfMedico = new JButton("Listado enfermedades atendidas por médico");
		btnEnfMedico.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			ListadoEnfMedico enfmed = new ListadoEnfMedico();
			
			enfmed.show();
			}
		});
		btnEnfMedico.setBounds(156, 70, 142, 25);
		getContentPane().add(btnEnfMedico);
		
		JButton btnNewButton = new JButton("Salir");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			  
				dispose();
			
			}
		});
		btnNewButton.setBounds(156, 137, 142, 25);
		getContentPane().add(btnNewButton);
	}



}
