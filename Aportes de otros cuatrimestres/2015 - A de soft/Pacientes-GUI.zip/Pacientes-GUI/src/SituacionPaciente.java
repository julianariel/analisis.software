

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


public class SituacionPaciente extends JFrame {
	private JTextField codPaciente;
	private JTextField codDoctor;
	private JTextField diagnostico;
	public SituacionPaciente() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setTitle("Situación del Paciente");
		getContentPane().setLayout(null);
		this.setBounds(380, 200, 400, 300);
		
		codPaciente = new JTextField();
		codPaciente.setBounds(211, 42, 114, 19);
		getContentPane().add(codPaciente);
		codPaciente.setColumns(10);
		
		codDoctor = new JTextField();
		codDoctor.setBounds(211, 100, 114, 19);
		getContentPane().add(codDoctor);
		codDoctor.setColumns(10);
		
		JButton btnSituacionPaciente = new JButton("Registrar diagnóstico");
		btnSituacionPaciente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String codPac = new String();
				String codMed = new String();
				String diag = new String();
				int error=0;
				BufferedWriter fichero = null;
		        PrintWriter pw = null;
		        String regex = "^[a-zA-Z]+$";
		        Archivos arch = new Archivos();
				
			     try {
			    	 
			    	 fichero=new BufferedWriter(new FileWriter(arch.situpac(), true));
			    	 pw = new PrintWriter(fichero);
			     
					
				
			       codPac=codPaciente.getText();    
			       
			       try{
			       Integer.parseInt(codPac);
			       }catch(Exception e){
			    	   
			    	   error=1;
			       }
			       if(error== 1 || Integer.parseInt(codPac) < 1 || Integer.parseInt(codPac) > 10000){
			    	   
			    	   JOptionPane.showMessageDialog(null,"El código de paciente ingresado no es válido"); 
			    	
			    	   codPaciente.setText("");
			    	   codDoctor.setText("");
				       diagnostico.setText("");
				       error=0;
			       }
			       else{
			       
			       codMed=codDoctor.getText();
			       
			       
			       try{
				       Integer.parseInt(codMed);
				       }catch(Exception e){
				    	   
				    	   error=1;
				       }
				       if(error== 1 || Integer.parseInt(codMed) < 1 || Integer.parseInt(codMed) > 10000){
				    	   
				    	   JOptionPane.showMessageDialog(null,"El código de Médico ingresado no es válido"); 
				    	
				    	   codPaciente.setText("");
				    	   codDoctor.setText("");
					       diagnostico.setText("");
					       error=0;
				       }
			       
				       else{
			       
			       
			       
			       diag= diagnostico.getText();
			       
			      /* if (diag.matches(regex)==false || diag.equals("")) { 
			       
			    	   JOptionPane.showMessageDialog(null,""); 
				    	
			    	   codPaciente.setText("");
			    	   codDoctor.setText("");
				       diagnostico.setText("");
			       
			       }
			       
			       else{
			       */
			       pw.println(codPac+" "+codMed+" "+diag);
			       
			       JOptionPane.showMessageDialog(null,"Se han registrado los datos correctamente");
			       
			    	
		    	   codPaciente.setText("");
		    	   codDoctor.setText("");
			       diagnostico.setText("");
			       //}
			       
			       }
			       }
			     } catch (Exception e) {
			            e.printStackTrace();
			        } finally {
			           try {
			          
			           if (null != fichero)
			              fichero.close();
			           } catch (Exception e2) {
			              e2.printStackTrace();
			           }
			        }
				
				
			     	
			}
			
			
			
			
		});
		btnSituacionPaciente.setBounds(89, 212, 155, 25);
		getContentPane().add(btnSituacionPaciente);
		
		JLabel lblIngrese = new JLabel("Código de paciente");
		lblIngrese.setBounds(22, 44, 171, 15);
		getContentPane().add(lblIngrese);
		
		JLabel lblIngreseNombreDe = new JLabel("Código del médico ");
		lblIngreseNombreDe.setBounds(22, 102, 163, 15);
		getContentPane().add(lblIngreseNombreDe);
		
		diagnostico = new JTextField();
		diagnostico.setBounds(221, 141, 114, 19);
		getContentPane().add(diagnostico);
		diagnostico.setColumns(10);
		
		JLabel lblApellidoDePaciente = new JLabel("Diagnóstico");
		lblApellidoDePaciente.setBounds(32, 129, 70, 15);
		getContentPane().add(lblApellidoDePaciente);
		
		JButton btnSalir = new JButton("Salir");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
			dispose();
			}
		});
		btnSalir.setBounds(278, 201, 117, 25);
		getContentPane().add(btnSalir);
	}
	

}




