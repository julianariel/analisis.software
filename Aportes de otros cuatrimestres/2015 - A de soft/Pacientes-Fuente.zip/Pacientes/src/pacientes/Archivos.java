package pacientes;

public class Archivos {

	public String datospac() {
		return "datopac.txt";
	}

	public String datosmed() {
		return "datomed.txt";
	}

	public String situpac() {
		return "situpac.txt";
	}
	
	public String login() {
		return "login.txt";
	}
}