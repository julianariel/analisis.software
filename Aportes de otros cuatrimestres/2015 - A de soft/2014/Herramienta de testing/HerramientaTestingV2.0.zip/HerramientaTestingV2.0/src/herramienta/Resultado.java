package herramienta;

/**
 * Pojo que se usa para almacenar los resultados del testeo.
 * 
 * @author Grupo 6
 *
 */
public class Resultado {

	private String cabeceraMetodo;
	private String codigoMetodo;
	private long cantidadLineasCodigo;
	private long cantidadLineasCodigoComentadas;
	private long porcentajeLineasCodigoComentadas;
	private long complejidadCiclomatica;
	private long fanIn;
	private long fanOut;
	private long healsteadLongitud;
	private long healsteadVolumen;
	
	public Resultado(){
		
	}

	public Resultado(String cabeceraMetodo, String codigoMetodo){
		this.cabeceraMetodo = cabeceraMetodo;
		this.codigoMetodo = codigoMetodo;
	}
	
	public String getCabeceraMetodo() {
		return cabeceraMetodo;
	}

	public void setCabeceraMetodo(String cabeceraMetodo) {
		this.cabeceraMetodo = cabeceraMetodo;
	}
	
	public String getCodigoMetodo() {
		return codigoMetodo;
	}

	public void setCodigoMetodo(String codigoMetodo) {
		this.codigoMetodo = codigoMetodo;
	}

	public long getCantidadLineasCodigo() {
		return cantidadLineasCodigo;
	}
	public void setCantidadLineasCodigo(long cantidadLineasCodigo) {
		this.cantidadLineasCodigo = cantidadLineasCodigo;
	}
	public long getCantidadLineasCodigoComentadas() {
		return cantidadLineasCodigoComentadas;
	}
	public void setCantidadLineasCodigoComentadas(
			long cantidadLineasCodigoComentadas) {
		this.cantidadLineasCodigoComentadas = cantidadLineasCodigoComentadas;
	}
	public long getPorcentajeLineasCodigoComentadas() {
		return porcentajeLineasCodigoComentadas;
	}
	public void setPorcentajeLineasCodigoComentadas(
			long porcentajeLineasCodigoComentadas) {
		this.porcentajeLineasCodigoComentadas = porcentajeLineasCodigoComentadas;
	}
	public long getComplejidadCiclomatica() {
		return complejidadCiclomatica;
	}
	public void setComplejidadCiclomatica(long complejidadCiclomatica) {
		this.complejidadCiclomatica = complejidadCiclomatica;
	}
	public long getFanIn() {
		return fanIn;
	}

	public void setFanIn(long fanIn) {
		this.fanIn = fanIn;
	}
	public long getFanOut() {
		return fanOut;
	}
	public void setFanOut(long fanOut) {
		this.fanOut = fanOut;
	}
	public long getHealsteadLongitud() {
		return healsteadLongitud;
	}
	public void setHealsteadLongitud(long healsteadLongitud) {
		this.healsteadLongitud = healsteadLongitud;
	}
	public long getHealsteadVolumen() {
		return healsteadVolumen;
	}
	public void setHealsteadVolumen(long healsteadVolumen) {
		this.healsteadVolumen = healsteadVolumen;
	}

	@Override
	public String toString() {
		return cabeceraMetodo;
	}
}
