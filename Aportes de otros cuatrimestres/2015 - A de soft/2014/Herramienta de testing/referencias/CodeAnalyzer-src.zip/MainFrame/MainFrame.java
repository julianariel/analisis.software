package MainFrame;

import AboutDialog.AboutDlg;
import CodeAnalysis.Comment;
import CodeAnalysis.CommentSet;
import CodeAnalysis.Extension;
import CodeAnalysis.ExtensionSet;
import CodeAnalysis.FileProcessor;
import CodeAnalysis.FolderProcessor;
import CodeAnalysis.Stats;
import CodeSetTreeModel.CodeSetTreeCellRenderer;
import CodeSetTreeModel.CodeSetTreeModel;
import CodeSetTreeModel.CodeSetTreeTraversal;
import CodeSetTreeModel.FileNode;
import HelpDisplay.HelpHTML;
import JavaUtils.HashFileFilter;
import JavaUtils.SwingWorker;
import JavaUtils.VectorListModel;
import ResultsDisplay.AnalyzerResults;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URL;
import java.util.Date;
import java.util.Properties;
import java.util.Vector;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.tree.TreePath;

public class MainFrame
  extends JFrame
  implements CodeSetTreeTraversal
{
  private static MainFrame mainFrame;
  private ImageIcon mainIcon = createImageIcon("/images/main-icon.png");
  private Vector lastCodeSets = new Vector();
  private Vector commentSets = new Vector();
  private Vector extensionSets = new Vector();
  private Vector exclusions;
  ExtensionSet extensionSet = null;
  private int lastDefaultCommentIndex;
  private int lastDefaultExtensionIndex;
  private FileNode rootNode;
  private CodeSetTreeModel treeModel;
  private boolean codeSetChanged;
  private int progressBarFileCount;
  private boolean analyzeRunState = false;
  private TreePath analyzeTreePath;
  final String CODEANALYZER_DIR = ".codeanalyzer";
  final String CODEANALYZER_PROPERTIES = "codeanalyzer.pro";
  final String CODESETS = "lastcodesets";
  final String COMMENT_TYPE_PREFIX = "comtype-";
  final String EXTENSION_TYPE_PREFIX = "exttype-";
  final String ROOT_PATHS = "rootpaths";
  final String EXCLUDE_PATHS = "excludepaths";
  final String EXTENSIONS_TYPE = "extensions";
  final int NODE_STORE_EXCLUSION = 1;
  final int NODE_ANALYZE = 2;
  final int NODE_CLEAR = 3;
  private int nodeExecuteType;
  private String editCommentSetName;
  private VectorListModel editCommentSetModel;
  private String editExtensionSetName;
  private VectorListModel editExtensionSetModel;
  private JLabel ExtensionListLabel;
  private JMenuBar MenuBar;
  private JButton addCommentButton;
  private JButton addExtensionButton;
  private JButton addFromExistingButton;
  private JButton cancelButton;
  private JTree codesetTree;
  private JTextField commCloseDisplay;
  private JLabel commCloseLabel;
  private JCheckBox commEOLCheckBox;
  private JLabel commEOLLabel;
  private JTextField commOpenDisplay;
  private JLabel commOpenLabel;
  private JButton commSetCancelButton;
  private JComboBox commSetComboBox;
  private JLabel commSetLabel;
  private JTextField commSetNameDisplay;
  private JLabel commSetNameLabel;
  private JButton commSetSaveButton;
  private JList commentList;
  private JMenuItem commentsAddType;
  private JMenu commentsDeleteType;
  private JMenu commentsEditType;
  private JButton delCommentButton;
  private JButton delExtensionButton;
  private JDialog editCommentSetDialog;
  private JDialog editExtensionSetDialog;
  private JScrollPane extListScrollPane;
  private JTextField extSetNameDisplay;
  private JLabel extSetNameLabel;
  private JLabel extensionDefineLabel;
  private JTextField extensionDisplay;
  private JLabel extensionLabel;
  private JList extensionList;
  private JMenuItem extensionsAddType;
  private JMenu extensionsDeleteType;
  private JTextField extensionsDisplay;
  private JMenu extensionsEditType;
  private JLabel extensionsLabel;
  private JMenu extensionsSelectType;
  private JMenu fileMenu;
  private JEditorPane helpEditorPane;
  private JMenu helpMenu;
  private JSeparator jSeparator1;
  private JSeparator jSeparator10;
  private JSeparator jSeparator11;
  private JSeparator jSeparator2;
  private JSeparator jSeparator3;
  private JSeparator jSeparator4;
  private JSeparator jSeparator5;
  private JSeparator jSeparator6;
  private JSeparator jSeparator7;
  private JSeparator jSeparator8;
  private JSeparator jSeparator9;
  private JMenu lastSetsMenu;
  private JMenuItem level1MenuExclude;
  private JMenuItem level1MenuInclude;
  private JMenuItem level1MenuRemove;
  private JMenuItem level1MenuStats;
  private JPopupMenu level1PopupMenu;
  private JMenuItem menuAbout;
  private JMenu menuComments;
  private JMenuItem menuExit;
  private JMenu menuExtensions;
  private JMenuItem menuHelp;
  private JMenuItem menuNewSet;
  private JMenuItem menuOpenSet;
  private JMenuItem menuReportAllCommaDelim;
  private JMenuItem menuReportAllHTML;
  private JMenuItem menuReportAllText;
  private JMenuItem menuReportFile;
  private JMenuItem menuReportSummary;
  private JMenuItem menuRun;
  private JMenuItem menuSaveSet;
  private JMenuItem menuSaveSetAs;
  private JMenuItem menuStop;
  private JMenuItem nodeMenuExclude;
  private JMenuItem nodeMenuInclude;
  private JMenuItem nodeMenuStats;
  private JPopupMenu nodePopupMenu;
  private JProgressBar progressBar;
  private JMenu reportsMenu;
  private JLabel resultsLabel;
  private JTabbedPane resultsPane;
  private JMenuItem rootMenuAddNew;
  private JMenuItem rootMenuRename;
  private JMenuItem rootMenuStats;
  private JPopupMenu rootPopupMenu;
  private JMenu runMenu;
  private JButton saveButton;
  private JDialog statsDialog;
  private JTextArea statsDialogText;
  public JTextField statusDisplay;
  private JMenu toolsMenu;
  private JLabel treeLabel;
  private JScrollPane treePane;
  
  public MainFrame()
  {
    loadProperties();
    setTreeModel();
    initComponents();
    updateLastSetsMenu();
    updateCommentsDeleteMenu();
    updateCommentsEditMenu();
    updateExtensionsDeleteMenu();
    updateExtensionsEditMenu();
    updateExtensionsSelectMenu();
    updateResultsPane(null);
  }
  
  private ImageIcon createImageIcon(String paramString)
  {
    URL localURL = CodeSetTreeCellRenderer.class.getResource(paramString);
    if (localURL != null) {
      return new ImageIcon(localURL);
    }
    System.err.println("Couldn't find file: " + paramString);
    return null;
  }
  
  private void setTreeModel()
  {
    this.rootNode = new FileNode("New", null, null, null);
    this.treeModel = new CodeSetTreeModel(this.rootNode);
    this.codeSetChanged = false;
  }
  
  public void loadLastCodeset()
  {
    if (this.lastCodeSets.size() == 0) {
      return;
    }
    String str = removeExtension((String)this.lastCodeSets.elementAt(0));
    loadCodeSet(str);
  }
  
  private Properties createDefaultProperties()
  {
    Properties localProperties = new Properties();
    localProperties.setProperty("lastcodesets", "");
    CommentSet localCommentSet1 = new CommentSet("Standard C");
    Comment localComment = new Comment("/*", "*/", false);
    localCommentSet1.add(localComment);
    String str1 = "comtype-1";
    String str2 = localCommentSet1.getPropertyValue();
    localProperties.setProperty(str1, str2);
    CommentSet localCommentSet2 = new CommentSet("C++ and Java");
    localComment = new Comment("/*", "*/", false);
    localCommentSet2.add(localComment);
    localComment = new Comment("//", "", true);
    localCommentSet2.add(localComment);
    str1 = "comtype-2";
    str2 = localCommentSet2.getPropertyValue();
    localProperties.setProperty(str1, str2);
    CommentSet localCommentSet3 = new CommentSet("HTML");
    localComment = new Comment("<!--", "-->", false);
    localCommentSet3.add(localComment);
    str1 = "comtype-3";
    str2 = localCommentSet3.getPropertyValue();
    localProperties.setProperty(str1, str2);
    CommentSet localCommentSet4 = new CommentSet("Assembly");
    localComment = new Comment("#", "", true);
    localCommentSet4.add(localComment);
    localComment = new Comment(";", "", true);
    localCommentSet4.add(localComment);
    str1 = "comtype-4";
    str2 = localCommentSet4.getPropertyValue();
    localProperties.setProperty(str1, str2);
    this.lastDefaultCommentIndex = 4;
    ExtensionSet localExtensionSet = new ExtensionSet("Standard C");
    Extension localExtension = new Extension("c", localCommentSet2);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("h", localCommentSet2);
    localExtensionSet.add(localExtension);
    str1 = "exttype-1";
    str2 = localExtensionSet.getPropertyValue();
    localProperties.setProperty(str1, str2);
    localExtensionSet = new ExtensionSet("Visual C++");
    localExtension = new Extension("cpp", localCommentSet2);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("h", localCommentSet2);
    localExtensionSet.add(localExtension);
    str1 = "exttype-2";
    str2 = localExtensionSet.getPropertyValue();
    localProperties.setProperty(str1, str2);
    localExtensionSet = new ExtensionSet("GNU C++");
    localExtension = new Extension("cc", localCommentSet2);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("cpp", localCommentSet2);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("h", localCommentSet2);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("hh", localCommentSet2);
    localExtensionSet.add(localExtension);
    str1 = "exttype-3";
    str2 = localExtensionSet.getPropertyValue();
    localProperties.setProperty(str1, str2);
    localExtensionSet = new ExtensionSet("Java");
    localExtension = new Extension("java", localCommentSet2);
    localExtensionSet.add(localExtension);
    str1 = "exttype-4";
    str2 = localExtensionSet.getPropertyValue();
    localProperties.setProperty(str1, str2);
    localExtensionSet = new ExtensionSet("Assembly");
    localExtension = new Extension("s", localCommentSet4);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("ia", localCommentSet4);
    localExtensionSet.add(localExtension);
    str1 = "exttype-5";
    str2 = localExtensionSet.getPropertyValue();
    localProperties.setProperty(str1, str2);
    localExtensionSet = new ExtensionSet("TI/Intel Assembly");
    localExtension = new Extension("asm", localCommentSet4);
    localExtensionSet.add(localExtension);
    str1 = "exttype-6";
    str2 = localExtensionSet.getPropertyValue();
    localProperties.setProperty(str1, str2);
    localExtensionSet = new ExtensionSet("HTML");
    localExtension = new Extension("htm", localCommentSet3);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("html", localCommentSet3);
    localExtensionSet.add(localExtension);
    str1 = "exttype-7";
    str2 = localExtensionSet.getPropertyValue();
    localProperties.setProperty(str1, str2);
    localExtensionSet = new ExtensionSet("C/C++");
    localExtension = new Extension("c", localCommentSet2);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("cpp", localCommentSet2);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("cc", localCommentSet2);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("h", localCommentSet2);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("hh", localCommentSet2);
    localExtensionSet.add(localExtension);
    str1 = "exttype-8";
    str2 = localExtensionSet.getPropertyValue();
    localProperties.setProperty(str1, str2);
    localExtensionSet = new ExtensionSet("C/C++/Java/Assembly");
    localExtension = new Extension("c", localCommentSet2);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("cpp", localCommentSet2);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("cc", localCommentSet2);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("h", localCommentSet2);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("hh", localCommentSet2);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("java", localCommentSet2);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("s", localCommentSet4);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("ia", localCommentSet4);
    localExtensionSet.add(localExtension);
    localExtension = new Extension("asm", localCommentSet4);
    localExtensionSet.add(localExtension);
    str1 = "exttype-9";
    str2 = localExtensionSet.getPropertyValue();
    localProperties.setProperty(str1, str2);
    this.lastDefaultExtensionIndex = 9;
    return localProperties;
  }
  
  private void loadProperties()
  {
    String str1 = System.getProperty("user.home") + "/" + ".codeanalyzer" + "/" + "codeanalyzer.pro";
    File localFile = new File(System.getProperty("user.home") + "/" + ".codeanalyzer");
    try
    {
      localFile.mkdir();
    }
    catch (SecurityException localSecurityException)
    {
      System.err.println("Could not create: " + localFile.toString());
      return;
    }
    Properties localProperties = new Properties(createDefaultProperties());
    FileInputStream localFileInputStream;
    try
    {
      localFileInputStream = new FileInputStream(str1);
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      System.err.println("File " + str1 + " not found");
      localFileInputStream = null;
    }
    if (localFileInputStream != null) {
      try
      {
        localProperties.load(localFileInputStream);
      }
      catch (IOException localIOException1)
      {
        System.err.println("File " + str1 + " load failed: bad escape chars");
        try
        {
          localFileInputStream.close();
        }
        catch (IOException localIOException2) {}
        return;
      }
    }
    String str2 = localProperties.getProperty("lastcodesets", "NULL");
    if (str2.equals("NULL"))
    {
      if (localFileInputStream != null) {
        try
        {
          localFileInputStream.close();
        }
        catch (IOException localIOException3) {}
      }
      return;
    }
    this.lastCodeSets.clear();
    String[] arrayOfString = str2.split("\\x2C");
    for (int i = 0; i < arrayOfString.length; i++) {
      if (arrayOfString[i].length() != 0) {
        this.lastCodeSets.addElement(arrayOfString[i]);
      }
    }
    this.commentSets = new Vector();
    String str3 = "nyet";
    Object localObject;
    for (int j = 1; !str3.equals("NULL"); j++)
    {
      String str5 = "comtype-" + j;
      str3 = localProperties.getProperty(str5, "NULL");
      if (!str3.equals("NULL"))
      {
        localObject = new CommentSet("temp");
        ((CommentSet)localObject).setPropertyValue(str3);
        this.commentSets.addElement(localObject);
      }
    }
    this.extensionSets = new Vector();
    String str4 = "nyet";
    for (int k = 1; !str4.equals("NULL"); k++)
    {
      localObject = "exttype-" + k;
      str4 = localProperties.getProperty((String)localObject, "NULL");
      if (!str4.equals("NULL"))
      {
        ExtensionSet localExtensionSet = new ExtensionSet("temp");
        localExtensionSet.setPropertyValue(str4, this.commentSets);
        this.extensionSets.addElement(localExtensionSet);
      }
    }
    if (localFileInputStream != null) {
      try
      {
        localFileInputStream.close();
      }
      catch (IOException localIOException4) {}
    }
  }
  
  private void saveProperties()
  {
    String str1 = System.getProperty("user.home") + "/" + ".codeanalyzer";
    File localFile = new File(str1);
    try
    {
      localFile.mkdir();
    }
    catch (SecurityException localSecurityException)
    {
      System.err.println("Directory " + str1 + " access error");
      return;
    }
    str1 = str1 + "/codeanalyzer.pro";
    FileOutputStream localFileOutputStream;
    try
    {
      localFileOutputStream = new FileOutputStream(str1);
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      System.err.println("File " + str1 + " access error");
      return;
    }
    Properties localProperties = new Properties();
    String str2 = "";
    for (int i = 0; i < this.lastCodeSets.size(); i++)
    {
      str2 = str2 + (String)this.lastCodeSets.elementAt(i);
      if (i != this.lastCodeSets.size() - 1) {
        str2 = str2 + ",";
      }
    }
    localProperties.setProperty("lastcodesets", str2);
    Object localObject;
    String str3;
    String str4;
    for (i = 0; i < this.commentSets.size(); i++)
    {
      localObject = (CommentSet)this.commentSets.elementAt(i);
      str3 = "comtype-" + (i + 1);
      str4 = ((CommentSet)localObject).getPropertyValue();
      localProperties.setProperty(str3, str4);
    }
    for (i = 0; i < this.extensionSets.size(); i++)
    {
      localObject = (ExtensionSet)this.extensionSets.elementAt(i);
      str3 = "exttype-" + (i + 1);
      str4 = ((ExtensionSet)localObject).getPropertyValue();
      localProperties.setProperty(str3, str4);
    }
    try
    {
      localProperties.store(localFileOutputStream, "Code Analyzer Properties");
    }
    catch (IOException localIOException1)
    {
      System.err.println("File " + str1 + " store failed");
      try
      {
        localFileOutputStream.close();
      }
      catch (IOException localIOException3) {}
      return;
    }
    try
    {
      localFileOutputStream.close();
    }
    catch (IOException localIOException2) {}
  }
  
  private void loadCodeSet(String paramString)
  {
    final String str = new String(paramString);
    this.statusDisplay.setText("Loading Code Set: " + str + " ...");
    this.progressBar.setMaximum(1000);
    this.progressBar.setValue(0);
    this.progressBar.setStringPainted(false);
    SwingWorker local1 = new SwingWorker()
    {
      public Object construct()
      {
        String str1 = System.getProperty("user.home") + "/" + ".codeanalyzer" + "/" + str + ".set";
        FileInputStream localFileInputStream;
        try
        {
          localFileInputStream = new FileInputStream(str1);
        }
        catch (FileNotFoundException localFileNotFoundException)
        {
          System.err.println("File " + str1 + " not found");
          return null;
        }
        Properties localProperties = new Properties();
        try
        {
          localProperties.load(localFileInputStream);
        }
        catch (IOException localIOException1)
        {
          System.err.println("File " + str1 + " load failed: bad escape chars");
          try
          {
            localFileInputStream.close();
          }
          catch (IOException localIOException2) {}
          return null;
        }
        MainFrame.this.extensionSet = null;
        String str2 = localProperties.getProperty("extensions", "NULL");
        if (str2.equals("NULL"))
        {
          JOptionPane.showMessageDialog(null, "File " + str1 + " load failed: no extension set defined!", "Invalid Code Set", 0);
          try
          {
            localFileInputStream.close();
          }
          catch (IOException localIOException3) {}
          return null;
        }
        for (int i = 0; i < MainFrame.this.extensionSets.size(); i++)
        {
          ExtensionSet localExtensionSet = (ExtensionSet)MainFrame.this.extensionSets.elementAt(i);
          if (localExtensionSet.toString().equals(str2))
          {
            MainFrame.this.extensionSet = new ExtensionSet(localExtensionSet);
            break;
          }
        }
        String str3 = localProperties.getProperty("rootpaths", "NULL");
        if ((str3.equals("NULL")) || (str3.equals("")))
        {
          try
          {
            localFileInputStream.close();
          }
          catch (IOException localIOException4) {}
          return null;
        }
        MainFrame.this.analyzeRunState = true;
        MainFrame.this.rootNode = new FileNode(str, str3.split("\\x2c"), MainFrame.this.extensionSet, MainFrame.this.progressBar);
        MainFrame.this.treeModel = new CodeSetTreeModel(MainFrame.this.rootNode);
        MainFrame.this.codesetTree.setModel(MainFrame.this.treeModel);
        TreePath localTreePath = new TreePath(MainFrame.this.rootNode);
        MainFrame.this.codeSetChanged = false;
        MainFrame.this.treeModel.fireTreeStructureChanged(localTreePath);
        str3 = localProperties.getProperty("excludepaths", "NULL");
        if ((!str3.equals("NULL")) && (!str3.equals("")))
        {
          String[] arrayOfString = str3.split("\\x2c");
          for (int j = 0; j < arrayOfString.length; j++)
          {
            FileNode localFileNode = (FileNode)MainFrame.this.treeModel.getChildNode(arrayOfString[j]);
            if (localFileNode != null) {
              MainFrame.this.treeModel.nodeExclude(localFileNode);
            }
          }
          MainFrame.this.treeModel.fireTreeStructureChanged(localTreePath);
        }
        try
        {
          localFileInputStream.close();
        }
        catch (IOException localIOException5) {}
        return MainFrame.mainFrame;
      }
      
      public void finished()
      {
        MainFrame.this.analyzeRunState = false;
        MainFrame.this.progressBar.setValue(MainFrame.this.progressBar.getMaximum());
        MainFrame.this.statusDisplay.setText("Loading Code Set: " + str + " ... done.");
        MainFrame.this.extensionsDisplay.setText(MainFrame.this.extensionSet.toString() + "   " + MainFrame.this.extensionSet.showContents());
        MainFrame.this.updateCodeSetList(str + ".set");
        MainFrame.this.updateResultsPane(MainFrame.this.rootNode);
      }
    };
    local1.start();
  }
  
  private void saveCodeSet()
  {
    String str1 = System.getProperty("user.home") + "/" + ".codeanalyzer";
    File localFile = new File(str1);
    try
    {
      localFile.mkdir();
    }
    catch (SecurityException localSecurityException)
    {
      System.err.println("Directory " + str1 + " access error");
      return;
    }
    str1 = str1 + "/" + this.rootNode.toString() + ".set";
    FileOutputStream localFileOutputStream;
    try
    {
      localFileOutputStream = new FileOutputStream(str1);
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      System.err.println("File " + str1 + " open error");
      return;
    }
    Properties localProperties = new Properties();
    String str2 = "";
    String[] arrayOfString = this.rootNode.list();
    if (arrayOfString == null) {
      arrayOfString = new String[0];
    }
    for (int i = 0; i < arrayOfString.length; i++)
    {
      str2 = str2 + arrayOfString[i];
      if (i < arrayOfString.length - 1) {
        str2 = str2 + ",";
      }
    }
    localProperties.setProperty("rootpaths", str2);
    this.exclusions = new Vector();
    this.nodeExecuteType = 1;
    this.treeModel.traverseDepthLast(this.rootNode, this);
    str2 = "";
    i = this.exclusions.size();
    for (int j = 0; j < i; j++)
    {
      String str4 = (String)this.exclusions.elementAt(j);
      str2 = str2 + str4;
      if (j < i - 1) {
        str2 = str2 + ",";
      }
    }
    localProperties.setProperty("excludepaths", str2);
    if (this.extensionSet != null)
    {
      String str3 = this.extensionSet.toString();
      localProperties.setProperty("extensions", str3);
    }
    try
    {
      localProperties.store(localFileOutputStream, this.rootNode.toString() + " Code Set Properties");
    }
    catch (IOException localIOException1)
    {
      System.err.println("File " + str1 + " store failed");
      try
      {
        localFileOutputStream.close();
      }
      catch (IOException localIOException3) {}
      return;
    }
    this.codeSetChanged = false;
    updateCodeSetList(this.rootNode.toString() + ".set");
    try
    {
      localFileOutputStream.close();
    }
    catch (IOException localIOException2) {}
  }
  
  private boolean saveChangedCodeset(boolean paramBoolean)
  {
    if (this.codeSetChanged)
    {
      int i = JOptionPane.showConfirmDialog(null, "The current Code Set has been modified, do you want to save it?", "Save Current Code Set?", 0);
      if (i == 0)
      {
        if (this.extensionSet == null)
        {
          if (!paramBoolean)
          {
            JOptionPane.showMessageDialog(null, "you must choose the Extension Set for this Code Set", "Save Failed", 0);
            return false;
          }
          localObject = (ExtensionSet)this.extensionSets.elementAt(0);
          this.extensionSet = new ExtensionSet((ExtensionSet)localObject);
          String str = "No Extension Set selected: Loading default: " + ((ExtensionSet)localObject).toString();
          JOptionPane.showMessageDialog(null, str, "Saving With Default Extension Set", 0);
        }
        Object localObject = this.rootNode.toString();
        while (((String)localObject).equals("New"))
        {
          localObject = JOptionPane.showInputDialog("Enter name for this code set:", this.rootNode.toString());
          this.rootNode.rename((String)localObject);
        }
        saveCodeSet();
      }
    }
    return true;
  }
  
  private void updateLastSetsMenu()
  {
    this.fileMenu.remove(this.lastSetsMenu);
    this.lastSetsMenu = new JMenu();
    this.lastSetsMenu.setText("Recent Code Sets");
    this.lastSetsMenu.setToolTipText("Select a recently used Code Set");
    for (int i = 0; i < this.lastCodeSets.size(); i++)
    {
      JMenuItem localJMenuItem = new JMenuItem();
      localJMenuItem.setText((String)this.lastCodeSets.elementAt(i));
      localJMenuItem.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          MainFrame.this.lastSetsMenuItemActionPerformed(paramAnonymousActionEvent);
        }
      });
      this.lastSetsMenu.add(localJMenuItem);
    }
    this.fileMenu.add(this.lastSetsMenu, 4);
  }
  
  private void updateCodeSetList(String paramString)
  {
    for (int i = this.lastCodeSets.indexOf(paramString); i != -1; i = this.lastCodeSets.indexOf(paramString)) {
      this.lastCodeSets.removeElementAt(i);
    }
    this.lastCodeSets.add(0, paramString);
    if (this.lastCodeSets.size() > 10) {
      this.lastCodeSets.setSize(10);
    }
    updateLastSetsMenu();
  }
  
  private void updateCommentsDeleteMenu()
  {
    this.menuComments.remove(this.commentsDeleteType);
    this.commentsDeleteType = new JMenu();
    this.commentsDeleteType.setText("Delete");
    this.commentsDeleteType.setToolTipText("Delete an existing comment set type");
    for (int i = 0; i < this.commentSets.size(); i++)
    {
      JMenuItem localJMenuItem = new JMenuItem();
      localJMenuItem.setText(((CommentSet)this.commentSets.elementAt(i)).toString());
      localJMenuItem.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          MainFrame.this.commentDeleteMenuItemActionPerformed(paramAnonymousActionEvent);
        }
      });
      this.commentsDeleteType.add(localJMenuItem);
    }
    this.menuComments.add(this.commentsDeleteType, 2);
  }
  
  private void updateCommentsEditMenu()
  {
    this.menuComments.remove(this.commentsEditType);
    this.commentsEditType = new JMenu();
    this.commentsEditType.setText("Edit");
    this.commentsEditType.setToolTipText("Edit an existing comment set type");
    for (int i = 0; i < this.commentSets.size(); i++)
    {
      JMenuItem localJMenuItem = new JMenuItem();
      localJMenuItem.setText(((CommentSet)this.commentSets.elementAt(i)).toString());
      localJMenuItem.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          MainFrame.this.commentEditMenuItemActionPerformed(paramAnonymousActionEvent);
        }
      });
      this.commentsEditType.add(localJMenuItem);
    }
    this.menuComments.add(this.commentsEditType, 4);
  }
  
  private void updateCommentsList(CommentSet paramCommentSet)
  {
    this.commentSets.addElement(paramCommentSet);
    updateCommentsDeleteMenu();
    updateCommentsEditMenu();
  }
  
  private void updateExtensionsDeleteMenu()
  {
    this.menuExtensions.remove(this.extensionsDeleteType);
    this.extensionsDeleteType = new JMenu();
    this.extensionsDeleteType.setText("Delete");
    this.extensionsDeleteType.setToolTipText("Delete an existing extension set type");
    for (int i = 0; i < this.extensionSets.size(); i++)
    {
      JMenuItem localJMenuItem = new JMenuItem();
      localJMenuItem.setText(((ExtensionSet)this.extensionSets.elementAt(i)).toString());
      localJMenuItem.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          MainFrame.this.extensionDeleteMenuItemActionPerformed(paramAnonymousActionEvent);
        }
      });
      this.extensionsDeleteType.add(localJMenuItem);
    }
    this.menuExtensions.add(this.extensionsDeleteType, 2);
  }
  
  private void updateExtensionsEditMenu()
  {
    this.menuExtensions.remove(this.extensionsEditType);
    this.extensionsEditType = new JMenu();
    this.extensionsEditType.setText("Edit");
    this.extensionsEditType.setToolTipText("Edit an existing extension set type");
    for (int i = 0; i < this.extensionSets.size(); i++)
    {
      JMenuItem localJMenuItem = new JMenuItem();
      localJMenuItem.setText(((ExtensionSet)this.extensionSets.elementAt(i)).toString());
      localJMenuItem.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          MainFrame.this.extensionEditMenuItemActionPerformed(paramAnonymousActionEvent);
        }
      });
      this.extensionsEditType.add(localJMenuItem);
    }
    this.menuExtensions.add(this.extensionsEditType, 4);
  }
  
  private void updateExtensionsSelectMenu()
  {
    this.menuExtensions.remove(this.extensionsSelectType);
    this.extensionsSelectType = new JMenu();
    this.extensionsSelectType.setText("Select");
    this.extensionsSelectType.setToolTipText("Select the active extension set type for this Code Set");
    for (int i = 0; i < this.extensionSets.size(); i++)
    {
      JMenuItem localJMenuItem = new JMenuItem();
      ExtensionSet localExtensionSet = (ExtensionSet)this.extensionSets.elementAt(i);
      localJMenuItem.setText(localExtensionSet.toString() + "  (" + localExtensionSet.showContents() + ")");
      localJMenuItem.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          MainFrame.this.extensionSelectMenuItemActionPerformed(paramAnonymousActionEvent);
        }
      });
      this.extensionsSelectType.add(localJMenuItem);
    }
    this.menuExtensions.add(this.extensionsSelectType, 6);
  }
  
  private void updateExtensionsList(ExtensionSet paramExtensionSet)
  {
    this.extensionSets.addElement(paramExtensionSet);
    updateExtensionsDeleteMenu();
    updateExtensionsEditMenu();
    updateExtensionsSelectMenu();
  }
  
  private void updateResultsPane(FileNode paramFileNode)
  {
    this.resultsPane.removeAll();
    if ((paramFileNode == null) || (this.extensionSet == null)) {
      return;
    }
    if (paramFileNode.isLeaf())
    {
      this.resultsPane.addTab(paramFileNode.toString(), new AnalyzerResults(paramFileNode, -1));
      return;
    }
    this.resultsPane.addTab("All Files", new AnalyzerResults(paramFileNode, -1));
    Vector localVector = this.extensionSet.getExtensionVector();
    for (int i = 0; i < localVector.size(); i++)
    {
      Extension localExtension = (Extension)localVector.elementAt(i);
      this.resultsPane.addTab(localExtension.toString(), new AnalyzerResults(paramFileNode, i));
    }
  }
  
  public boolean executeForNode(FileNode paramFileNode)
  {
    switch (this.nodeExecuteType)
    {
    case 1: 
      if (!paramFileNode.isIncluded())
      {
        this.exclusions.addElement(paramFileNode.getPath());
        if (!paramFileNode.isLeaf()) {
          return false;
        }
      }
      break;
    case 2: 
      if (!this.analyzeRunState) {
        return false;
      }
      if (!paramFileNode.isIncluded())
      {
        paramFileNode.stats.clear();
        return false;
      }
      Runnable local8 = new Runnable()
      {
        public void run()
        {
          MainFrame.this.progressBar.setValue(MainFrame.access$1704(MainFrame.this));
          MainFrame.this.treeModel.fireTreeStructureChanged(MainFrame.this.analyzeTreePath);
        }
      };
      SwingUtilities.invokeLater(local8);
      Object localObject;
      if (paramFileNode.isLeaf())
      {
        localObject = this.extensionSet.getExtension(paramFileNode);
        if (localObject == null) {
          return false;
        }
        FileProcessor localFileProcessor;
        try
        {
          localFileProcessor = new FileProcessor(paramFileNode, ((Extension)localObject).getCommentSet());
        }
        catch (FileNotFoundException localFileNotFoundException)
        {
          return false;
        }
        try
        {
          localFileProcessor.process();
        }
        catch (IOException localIOException) {}
      }
      else
      {
        localObject = new FolderProcessor(paramFileNode);
        ((FolderProcessor)localObject).process();
      }
      break;
    case 3: 
      paramFileNode.stats.clear();
    }
    return true;
  }
  
  private String removeExtension(File paramFile)
  {
    if (paramFile != null)
    {
      String str = paramFile.getName();
      int i = str.lastIndexOf('.');
      if ((i > 0) && (i < str.length() - 1)) {
        return str.substring(0, i);
      }
    }
    return null;
  }
  
  private String removeExtension(String paramString)
  {
    if (paramString != null)
    {
      String str = paramString;
      int i = str.lastIndexOf('.');
      if ((i > 0) && (i < str.length() - 1)) {
        return str.substring(0, i);
      }
    }
    return null;
  }
  
  private void initComponents()
  {
    this.rootPopupMenu = new JPopupMenu();
    this.rootMenuAddNew = new JMenuItem();
    this.rootMenuRename = new JMenuItem();
    this.rootMenuStats = new JMenuItem();
    this.level1PopupMenu = new JPopupMenu();
    this.level1MenuRemove = new JMenuItem();
    this.level1MenuInclude = new JMenuItem();
    this.level1MenuExclude = new JMenuItem();
    this.level1MenuStats = new JMenuItem();
    this.nodePopupMenu = new JPopupMenu();
    this.nodeMenuInclude = new JMenuItem();
    this.nodeMenuExclude = new JMenuItem();
    this.nodeMenuStats = new JMenuItem();
    this.statsDialog = new JDialog();
    this.statsDialogText = new JTextArea();
    this.editExtensionSetDialog = new JDialog();
    this.extSetNameLabel = new JLabel();
    this.extSetNameDisplay = new JTextField();
    this.extListScrollPane = new JScrollPane();
    this.extensionList = new JList();
    this.addExtensionButton = new JButton();
    this.delExtensionButton = new JButton();
    this.addFromExistingButton = new JButton();
    this.extensionLabel = new JLabel();
    this.extensionDisplay = new JTextField();
    this.commSetLabel = new JLabel();
    this.commSetComboBox = new JComboBox(this.commentSets);
    this.saveButton = new JButton();
    this.cancelButton = new JButton();
    this.jSeparator3 = new JSeparator();
    this.jSeparator7 = new JSeparator();
    this.jSeparator8 = new JSeparator();
    this.ExtensionListLabel = new JLabel();
    this.extensionDefineLabel = new JLabel();
    this.editCommentSetDialog = new JDialog();
    this.commSetNameLabel = new JLabel();
    this.commSetNameDisplay = new JTextField();
    this.jSeparator9 = new JSeparator();
    this.commentList = new JList();
    this.addCommentButton = new JButton();
    this.delCommentButton = new JButton();
    this.jSeparator10 = new JSeparator();
    this.commOpenLabel = new JLabel();
    this.commOpenDisplay = new JTextField();
    this.commEOLLabel = new JLabel();
    this.commEOLCheckBox = new JCheckBox();
    this.commCloseLabel = new JLabel();
    this.commCloseDisplay = new JTextField();
    this.jSeparator11 = new JSeparator();
    this.commSetSaveButton = new JButton();
    this.commSetCancelButton = new JButton();
    this.helpEditorPane = new JEditorPane();
    this.treePane = new JScrollPane();
    this.codesetTree = new JTree(this.treeModel);
    this.resultsPane = new JTabbedPane();
    this.extensionsLabel = new JLabel();
    this.extensionsDisplay = new JTextField();
    this.statusDisplay = new JTextField();
    this.treeLabel = new JLabel();
    this.resultsLabel = new JLabel();
    this.progressBar = new JProgressBar();
    this.MenuBar = new JMenuBar();
    this.fileMenu = new JMenu();
    this.menuNewSet = new JMenuItem();
    this.menuOpenSet = new JMenuItem();
    this.menuSaveSet = new JMenuItem();
    this.menuSaveSetAs = new JMenuItem();
    this.lastSetsMenu = new JMenu();
    this.menuExit = new JMenuItem();
    this.runMenu = new JMenu();
    this.menuRun = new JMenuItem();
    this.menuStop = new JMenuItem();
    this.toolsMenu = new JMenu();
    this.menuComments = new JMenu();
    this.commentsAddType = new JMenuItem();
    this.jSeparator1 = new JSeparator();
    this.commentsDeleteType = new JMenu();
    this.jSeparator2 = new JSeparator();
    this.commentsEditType = new JMenu();
    this.menuExtensions = new JMenu();
    this.extensionsAddType = new JMenuItem();
    this.jSeparator4 = new JSeparator();
    this.extensionsDeleteType = new JMenu();
    this.jSeparator5 = new JSeparator();
    this.extensionsEditType = new JMenu();
    this.jSeparator6 = new JSeparator();
    this.extensionsSelectType = new JMenu();
    this.reportsMenu = new JMenu();
    this.menuReportFile = new JMenuItem();
    this.menuReportSummary = new JMenuItem();
    this.menuReportAllText = new JMenuItem();
    this.menuReportAllCommaDelim = new JMenuItem();
    this.menuReportAllHTML = new JMenuItem();
    this.helpMenu = new JMenu();
    this.menuHelp = new JMenuItem();
    this.menuAbout = new JMenuItem();
    this.rootMenuAddNew.setText("Add Branch");
    this.rootMenuAddNew.setToolTipText("Add a new filesystem branch to this code set");
    this.rootMenuAddNew.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.rootMenuAddNewActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.rootPopupMenu.add(this.rootMenuAddNew);
    this.rootMenuRename.setText("Rename");
    this.rootMenuRename.setToolTipText("Rename this code set");
    this.rootMenuRename.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.rootMenuRenameActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.rootPopupMenu.add(this.rootMenuRename);
    this.rootMenuStats.setText("Show Stats");
    this.rootMenuStats.setToolTipText("Show statistics for this node");
    this.rootMenuStats.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.menuStatsActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.rootPopupMenu.add(this.rootMenuStats);
    this.level1MenuRemove.setText("Remove");
    this.level1MenuRemove.setToolTipText("Remove this filesystem branch from the code set");
    this.level1MenuRemove.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.level1MenuRemoveActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.level1PopupMenu.add(this.level1MenuRemove);
    this.level1MenuInclude.setText("Include");
    this.level1MenuInclude.setToolTipText("Include this branch in analysis");
    this.level1MenuInclude.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.level1MenuIncludeActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.level1PopupMenu.add(this.level1MenuInclude);
    this.level1MenuExclude.setText("Exclude");
    this.level1MenuExclude.setToolTipText("Exclude this branch from analysis");
    this.level1MenuExclude.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.level1MenuExcludeActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.level1PopupMenu.add(this.level1MenuExclude);
    this.level1MenuStats.setText("Show Stats");
    this.level1MenuStats.setToolTipText("Show statistics for this node");
    this.level1MenuStats.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.menuStatsActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.level1PopupMenu.add(this.level1MenuStats);
    this.nodeMenuInclude.setText("Include");
    this.nodeMenuInclude.setToolTipText("Include this file/branch in analysis");
    this.nodeMenuInclude.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.nodeMenuIncludeActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.nodePopupMenu.add(this.nodeMenuInclude);
    this.nodeMenuExclude.setText("Exclude");
    this.nodeMenuExclude.setToolTipText("Exclude this file/branch from analysis");
    this.nodeMenuExclude.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.nodeMenuExcludeActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.nodePopupMenu.add(this.nodeMenuExclude);
    this.nodeMenuStats.setText("Show Stats");
    this.nodeMenuStats.setToolTipText("Show statistics for this node");
    this.nodeMenuStats.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.menuStatsActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.nodePopupMenu.add(this.nodeMenuStats);
    this.statsDialog.setTitle("Statistics");
    this.statsDialog.setFont(new Font("Monospaced", 0, 12));
    this.statsDialog.setLocationRelativeTo(this.codesetTree);
    this.statsDialog.setModal(true);
    this.statsDialog.setResizable(false);
    this.statsDialogText.setEditable(false);
    this.statsDialogText.setFont(new Font("Monospaced", 0, 12));
    this.statsDialogText.setRows(29);
    this.statsDialog.getContentPane().add(this.statsDialogText, "Center");
    this.editExtensionSetDialog.getContentPane().setLayout(new GridBagLayout());
    this.editExtensionSetDialog.setTitle("Edit Extension Set");
    this.editExtensionSetDialog.setLocationRelativeTo(this);
    this.editExtensionSetDialog.setModal(true);
    this.editExtensionSetDialog.setResizable(false);
    this.extSetNameLabel.setText("Extension Set Name:");
    GridBagConstraints localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.insets = new Insets(24, 4, 24, 0);
    this.editExtensionSetDialog.getContentPane().add(this.extSetNameLabel, localGridBagConstraints);
    this.extSetNameDisplay.setMinimumSize(new Dimension(180, 20));
    this.extSetNameDisplay.setPreferredSize(new Dimension(180, 20));
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridwidth = 0;
    localGridBagConstraints.anchor = 17;
    localGridBagConstraints.insets = new Insets(24, 12, 24, 0);
    this.editExtensionSetDialog.getContentPane().add(this.extSetNameDisplay, localGridBagConstraints);
    this.extListScrollPane.setHorizontalScrollBarPolicy(31);
    this.extListScrollPane.setMinimumSize(new Dimension(280, 180));
    this.extListScrollPane.setPreferredSize(new Dimension(280, 180));
    this.extensionList.setSelectionMode(0);
    this.extensionList.setAutoscrolls(false);
    this.extensionList.addListSelectionListener(new ListSelectionListener()
    {
      public void valueChanged(ListSelectionEvent paramAnonymousListSelectionEvent)
      {
        MainFrame.this.extensionListValueChanged(paramAnonymousListSelectionEvent);
      }
    });
    this.extListScrollPane.setViewportView(this.extensionList);
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 3;
    localGridBagConstraints.gridwidth = 2;
    localGridBagConstraints.gridheight = 3;
    localGridBagConstraints.fill = 1;
    localGridBagConstraints.insets = new Insets(2, 2, 2, 2);
    this.editExtensionSetDialog.getContentPane().add(this.extListScrollPane, localGridBagConstraints);
    this.addExtensionButton.setText("Add");
    this.addExtensionButton.setToolTipText("Add a new extension to the set");
    this.addExtensionButton.setMinimumSize(new Dimension(70, 26));
    this.addExtensionButton.setPreferredSize(new Dimension(70, 26));
    this.addExtensionButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.addExtensionButtonActionPerformed(paramAnonymousActionEvent);
      }
    });
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 2;
    localGridBagConstraints.gridy = 3;
    localGridBagConstraints.anchor = 16;
    localGridBagConstraints.insets = new Insets(18, 8, 2, 4);
    this.editExtensionSetDialog.getContentPane().add(this.addExtensionButton, localGridBagConstraints);
    this.delExtensionButton.setText("Delete");
    this.delExtensionButton.setToolTipText("Delete selected extension from the set");
    this.delExtensionButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.delExtensionButtonActionPerformed(paramAnonymousActionEvent);
      }
    });
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 2;
    localGridBagConstraints.gridy = 4;
    localGridBagConstraints.anchor = 18;
    localGridBagConstraints.insets = new Insets(2, 8, 0, 4);
    this.editExtensionSetDialog.getContentPane().add(this.delExtensionButton, localGridBagConstraints);
    this.addFromExistingButton.setText("Add Set");
    this.addFromExistingButton.setToolTipText("Add extensions from an existing Extension Set");
    this.addFromExistingButton.setMargin(new Insets(2, 4, 2, 4));
    this.addFromExistingButton.setMinimumSize(new Dimension(70, 26));
    this.addFromExistingButton.setPreferredSize(new Dimension(70, 26));
    this.addFromExistingButton.setVerticalAlignment(1);
    this.addFromExistingButton.setVerticalTextPosition(1);
    this.addFromExistingButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.addFromExistingButtonActionPerformed(paramAnonymousActionEvent);
      }
    });
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 2;
    localGridBagConstraints.gridy = 5;
    localGridBagConstraints.anchor = 18;
    localGridBagConstraints.insets = new Insets(4, 8, 16, 4);
    this.editExtensionSetDialog.getContentPane().add(this.addFromExistingButton, localGridBagConstraints);
    this.extensionLabel.setText("Extension");
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 8;
    localGridBagConstraints.anchor = 17;
    localGridBagConstraints.insets = new Insets(8, 24, 8, 0);
    this.editExtensionSetDialog.getContentPane().add(this.extensionLabel, localGridBagConstraints);
    this.extensionDisplay.setMinimumSize(new Dimension(80, 20));
    this.extensionDisplay.setPreferredSize(new Dimension(80, 20));
    this.extensionDisplay.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.extensionDisplayActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.extensionDisplay.addFocusListener(new FocusAdapter()
    {
      public void focusLost(FocusEvent paramAnonymousFocusEvent)
      {
        MainFrame.this.extensionDisplayFocusLost(paramAnonymousFocusEvent);
      }
    });
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 1;
    localGridBagConstraints.gridy = 8;
    localGridBagConstraints.anchor = 17;
    localGridBagConstraints.insets = new Insets(8, 2, 8, 0);
    this.editExtensionSetDialog.getContentPane().add(this.extensionDisplay, localGridBagConstraints);
    this.commSetLabel.setText("Comment Set");
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 9;
    localGridBagConstraints.anchor = 17;
    localGridBagConstraints.insets = new Insets(8, 24, 24, 0);
    this.editExtensionSetDialog.getContentPane().add(this.commSetLabel, localGridBagConstraints);
    this.commSetComboBox.setMaximumRowCount(10);
    this.commSetComboBox.setMinimumSize(new Dimension(200, 20));
    this.commSetComboBox.setPreferredSize(new Dimension(200, 20));
    this.commSetComboBox.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.commSetComboBoxActionPerformed(paramAnonymousActionEvent);
      }
    });
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 1;
    localGridBagConstraints.gridy = 9;
    localGridBagConstraints.anchor = 17;
    localGridBagConstraints.insets = new Insets(8, 2, 24, 4);
    this.editExtensionSetDialog.getContentPane().add(this.commSetComboBox, localGridBagConstraints);
    this.saveButton.setText("Save");
    this.saveButton.setToolTipText("Save changes to Extension Set");
    this.saveButton.setMinimumSize(new Dimension(74, 26));
    this.saveButton.setPreferredSize(new Dimension(74, 26));
    this.saveButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.saveButtonActionPerformed(paramAnonymousActionEvent);
      }
    });
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 1;
    localGridBagConstraints.gridy = 11;
    localGridBagConstraints.anchor = 13;
    localGridBagConstraints.insets = new Insets(24, 0, 16, 4);
    this.editExtensionSetDialog.getContentPane().add(this.saveButton, localGridBagConstraints);
    this.cancelButton.setText("Cancel");
    this.cancelButton.setToolTipText("Cancel changes to Extension Set");
    this.cancelButton.setMinimumSize(new Dimension(74, 26));
    this.cancelButton.setPreferredSize(new Dimension(74, 26));
    this.cancelButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.cancelButtonActionPerformed(paramAnonymousActionEvent);
      }
    });
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 2;
    localGridBagConstraints.gridy = 11;
    localGridBagConstraints.anchor = 17;
    localGridBagConstraints.insets = new Insets(24, 4, 16, 4);
    this.editExtensionSetDialog.getContentPane().add(this.cancelButton, localGridBagConstraints);
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 1;
    localGridBagConstraints.gridwidth = 0;
    localGridBagConstraints.fill = 2;
    localGridBagConstraints.insets = new Insets(2, 0, 2, 0);
    this.editExtensionSetDialog.getContentPane().add(this.jSeparator3, localGridBagConstraints);
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 6;
    localGridBagConstraints.gridwidth = 0;
    localGridBagConstraints.fill = 2;
    localGridBagConstraints.insets = new Insets(2, 0, 2, 0);
    this.editExtensionSetDialog.getContentPane().add(this.jSeparator7, localGridBagConstraints);
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 10;
    localGridBagConstraints.gridwidth = 0;
    localGridBagConstraints.fill = 2;
    localGridBagConstraints.insets = new Insets(2, 0, 2, 0);
    this.editExtensionSetDialog.getContentPane().add(this.jSeparator8, localGridBagConstraints);
    this.ExtensionListLabel.setText("Extensions");
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 2;
    localGridBagConstraints.gridwidth = 2;
    localGridBagConstraints.insets = new Insets(24, 0, 8, 0);
    this.editExtensionSetDialog.getContentPane().add(this.ExtensionListLabel, localGridBagConstraints);
    this.extensionDefineLabel.setText("Edit Extension");
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 7;
    localGridBagConstraints.gridwidth = 2;
    localGridBagConstraints.insets = new Insets(20, 0, 16, 0);
    this.editExtensionSetDialog.getContentPane().add(this.extensionDefineLabel, localGridBagConstraints);
    this.editCommentSetDialog.getContentPane().setLayout(new GridBagLayout());
    this.editCommentSetDialog.setTitle("");
    this.editCommentSetDialog.setResizable(false);
    this.commSetNameLabel.setText("Comment Set Name:");
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 0;
    localGridBagConstraints.anchor = 13;
    localGridBagConstraints.insets = new Insets(12, 16, 16, 10);
    this.editCommentSetDialog.getContentPane().add(this.commSetNameLabel, localGridBagConstraints);
    this.commSetNameDisplay.setMinimumSize(new Dimension(160, 20));
    this.commSetNameDisplay.setPreferredSize(new Dimension(160, 20));
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 1;
    localGridBagConstraints.gridy = 0;
    localGridBagConstraints.gridwidth = 0;
    localGridBagConstraints.anchor = 17;
    localGridBagConstraints.insets = new Insets(12, 0, 16, 8);
    this.editCommentSetDialog.getContentPane().add(this.commSetNameDisplay, localGridBagConstraints);
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 1;
    localGridBagConstraints.gridwidth = 0;
    localGridBagConstraints.fill = 2;
    this.editCommentSetDialog.getContentPane().add(this.jSeparator9, localGridBagConstraints);
    this.commentList.setFont(new Font("Monospaced", 1, 14));
    this.commentList.setSelectionMode(0);
    this.commentList.setMaximumSize(new Dimension(180, 240));
    this.commentList.setMinimumSize(new Dimension(180, 240));
    this.commentList.setPreferredSize(new Dimension(180, 240));
    this.commentList.addListSelectionListener(new ListSelectionListener()
    {
      public void valueChanged(ListSelectionEvent paramAnonymousListSelectionEvent)
      {
        MainFrame.this.commentListValueChanged(paramAnonymousListSelectionEvent);
      }
    });
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 2;
    localGridBagConstraints.gridwidth = 2;
    localGridBagConstraints.gridheight = 2;
    localGridBagConstraints.insets = new Insets(24, 0, 16, 0);
    this.editCommentSetDialog.getContentPane().add(this.commentList, localGridBagConstraints);
    this.addCommentButton.setText("Add");
    this.addCommentButton.setToolTipText("Add new comment type");
    this.addCommentButton.setMaximumSize(new Dimension(70, 26));
    this.addCommentButton.setMinimumSize(new Dimension(70, 26));
    this.addCommentButton.setPreferredSize(new Dimension(70, 26));
    this.addCommentButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.addCommentButtonActionPerformed(paramAnonymousActionEvent);
      }
    });
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 2;
    localGridBagConstraints.gridy = 2;
    localGridBagConstraints.anchor = 16;
    localGridBagConstraints.insets = new Insets(48, 0, 6, 4);
    this.editCommentSetDialog.getContentPane().add(this.addCommentButton, localGridBagConstraints);
    this.delCommentButton.setText("Delete");
    this.delCommentButton.setToolTipText("Delete selected comment type");
    this.delCommentButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.delCommentButtonActionPerformed(paramAnonymousActionEvent);
      }
    });
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 2;
    localGridBagConstraints.gridy = 3;
    localGridBagConstraints.anchor = 18;
    localGridBagConstraints.insets = new Insets(6, 0, 0, 4);
    this.editCommentSetDialog.getContentPane().add(this.delCommentButton, localGridBagConstraints);
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 4;
    localGridBagConstraints.gridwidth = 0;
    localGridBagConstraints.fill = 2;
    this.editCommentSetDialog.getContentPane().add(this.jSeparator10, localGridBagConstraints);
    this.commOpenLabel.setText("Comment Opening:");
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 5;
    localGridBagConstraints.anchor = 17;
    localGridBagConstraints.insets = new Insets(24, 40, 6, 0);
    this.editCommentSetDialog.getContentPane().add(this.commOpenLabel, localGridBagConstraints);
    this.commOpenDisplay.setText("jTextField1");
    this.commOpenDisplay.setMaximumSize(new Dimension(80, 20));
    this.commOpenDisplay.setMinimumSize(new Dimension(80, 20));
    this.commOpenDisplay.setPreferredSize(new Dimension(80, 20));
    this.commOpenDisplay.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.commOpenDisplayActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.commOpenDisplay.addFocusListener(new FocusAdapter()
    {
      public void focusLost(FocusEvent paramAnonymousFocusEvent)
      {
        MainFrame.this.commOpenDisplayFocusLost(paramAnonymousFocusEvent);
      }
    });
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 1;
    localGridBagConstraints.gridy = 5;
    localGridBagConstraints.gridwidth = 0;
    localGridBagConstraints.anchor = 17;
    localGridBagConstraints.insets = new Insets(24, 8, 6, 0);
    this.editCommentSetDialog.getContentPane().add(this.commOpenDisplay, localGridBagConstraints);
    this.commEOLLabel.setText("Comment is EOL:");
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 6;
    localGridBagConstraints.anchor = 17;
    localGridBagConstraints.insets = new Insets(0, 40, 6, 0);
    this.editCommentSetDialog.getContentPane().add(this.commEOLLabel, localGridBagConstraints);
    this.commEOLCheckBox.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.commEOLCheckBoxActionPerformed(paramAnonymousActionEvent);
      }
    });
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 1;
    localGridBagConstraints.gridy = 6;
    localGridBagConstraints.gridwidth = 0;
    localGridBagConstraints.anchor = 17;
    localGridBagConstraints.insets = new Insets(0, 8, 6, 0);
    this.editCommentSetDialog.getContentPane().add(this.commEOLCheckBox, localGridBagConstraints);
    this.commCloseLabel.setText("Comment Closing:");
    this.commCloseLabel.setToolTipText("");
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 7;
    localGridBagConstraints.anchor = 17;
    localGridBagConstraints.insets = new Insets(0, 40, 24, 0);
    this.editCommentSetDialog.getContentPane().add(this.commCloseLabel, localGridBagConstraints);
    this.commCloseDisplay.setText("jTextField2");
    this.commCloseDisplay.setMaximumSize(new Dimension(80, 20));
    this.commCloseDisplay.setMinimumSize(new Dimension(80, 20));
    this.commCloseDisplay.setPreferredSize(new Dimension(80, 20));
    this.commCloseDisplay.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.commCloseDisplayActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.commCloseDisplay.addFocusListener(new FocusAdapter()
    {
      public void focusLost(FocusEvent paramAnonymousFocusEvent)
      {
        MainFrame.this.commCloseDisplayFocusLost(paramAnonymousFocusEvent);
      }
    });
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 1;
    localGridBagConstraints.gridy = 7;
    localGridBagConstraints.gridwidth = 0;
    localGridBagConstraints.anchor = 17;
    localGridBagConstraints.insets = new Insets(0, 8, 24, 0);
    this.editCommentSetDialog.getContentPane().add(this.commCloseDisplay, localGridBagConstraints);
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 8;
    localGridBagConstraints.gridwidth = 0;
    localGridBagConstraints.fill = 2;
    this.editCommentSetDialog.getContentPane().add(this.jSeparator11, localGridBagConstraints);
    this.commSetSaveButton.setText("Save");
    this.commSetSaveButton.setMaximumSize(new Dimension(74, 26));
    this.commSetSaveButton.setMinimumSize(new Dimension(74, 26));
    this.commSetSaveButton.setPreferredSize(new Dimension(74, 26));
    this.commSetSaveButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.commSetSaveButtonActionPerformed(paramAnonymousActionEvent);
      }
    });
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 1;
    localGridBagConstraints.gridy = 9;
    localGridBagConstraints.anchor = 13;
    localGridBagConstraints.insets = new Insets(20, 0, 12, 12);
    this.editCommentSetDialog.getContentPane().add(this.commSetSaveButton, localGridBagConstraints);
    this.commSetCancelButton.setText("Cancel");
    this.commSetCancelButton.setMaximumSize(new Dimension(74, 26));
    this.commSetCancelButton.setMinimumSize(new Dimension(74, 26));
    this.commSetCancelButton.setPreferredSize(new Dimension(74, 26));
    this.commSetCancelButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.commSetCancelButtonActionPerformed(paramAnonymousActionEvent);
      }
    });
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 2;
    localGridBagConstraints.gridy = 9;
    localGridBagConstraints.anchor = 17;
    localGridBagConstraints.insets = new Insets(20, 0, 12, 4);
    this.editCommentSetDialog.getContentPane().add(this.commSetCancelButton, localGridBagConstraints);
    this.helpEditorPane.setEditable(false);
    this.helpEditorPane.setContentType("text/html");
    getContentPane().setLayout(new GridBagLayout());
    setDefaultCloseOperation(2);
    setTitle("Code Analyzer");
    setBackground(new Color(255, 255, 255));
    setIconImage(this.mainIcon.getImage());
    addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent paramAnonymousWindowEvent)
      {
        MainFrame.this.exitForm(paramAnonymousWindowEvent);
      }
    });
    this.treePane.setMinimumSize(new Dimension(330, 620));
    this.treePane.setPreferredSize(new Dimension(330, 620));
    this.codesetTree.setCellRenderer(new CodeSetTreeCellRenderer());
    this.codesetTree.addMouseListener(new MouseAdapter()
    {
      public void mousePressed(MouseEvent paramAnonymousMouseEvent)
      {
        MainFrame.this.codesetTreeMouseReleased(paramAnonymousMouseEvent);
      }
      
      public void mouseReleased(MouseEvent paramAnonymousMouseEvent)
      {
        MainFrame.this.codesetTreeMouseReleased(paramAnonymousMouseEvent);
      }
    });
    this.treePane.setViewportView(this.codesetTree);
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 1;
    localGridBagConstraints.fill = 1;
    localGridBagConstraints.anchor = 18;
    localGridBagConstraints.weightx = 0.35D;
    localGridBagConstraints.weighty = 0.8D;
    localGridBagConstraints.insets = new Insets(2, 2, 2, 2);
    getContentPane().add(this.treePane, localGridBagConstraints);
    this.resultsPane.setBackground(new Color(204, 204, 204));
    this.resultsPane.setBorder(new EtchedBorder());
    this.resultsPane.setMinimumSize(new Dimension(680, 620));
    this.resultsPane.setPreferredSize(new Dimension(680, 620));
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 1;
    localGridBagConstraints.gridy = 1;
    localGridBagConstraints.gridwidth = -1;
    localGridBagConstraints.fill = 1;
    localGridBagConstraints.anchor = 12;
    localGridBagConstraints.weightx = 0.65D;
    localGridBagConstraints.weighty = 0.8D;
    localGridBagConstraints.insets = new Insets(2, 2, 2, 2);
    getContentPane().add(this.resultsPane, localGridBagConstraints);
    this.extensionsLabel.setText("Extension Set");
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 1;
    localGridBagConstraints.gridy = 2;
    localGridBagConstraints.insets = new Insets(4, 0, 0, 0);
    getContentPane().add(this.extensionsLabel, localGridBagConstraints);
    this.extensionsDisplay.setMinimumSize(new Dimension(194, 20));
    this.extensionsDisplay.setPreferredSize(new Dimension(194, 20));
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 1;
    localGridBagConstraints.gridy = 3;
    localGridBagConstraints.fill = 2;
    localGridBagConstraints.weightx = 0.65D;
    localGridBagConstraints.insets = new Insets(0, 40, 0, 40);
    getContentPane().add(this.extensionsDisplay, localGridBagConstraints);
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 4;
    localGridBagConstraints.gridwidth = 0;
    localGridBagConstraints.fill = 2;
    localGridBagConstraints.insets = new Insets(8, 8, 8, 8);
    getContentPane().add(this.statusDisplay, localGridBagConstraints);
    this.treeLabel.setText("Code Set Browser");
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 0;
    localGridBagConstraints.insets = new Insets(16, 0, 0, 0);
    getContentPane().add(this.treeLabel, localGridBagConstraints);
    this.resultsLabel.setText("Results");
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 1;
    localGridBagConstraints.gridy = 0;
    localGridBagConstraints.gridwidth = -1;
    localGridBagConstraints.insets = new Insets(16, 0, 0, 0);
    getContentPane().add(this.resultsLabel, localGridBagConstraints);
    this.progressBar.setForeground(new Color(0, 102, 153));
    this.progressBar.setBorder(null);
    this.progressBar.setMinimumSize(new Dimension(280, 34));
    this.progressBar.setPreferredSize(new Dimension(280, 34));
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 2;
    localGridBagConstraints.gridheight = 2;
    localGridBagConstraints.fill = 2;
    localGridBagConstraints.anchor = 16;
    localGridBagConstraints.weightx = 0.35D;
    localGridBagConstraints.insets = new Insets(0, 10, 0, 10);
    getContentPane().add(this.progressBar, localGridBagConstraints);
    this.MenuBar.setMargin(new Insets(2, 0, 2, 0));
    this.fileMenu.setHorizontalAlignment(0);
    this.fileMenu.setHorizontalTextPosition(0);
    this.fileMenu.setIconTextGap(0);
    this.fileMenu.setLabel("File  ");
    this.fileMenu.setMaximumSize(new Dimension(60, 24));
    this.fileMenu.setMinimumSize(new Dimension(60, 24));
    this.fileMenu.setPreferredSize(new Dimension(60, 24));
    this.menuNewSet.setText("New Code Set");
    this.menuNewSet.setToolTipText("Create new collection of source files");
    this.menuNewSet.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.menuNewSetActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.fileMenu.add(this.menuNewSet);
    this.menuOpenSet.setText("Open Code Set");
    this.menuOpenSet.setToolTipText("Open a collection of source files");
    this.menuOpenSet.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.menuOpenSetActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.fileMenu.add(this.menuOpenSet);
    this.menuSaveSet.setText("Save Code Set");
    this.menuSaveSet.setToolTipText("Save the current collection of source files");
    this.menuSaveSet.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.menuSaveSetActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.fileMenu.add(this.menuSaveSet);
    this.menuSaveSetAs.setText("Save As Code Set");
    this.menuSaveSetAs.setToolTipText("Save the current source collection to a new collection");
    this.menuSaveSetAs.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.menuSaveSetAsActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.fileMenu.add(this.menuSaveSetAs);
    this.lastSetsMenu.setText("Recent Code Sets");
    this.lastSetsMenu.setToolTipText("Select a recently used Code Set");
    this.fileMenu.add(this.lastSetsMenu);
    this.menuExit.setText("Exit");
    this.menuExit.setToolTipText("Exit Code Analyzer");
    this.menuExit.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.menuExitActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.fileMenu.add(this.menuExit);
    this.MenuBar.add(this.fileMenu);
    this.runMenu.setHorizontalAlignment(0);
    this.runMenu.setHorizontalTextPosition(0);
    this.runMenu.setLabel("Run  ");
    this.runMenu.setMaximumSize(new Dimension(60, 24));
    this.runMenu.setMinimumSize(new Dimension(60, 24));
    this.runMenu.setPreferredSize(new Dimension(60, 24));
    this.menuRun.setText("Run");
    this.menuRun.setToolTipText("Analyze the current code set");
    this.menuRun.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.menuRunActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.runMenu.add(this.menuRun);
    this.menuStop.setText("Stop");
    this.menuStop.setToolTipText("Stop analysis");
    this.menuStop.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.menuStopActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.runMenu.add(this.menuStop);
    this.MenuBar.add(this.runMenu);
    this.toolsMenu.setHorizontalAlignment(0);
    this.toolsMenu.setHorizontalTextPosition(0);
    this.toolsMenu.setLabel("Tools   ");
    this.toolsMenu.setMaximumSize(new Dimension(60, 24));
    this.toolsMenu.setMinimumSize(new Dimension(60, 24));
    this.toolsMenu.setPreferredSize(new Dimension(60, 24));
    this.menuComments.setText("Comment Sets");
    this.menuComments.setToolTipText("Add/Delete/Edit Comment Sets");
    this.commentsAddType.setText("Add");
    this.commentsAddType.setToolTipText("Create a new comment set type");
    this.commentsAddType.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.commentsAddTypeActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.menuComments.add(this.commentsAddType);
    this.menuComments.add(this.jSeparator1);
    this.commentsDeleteType.setText("Delete");
    this.commentsDeleteType.setToolTipText("Delete an existing comment set type");
    this.menuComments.add(this.commentsDeleteType);
    this.menuComments.add(this.jSeparator2);
    this.commentsEditType.setText("Edit");
    this.commentsEditType.setToolTipText("Edit an existing comment set type");
    this.menuComments.add(this.commentsEditType);
    this.toolsMenu.add(this.menuComments);
    this.menuExtensions.setText("Extension Sets");
    this.menuExtensions.setToolTipText("Add/Delete/Edit/Select Extension Sets");
    this.extensionsAddType.setText("Add");
    this.extensionsAddType.setToolTipText("Create a new extension set type");
    this.extensionsAddType.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.extensionsAddTypeActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.menuExtensions.add(this.extensionsAddType);
    this.menuExtensions.add(this.jSeparator4);
    this.extensionsDeleteType.setText("Delete");
    this.extensionsDeleteType.setToolTipText("Delete an existing extension set type");
    this.menuExtensions.add(this.extensionsDeleteType);
    this.menuExtensions.add(this.jSeparator5);
    this.extensionsEditType.setText("Edit");
    this.extensionsEditType.setToolTipText("Edit an existing extension set type");
    this.menuExtensions.add(this.extensionsEditType);
    this.menuExtensions.add(this.jSeparator6);
    this.extensionsSelectType.setText("Select");
    this.extensionsSelectType.setToolTipText("Select the active extension set type for this Code Set");
    this.menuExtensions.add(this.extensionsSelectType);
    this.toolsMenu.add(this.menuExtensions);
    this.MenuBar.add(this.toolsMenu);
    this.reportsMenu.setText("Reports  ");
    this.reportsMenu.setHorizontalAlignment(0);
    this.reportsMenu.setMaximumSize(new Dimension(60, 24));
    this.reportsMenu.setMinimumSize(new Dimension(60, 24));
    this.reportsMenu.setPreferredSize(new Dimension(60, 24));
    this.menuReportFile.setText("Selected File Summary");
    this.menuReportFile.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.menuReportFileActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.reportsMenu.add(this.menuReportFile);
    this.menuReportSummary.setText("Code Set Summary");
    this.menuReportSummary.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.menuReportSummaryActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.reportsMenu.add(this.menuReportSummary);
    this.menuReportAllText.setText("Full Text Report");
    this.menuReportAllText.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.menuReportAllTextActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.reportsMenu.add(this.menuReportAllText);
    this.menuReportAllCommaDelim.setText("Full CSV Report");
    this.menuReportAllCommaDelim.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.menuReportAllCommaDelimActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.reportsMenu.add(this.menuReportAllCommaDelim);
    this.menuReportAllHTML.setText("Full HTML Report");
    this.menuReportAllHTML.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.menuReportAllHTMLActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.reportsMenu.add(this.menuReportAllHTML);
    this.MenuBar.add(this.reportsMenu);
    this.helpMenu.setHorizontalAlignment(0);
    this.helpMenu.setHorizontalTextPosition(0);
    this.helpMenu.setLabel("Help   ");
    this.helpMenu.setMaximumSize(new Dimension(60, 24));
    this.helpMenu.setMinimumSize(new Dimension(60, 24));
    this.helpMenu.setPreferredSize(new Dimension(60, 24));
    this.menuHelp.setText("User's Guide");
    this.menuHelp.setToolTipText("Display the HTML User's Guide");
    this.menuHelp.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.menuHelpActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.helpMenu.add(this.menuHelp);
    this.menuAbout.setText("About Code Analyzer");
    this.menuAbout.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        MainFrame.this.menuAboutActionPerformed(paramAnonymousActionEvent);
      }
    });
    this.helpMenu.add(this.menuAbout);
    this.MenuBar.add(this.helpMenu);
    setJMenuBar(this.MenuBar);
    Dimension localDimension = Toolkit.getDefaultToolkit().getScreenSize();
    setBounds((localDimension.width - 1024) / 2, (localDimension.height - 768) / 2, 1024, 768);
  }
  
  private void codesetTreeMouseReleased(MouseEvent paramMouseEvent)
  {
    if (this.analyzeRunState == true) {
      return;
    }
    TreePath localTreePath = this.codesetTree.getPathForLocation(paramMouseEvent.getX(), paramMouseEvent.getY());
    this.codesetTree.setSelectionPath(localTreePath);
    FileNode localFileNode = (FileNode)this.codesetTree.getLastSelectedPathComponent();
    this.statusDisplay.setText("");
    this.progressBar.setValue(0);
    updateResultsPane(localFileNode);
    if ((paramMouseEvent.isPopupTrigger()) && (localFileNode != null)) {
      if (localFileNode.isRoot()) {
        this.rootPopupMenu.show(this.codesetTree, paramMouseEvent.getX(), paramMouseEvent.getY());
      } else if (localFileNode.isLevel1()) {
        this.level1PopupMenu.show(this.codesetTree, paramMouseEvent.getX(), paramMouseEvent.getY());
      } else {
        this.nodePopupMenu.show(this.codesetTree, paramMouseEvent.getX(), paramMouseEvent.getY());
      }
    }
  }
  
  private void rootMenuRenameActionPerformed(ActionEvent paramActionEvent)
  {
    String str = JOptionPane.showInputDialog("Enter name for this code set:", this.rootNode.toString());
    if (!this.rootNode.toString().equals(str))
    {
      TreePath localTreePath = this.codesetTree.getSelectionPath();
      this.rootNode.rename(str);
      this.codeSetChanged = true;
      this.treeModel.fireTreeStructureChanged(localTreePath);
    }
  }
  
  private void rootMenuAddNewActionPerformed(ActionEvent paramActionEvent)
  {
    JFileChooser localJFileChooser = new JFileChooser(System.getProperty("user.home"));
    localJFileChooser.setFileSelectionMode(2);
    localJFileChooser.setDialogTitle(new String("Select New Code Set Branch(es)"));
    localJFileChooser.setMultiSelectionEnabled(true);
    int i = localJFileChooser.showOpenDialog(this);
    if (i == 0)
    {
      File[] arrayOfFile = localJFileChooser.getSelectedFiles();
      this.rootNode.addBranches(arrayOfFile);
      TreePath localTreePath = this.codesetTree.getSelectionPath();
      this.codeSetChanged = true;
      this.treeModel.fireTreeStructureChanged(localTreePath);
    }
  }
  
  private void level1MenuRemoveActionPerformed(ActionEvent paramActionEvent)
  {
    int i = JOptionPane.showConfirmDialog(null, "Delete this code branch?", "Confirm Deletion", 0);
    if (i == 0)
    {
      FileNode localFileNode = (FileNode)this.codesetTree.getLastSelectedPathComponent();
      TreePath localTreePath = new TreePath(this.rootNode);
      this.rootNode.removeBranch(localFileNode.toString());
      this.codeSetChanged = true;
      this.treeModel.fireTreeStructureChanged(localTreePath);
    }
  }
  
  private void level1MenuIncludeActionPerformed(ActionEvent paramActionEvent)
  {
    FileNode localFileNode = (FileNode)this.codesetTree.getLastSelectedPathComponent();
    TreePath localTreePath = this.codesetTree.getSelectionPath();
    if (this.treeModel.nodeInclude(localFileNode)) {
      this.codeSetChanged = true;
    }
    this.treeModel.fireTreeStructureChanged(localTreePath);
  }
  
  private void level1MenuExcludeActionPerformed(ActionEvent paramActionEvent)
  {
    FileNode localFileNode = (FileNode)this.codesetTree.getLastSelectedPathComponent();
    TreePath localTreePath = this.codesetTree.getSelectionPath();
    if (this.treeModel.nodeExclude(localFileNode)) {
      this.codeSetChanged = true;
    }
    this.treeModel.fireTreeStructureChanged(localTreePath);
  }
  
  private void nodeMenuIncludeActionPerformed(ActionEvent paramActionEvent)
  {
    FileNode localFileNode = (FileNode)this.codesetTree.getLastSelectedPathComponent();
    TreePath localTreePath = this.codesetTree.getSelectionPath();
    if (this.treeModel.nodeInclude(localFileNode)) {
      this.codeSetChanged = true;
    }
    this.treeModel.fireTreeStructureChanged(localTreePath);
  }
  
  private void nodeMenuExcludeActionPerformed(ActionEvent paramActionEvent)
  {
    FileNode localFileNode = (FileNode)this.codesetTree.getLastSelectedPathComponent();
    TreePath localTreePath = this.codesetTree.getSelectionPath();
    if (this.treeModel.nodeExclude(localFileNode)) {
      this.codeSetChanged = true;
    }
    this.treeModel.fireTreeStructureChanged(localTreePath);
  }
  
  private void menuStatsActionPerformed(ActionEvent paramActionEvent)
  {
    FileNode localFileNode = (FileNode)this.codesetTree.getLastSelectedPathComponent();
    localFileNode.stats.display(this.statsDialogText);
    Dimension localDimension = Toolkit.getDefaultToolkit().getScreenSize();
    this.statsDialog.setBounds((localDimension.width - 375) / 2, (localDimension.height - 320) / 2, 375, 320);
    if (localFileNode.isLeaf()) {
      this.statsDialog.setTitle("Statistics for file " + localFileNode.toString());
    } else {
      this.statsDialog.setTitle("Composite Statistics for folder " + localFileNode.toString());
    }
    this.statsDialog.show();
  }
  
  private void menuNewSetActionPerformed(ActionEvent paramActionEvent)
  {
    if (this.analyzeRunState == true)
    {
      this.statusDisplay.setText("This action cannot be performed - the Analyzer is running!");
      return;
    }
    this.statusDisplay.setText("");
    this.progressBar.setValue(0);
    if (!saveChangedCodeset(false)) {
      return;
    }
    this.rootNode = new FileNode("New", null, null, null);
    TreePath localTreePath = new TreePath(this.rootNode);
    this.treeModel = new CodeSetTreeModel(this.rootNode);
    this.codesetTree.setModel(this.treeModel);
    this.codeSetChanged = false;
    this.treeModel.fireTreeStructureChanged(localTreePath);
    this.extensionSet = null;
    this.extensionsDisplay.setText("");
    updateResultsPane(null);
  }
  
  private void menuOpenSetActionPerformed(ActionEvent paramActionEvent)
  {
    if (this.analyzeRunState == true)
    {
      this.statusDisplay.setText("This action cannot be performed - the Analyzer is running!");
      return;
    }
    this.statusDisplay.setText("");
    this.progressBar.setValue(0);
    if (!saveChangedCodeset(false)) {
      return;
    }
    String str1 = System.getProperty("user.home") + "/" + ".codeanalyzer";
    JFileChooser localJFileChooser = new JFileChooser(str1);
    localJFileChooser.setFileSelectionMode(0);
    localJFileChooser.setDialogTitle("Open Code Set");
    localJFileChooser.setMultiSelectionEnabled(false);
    HashFileFilter localHashFileFilter = new HashFileFilter();
    localHashFileFilter.addExtension("set");
    localHashFileFilter.setDescription("Code Set Files");
    localJFileChooser.setFileFilter(localHashFileFilter);
    int i = localJFileChooser.showOpenDialog(this);
    if (i == 0)
    {
      File localFile = localJFileChooser.getSelectedFile();
      if (!localFile.exists())
      {
        JOptionPane.showMessageDialog(null, "File does not exist", "Code Set Not Found", 0);
        return;
      }
      String str2 = removeExtension(localFile);
      loadCodeSet(str2);
      updateResultsPane(null);
    }
  }
  
  private void menuSaveSetActionPerformed(ActionEvent paramActionEvent)
  {
    if (this.analyzeRunState == true)
    {
      this.statusDisplay.setText("This action cannot be performed - the Analyzer is running!");
      return;
    }
    int i = 0;
    String str = this.rootNode.toString();
    this.statusDisplay.setText("");
    this.progressBar.setValue(0);
    if (this.extensionSet == null)
    {
      JOptionPane.showMessageDialog(null, "you must choose the Extension Set for this Code Set", "Save Failed", 0);
      return;
    }
    while (str.equals("New"))
    {
      str = JOptionPane.showInputDialog("Enter name for this code set:", this.rootNode.toString());
      this.rootNode.rename(str);
      i = 1;
    }
    saveCodeSet();
    if (i != 0)
    {
      TreePath localTreePath1 = this.codesetTree.getSelectionPath();
      TreePath localTreePath2 = new TreePath(this.rootNode);
      this.treeModel.fireTreeStructureChanged(localTreePath2);
      if (localTreePath1 != null) {
        this.treeModel.fireTreeStructureChanged(localTreePath1);
      }
    }
  }
  
  private void menuSaveSetAsActionPerformed(ActionEvent paramActionEvent)
  {
    if (this.analyzeRunState == true)
    {
      this.statusDisplay.setText("This action cannot be performed - the Analyzer is running!");
      return;
    }
    String str = JOptionPane.showInputDialog("Enter new name for this code set:", this.rootNode.toString());
    this.statusDisplay.setText("");
    this.progressBar.setValue(0);
    while (str.equals("New"))
    {
      str = JOptionPane.showInputDialog("Enter new name for this code set:", this.rootNode.toString());
      this.rootNode.rename(str);
    }
    TreePath localTreePath1 = this.codesetTree.getSelectionPath();
    TreePath localTreePath2 = new TreePath(this.rootNode);
    this.rootNode.rename(str);
    saveCodeSet();
    this.treeModel.fireTreeStructureChanged(localTreePath2);
    if (localTreePath1 != null) {
      this.treeModel.fireTreeStructureChanged(localTreePath1);
    }
  }
  
  private void lastSetsMenuItemActionPerformed(ActionEvent paramActionEvent)
  {
    if (this.analyzeRunState == true)
    {
      this.statusDisplay.setText("This action cannot be performed - the Analyzer is running!");
      return;
    }
    this.statusDisplay.setText("");
    this.progressBar.setValue(0);
    if (saveChangedCodeset(false))
    {
      String str = removeExtension(paramActionEvent.getActionCommand());
      loadCodeSet(str);
      updateResultsPane(null);
    }
  }
  
  private void menuExitActionPerformed(ActionEvent paramActionEvent)
  {
    if (this.analyzeRunState == true)
    {
      this.statusDisplay.setText("This action cannot be performed - the Analyzer is running!");
      return;
    }
    if (saveChangedCodeset(false))
    {
      saveProperties();
      System.exit(0);
    }
  }
  
  private void menuRunActionPerformed(ActionEvent paramActionEvent)
  {
    if (this.analyzeRunState == true)
    {
      this.statusDisplay.setText("This action cannot be performed - the Analyzer is running!");
      return;
    }
    this.statusDisplay.setText("");
    this.progressBar.setValue(0);
    if (this.extensionSet == null)
    {
      JOptionPane.showMessageDialog(null, "Cannot analyze - Extension Set not selected!", "Run Failed", 0);
      return;
    }
    this.statusDisplay.setText("Preparing for analysis...");
    this.rootNode.stats.clear();
    this.nodeExecuteType = 3;
    this.treeModel.traverseDepthFirst(this.rootNode, mainFrame);
    int i = this.rootNode.getCount();
    this.progressBarFileCount = 0;
    this.progressBar.setMaximum(i);
    this.progressBar.setValue(0);
    this.progressBar.setStringPainted(true);
    this.analyzeTreePath = this.codesetTree.getSelectionPath();
    if (this.analyzeTreePath == null) {
      this.analyzeTreePath = new TreePath(this.rootNode);
    }
    this.statusDisplay.setText("Analyzing " + this.rootNode.toString() + "...");
    this.codesetTree.setEnabled(false);
    SwingWorker local56 = new SwingWorker()
    {
      public Object construct()
      {
        MainFrame.this.analyzeRunState = true;
        MainFrame.this.nodeExecuteType = 2;
        MainFrame.this.treeModel.traverseDepthFirst(MainFrame.this.rootNode, MainFrame.mainFrame);
        return MainFrame.mainFrame;
      }
      
      public void finished()
      {
        FolderProcessor localFolderProcessor = new FolderProcessor(MainFrame.this.rootNode);
        localFolderProcessor.process();
        if (!MainFrame.this.analyzeRunState)
        {
          MainFrame.this.progressBar.setValue(0);
          MainFrame.this.nodeExecuteType = 3;
          MainFrame.this.treeModel.traverseDepthFirst(MainFrame.this.rootNode, MainFrame.mainFrame);
          MainFrame.this.statusDisplay.setText("Cancelling analysis...done.");
        }
        else
        {
          MainFrame.this.statusDisplay.setText("Analyzing " + MainFrame.this.rootNode.toString() + "...done.");
        }
        MainFrame.this.analyzeRunState = false;
        MainFrame.this.codesetTree.setEnabled(true);
        MainFrame.this.updateResultsPane((FileNode)MainFrame.this.analyzeTreePath.getLastPathComponent());
      }
    };
    local56.start();
  }
  
  private void menuStopActionPerformed(ActionEvent paramActionEvent)
  {
    this.analyzeRunState = false;
    this.statusDisplay.setText("Cancelling analysis...");
  }
  
  private void commentsAddTypeActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    this.progressBar.setValue(0);
    this.editCommentSetName = "";
    this.commSetNameDisplay.setText(this.editCommentSetName);
    this.commOpenDisplay.setText("");
    this.commEOLCheckBox.setSelected(false);
    this.commCloseDisplay.setText("");
    this.editCommentSetModel = new VectorListModel();
    this.commentList.setModel(this.editCommentSetModel);
    this.editCommentSetModel.fireContentsChanged();
    this.commOpenDisplay.setEnabled(false);
    this.commEOLCheckBox.setEnabled(false);
    this.commCloseDisplay.setEnabled(false);
    this.commSetNameDisplay.requestFocus();
    this.editCommentSetDialog.setTitle("Add New Comment Set");
    Dimension localDimension = Toolkit.getDefaultToolkit().getScreenSize();
    this.editCommentSetDialog.setBounds((localDimension.width - 380) / 2, (localDimension.height - 600) / 2, 380, 600);
    this.editCommentSetDialog.show();
  }
  
  private void commentDeleteMenuItemActionPerformed(ActionEvent paramActionEvent)
  {
    if (this.analyzeRunState == true)
    {
      this.statusDisplay.setText("This action cannot be performed - the Analyzer is running!");
      return;
    }
    String str = paramActionEvent.getActionCommand();
    this.statusDisplay.setText("");
    this.progressBar.setValue(0);
    for (int i = 0; i < this.commentSets.size(); i++) {
      if (str.equals(((CommentSet)this.commentSets.elementAt(i)).toString()))
      {
        if (i < this.lastDefaultCommentIndex)
        {
          JOptionPane.showMessageDialog(null, "Cannot delete default Comment Set", "Comment Set Delete Failed", 0);
          return;
        }
        int j = JOptionPane.showConfirmDialog(null, "Delete Comment Set " + str + "?", "Delete Comment Set?", 0);
        if (j == 0)
        {
          CommentSet localCommentSet = (CommentSet)this.commentSets.remove(i);
          updateCommentsDeleteMenu();
          updateCommentsEditMenu();
          this.statusDisplay.setText("Comment Set " + localCommentSet.toString() + " deleted");
        }
      }
    }
  }
  
  private void commentEditMenuItemActionPerformed(ActionEvent paramActionEvent)
  {
    if (this.analyzeRunState == true)
    {
      this.statusDisplay.setText("This action cannot be performed - the Analyzer is running!");
      return;
    }
    CommentSet localCommentSet = null;
    int i = 65535;
    this.statusDisplay.setText("");
    this.progressBar.setValue(0);
    this.editCommentSetName = paramActionEvent.getActionCommand();
    for (int j = 0; j < this.commentSets.size(); j++)
    {
      localCommentSet = (CommentSet)this.commentSets.elementAt(j);
      if (localCommentSet.toString().equals(this.editCommentSetName))
      {
        i = j;
        break;
      }
    }
    if (i == 65535)
    {
      JOptionPane.showMessageDialog(null, "Comment Set not found!", "Invalid Comment Set", 0);
      return;
    }
    if (i < this.lastDefaultCommentIndex)
    {
      JOptionPane.showMessageDialog(null, "Cannot edit default Comment Set", "Invalid Comment Set", 0);
      return;
    }
    this.commSetNameDisplay.setText(this.editCommentSetName);
    this.editCommentSetModel = new VectorListModel();
    this.commentList.setModel(this.editCommentSetModel);
    Vector localVector = localCommentSet.getCommentVector();
    for (int k = 0; k < localVector.size(); k++)
    {
      Comment localComment1 = (Comment)localVector.elementAt(k);
      Comment localComment2 = new Comment(localComment1);
      this.editCommentSetModel.add(localComment2);
    }
    this.editCommentSetModel.fireContentsChanged();
    this.commentList.setSelectedIndex(0);
    cdlgDisplayComment();
    this.editCommentSetDialog.setTitle("Edit Comment Set");
    Dimension localDimension = Toolkit.getDefaultToolkit().getScreenSize();
    this.editCommentSetDialog.setBounds((localDimension.width - 380) / 2, (localDimension.height - 600) / 2, 380, 600);
    this.editCommentSetDialog.show();
  }
  
  private void extensionsAddTypeActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    this.progressBar.setValue(0);
    this.editExtensionSetName = "";
    this.extSetNameDisplay.setText(this.editExtensionSetName);
    this.extensionDisplay.setText("");
    this.editExtensionSetModel = new VectorListModel();
    this.extensionList.setModel(this.editExtensionSetModel);
    this.editExtensionSetModel.fireContentsChanged();
    this.extensionDisplay.setEnabled(false);
    this.commSetComboBox.setEnabled(false);
    this.extSetNameDisplay.requestFocus();
    this.editExtensionSetDialog.setTitle("Add New Extension Set");
    Dimension localDimension = Toolkit.getDefaultToolkit().getScreenSize();
    this.editExtensionSetDialog.setBounds((localDimension.width - 480) / 2, (localDimension.height - 600) / 2, 480, 600);
    this.editExtensionSetDialog.show();
  }
  
  private void extensionDeleteMenuItemActionPerformed(ActionEvent paramActionEvent)
  {
    if (this.analyzeRunState == true)
    {
      this.statusDisplay.setText("This action cannot be performed - the Analyzer is running!");
      return;
    }
    String str = paramActionEvent.getActionCommand();
    this.statusDisplay.setText("");
    this.progressBar.setValue(0);
    for (int i = 0; i < this.extensionSets.size(); i++) {
      if (str.equals(((ExtensionSet)this.extensionSets.elementAt(i)).toString()))
      {
        if (i < this.lastDefaultExtensionIndex)
        {
          JOptionPane.showMessageDialog(null, "Cannot delete default Extension Set", "Extension Set Delete Failed", 0);
          return;
        }
        int j = JOptionPane.showConfirmDialog(null, "Delete Extension Set " + str + "?", "Delete Extension Set?", 0);
        if (j == 0)
        {
          ExtensionSet localExtensionSet = (ExtensionSet)this.extensionSets.remove(i);
          updateExtensionsDeleteMenu();
          updateExtensionsEditMenu();
          updateExtensionsSelectMenu();
          this.statusDisplay.setText("Extension Set " + localExtensionSet.toString() + " deleted");
        }
      }
    }
  }
  
  private void extensionEditMenuItemActionPerformed(ActionEvent paramActionEvent)
  {
    if (this.analyzeRunState == true)
    {
      this.statusDisplay.setText("This action cannot be performed - the Analyzer is running!");
      return;
    }
    ExtensionSet localExtensionSet = null;
    int i = 65535;
    this.statusDisplay.setText("");
    this.progressBar.setValue(0);
    this.editExtensionSetName = paramActionEvent.getActionCommand();
    for (int j = 0; j < this.extensionSets.size(); j++)
    {
      localExtensionSet = (ExtensionSet)this.extensionSets.elementAt(j);
      if (localExtensionSet.toString().equals(this.editExtensionSetName))
      {
        i = j;
        break;
      }
    }
    if (i == 65535)
    {
      JOptionPane.showMessageDialog(null, "Extension Set not found!", "Invalid Extension Set", 0);
      return;
    }
    if (i < this.lastDefaultExtensionIndex)
    {
      JOptionPane.showMessageDialog(null, "Cannot edit default Extension Set", "Invalid Extension Set", 0);
      return;
    }
    this.extSetNameDisplay.setText(this.editExtensionSetName);
    this.editExtensionSetModel = new VectorListModel();
    this.extensionList.setModel(this.editExtensionSetModel);
    Vector localVector = localExtensionSet.getExtensionVector();
    for (int k = 0; k < localVector.size(); k++)
    {
      Extension localExtension1 = (Extension)localVector.elementAt(k);
      Extension localExtension2 = new Extension(localExtension1);
      this.editExtensionSetModel.add(localExtension2);
    }
    this.editExtensionSetModel.fireContentsChanged();
    this.extensionList.setSelectedIndex(0);
    edlgDisplayExtension();
    this.editExtensionSetDialog.setTitle("Edit Extension Set");
    Dimension localDimension = Toolkit.getDefaultToolkit().getScreenSize();
    this.editExtensionSetDialog.setBounds((localDimension.width - 480) / 2, (localDimension.height - 600) / 2, 480, 600);
    this.editExtensionSetDialog.show();
  }
  
  private void extensionSelectMenuItemActionPerformed(ActionEvent paramActionEvent)
  {
    if (this.analyzeRunState == true)
    {
      this.statusDisplay.setText("This action cannot be performed - the Analyzer is running!");
      return;
    }
    String str1 = paramActionEvent.getActionCommand();
    this.statusDisplay.setText("");
    this.progressBar.setValue(0);
    for (int i = 0; i < this.extensionSets.size(); i++)
    {
      ExtensionSet localExtensionSet = (ExtensionSet)this.extensionSets.elementAt(i);
      int j = str1.indexOf(localExtensionSet.showContents());
      if ((j != -1) && (j >= 4))
      {
        String str2 = str1.substring(0, j - 3);
        String str3 = ((ExtensionSet)this.extensionSets.elementAt(i)).toString();
        if (str3.equals(str2))
        {
          this.extensionSet = new ExtensionSet((ExtensionSet)this.extensionSets.elementAt(i));
          this.extensionsDisplay.setText(this.extensionSet.toString() + "  (" + this.extensionSet.showContents() + ")");
          this.statusDisplay.setText("Extension Set " + str3 + " selected");
          TreePath localTreePath = this.codesetTree.getSelectionPath();
          if (localTreePath != null)
          {
            localFileNode = (FileNode)localTreePath.getLastPathComponent();
            if (localFileNode.isLeaf()) {
              localTreePath = localTreePath.getParentPath();
            }
          }
          else
          {
            localTreePath = new TreePath(this.rootNode);
          }
          FileNode localFileNode = (FileNode)localTreePath.getLastPathComponent();
          String str4 = localFileNode.getPath();
          String str5 = this.rootNode.toString();
          String[] arrayOfString = this.rootNode.list();
          this.progressBar.setMaximum(100);
          this.progressBar.setValue(0);
          this.progressBar.setStringPainted(false);
          this.rootNode = new FileNode(str5, arrayOfString, this.extensionSet, this.progressBar);
          this.progressBar.setValue(this.progressBar.getMaximum());
          this.treeModel = new CodeSetTreeModel(this.rootNode);
          this.codesetTree.setModel(this.treeModel);
          localTreePath = this.rootNode.findPath(str4);
          if (localTreePath == null) {
            localTreePath = new TreePath(this.rootNode);
          }
          this.treeModel.fireTreeStructureChanged(localTreePath);
          this.codesetTree.setSelectionPath(localTreePath);
          localFileNode = (FileNode)localTreePath.getLastPathComponent();
          updateResultsPane(localFileNode);
          this.codeSetChanged = true;
          return;
        }
      }
    }
  }
  
  private void cdlgDisplayComment()
  {
    if (this.editCommentSetModel.size() > 0)
    {
      Comment localComment = (Comment)this.commentList.getSelectedValue();
      if (localComment != null)
      {
        this.commOpenDisplay.setEnabled(true);
        this.commEOLCheckBox.setEnabled(true);
        this.commOpenDisplay.setText(localComment.getOpening());
        if (localComment.isEOL())
        {
          this.commEOLCheckBox.setSelected(true);
          this.commCloseDisplay.setText("");
          this.commCloseDisplay.setEnabled(false);
        }
        else
        {
          this.commEOLCheckBox.setSelected(false);
          this.commCloseDisplay.setText(localComment.getClosing());
          this.commCloseDisplay.setEnabled(true);
        }
        return;
      }
    }
    this.commOpenDisplay.setText("");
    this.commEOLCheckBox.setSelected(false);
    this.commCloseDisplay.setText("");
    this.commOpenDisplay.setEnabled(false);
    this.commEOLCheckBox.setEnabled(false);
    this.commCloseDisplay.setEnabled(false);
  }
  
  private boolean cdlgVerifyComment()
  {
    if (this.editCommentSetModel.size() > 0)
    {
      Comment localComment1 = (Comment)this.commentList.getSelectedValue();
      if (localComment1 != null)
      {
        if ((localComment1.getOpening().indexOf('.') != -1) || (localComment1.getOpening().indexOf(',') != -1) || (localComment1.getClosing().indexOf('.') != -1) || (localComment1.getClosing().indexOf(',') != -1))
        {
          JOptionPane.showMessageDialog(null, "Comment open/close cannot include a period or comma", "Invalid Comment", 0);
          localComment1.setOpening("OPEN");
          localComment1.setEOL(false);
          localComment1.setClosing("CLOSE");
          this.editCommentSetModel.fireContentsChanged();
          this.commOpenDisplay.setText(localComment1.getOpening());
          this.commEOLCheckBox.setSelected(false);
          this.commCloseDisplay.setText(localComment1.getClosing());
          this.commOpenDisplay.selectAll();
          this.commOpenDisplay.requestFocus();
          return false;
        }
        int i = this.commentList.getSelectedIndex();
        for (int j = 0; j < this.editCommentSetModel.size(); j++) {
          if (j != i)
          {
            Comment localComment2 = (Comment)this.editCommentSetModel.elementAt(j);
            if (localComment2.equals(localComment1))
            {
              JOptionPane.showMessageDialog(null, "Comment " + localComment1.toString() + " already exists", "Invalid Comment", 0);
              localComment1.setOpening("OPEN");
              localComment1.setEOL(false);
              localComment1.setClosing("CLOSE");
              this.editCommentSetModel.fireContentsChanged();
              this.commOpenDisplay.setText(localComment1.getOpening());
              this.commEOLCheckBox.setSelected(false);
              this.commCloseDisplay.setText(localComment1.getClosing());
              this.commOpenDisplay.selectAll();
              this.commOpenDisplay.requestFocus();
              return false;
            }
          }
        }
        return true;
      }
    }
    return true;
  }
  
  private void cdlgSetComment(String paramString1, boolean paramBoolean, String paramString2)
  {
    if (this.editCommentSetModel.size() > 0)
    {
      Comment localComment = (Comment)this.commentList.getSelectedValue();
      if (localComment != null)
      {
        if (paramString1 != null) {
          localComment.setOpening(paramString1);
        }
        if (paramBoolean)
        {
          localComment.setEOL(true);
          localComment.setClosing("");
        }
        else
        {
          localComment.setEOL(false);
          if (paramString2 != null) {
            localComment.setClosing(paramString2);
          }
        }
      }
    }
  }
  
  private Comment cdlgGetComment()
  {
    if (this.editCommentSetModel.size() > 0)
    {
      Comment localComment = (Comment)this.commentList.getSelectedValue();
      if (localComment != null) {
        return localComment;
      }
    }
    return null;
  }
  
  private void commentListValueChanged(ListSelectionEvent paramListSelectionEvent)
  {
    this.statusDisplay.setText("");
    cdlgDisplayComment();
  }
  
  private void addCommentButtonActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    cdlgSetComment(this.commOpenDisplay.getText(), this.commEOLCheckBox.isSelected(), this.commCloseDisplay.getText());
    if (!cdlgVerifyComment()) {
      return;
    }
    Comment localComment = cdlgGetComment();
    if ((localComment != null) && ((localComment.getOpening().equals("OPEN")) || ((!localComment.isEOL()) && (localComment.getClosing().equals("CLOSE")))))
    {
      JOptionPane.showMessageDialog(null, "Please complete the current comment definition before continuing", "Add Comment Failed", 0);
      if (localComment.getOpening().equals("OPEN"))
      {
        this.commOpenDisplay.selectAll();
        this.commOpenDisplay.requestFocus();
      }
      else
      {
        this.commCloseDisplay.selectAll();
        this.commCloseDisplay.requestFocus();
      }
      return;
    }
    localComment = new Comment("OPEN", "CLOSE", false);
    this.editCommentSetModel.add(localComment);
    this.editCommentSetModel.fireContentsChanged();
    this.commentList.setSelectedIndex(this.editCommentSetModel.size() - 1);
    this.commentList.ensureIndexIsVisible(this.editCommentSetModel.size() - 1);
    cdlgDisplayComment();
    this.commOpenDisplay.selectAll();
    this.commOpenDisplay.requestFocus();
  }
  
  private void delCommentButtonActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    if (this.editCommentSetModel.size() <= 0) {
      return;
    }
    int i = this.commentList.getSelectedIndex();
    this.editCommentSetModel.remove(i);
    this.editCommentSetModel.fireContentsChanged();
    if (this.editCommentSetModel.size() <= 0)
    {
      cdlgDisplayComment();
      return;
    }
    if (i != 0) {
      i--;
    }
    this.commentList.setSelectedIndex(i);
    cdlgDisplayComment();
  }
  
  private void commOpenDisplayActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    cdlgSetComment(this.commOpenDisplay.getText(), this.commEOLCheckBox.isSelected(), null);
    this.editCommentSetModel.fireContentsChanged();
    this.commEOLCheckBox.requestFocus();
  }
  
  private void commOpenDisplayFocusLost(FocusEvent paramFocusEvent)
  {
    this.statusDisplay.setText("");
    cdlgSetComment(this.commOpenDisplay.getText(), this.commEOLCheckBox.isSelected(), null);
    this.editCommentSetModel.fireContentsChanged();
  }
  
  private void commEOLCheckBoxActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    cdlgSetComment(null, this.commEOLCheckBox.isSelected(), null);
    this.editCommentSetModel.fireContentsChanged();
    cdlgDisplayComment();
    if (this.commEOLCheckBox.isSelected()) {
      this.commOpenDisplay.requestFocus();
    } else {
      this.commCloseDisplay.requestFocus();
    }
  }
  
  private void commCloseDisplayActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    cdlgSetComment(null, false, this.commCloseDisplay.getText());
    this.editCommentSetModel.fireContentsChanged();
    this.commOpenDisplay.requestFocus();
  }
  
  private void commCloseDisplayFocusLost(FocusEvent paramFocusEvent)
  {
    this.statusDisplay.setText("");
    cdlgSetComment(null, false, this.commCloseDisplay.getText());
    this.editCommentSetModel.fireContentsChanged();
  }
  
  private void commSetSaveButtonActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    if (!cdlgVerifyComment()) {
      return;
    }
    if (this.commSetNameDisplay.getText().equals(""))
    {
      JOptionPane.showMessageDialog(null, "Select a name for this Comment Set", "Save Comment Set Failed", 0);
      this.commSetNameDisplay.requestFocus();
      return;
    }
    for (int i = 0; i < this.commentSets.size(); i++)
    {
      CommentSet localCommentSet2 = (CommentSet)this.commentSets.elementAt(i);
      if (localCommentSet2.toString().equals(this.commSetNameDisplay.getText()))
      {
        JOptionPane.showMessageDialog(null, "This Comment Set name already exists", "Save Comment Set Failed", 0);
        this.commSetNameDisplay.requestFocus();
        return;
      }
    }
    CommentSet localCommentSet1 = new CommentSet(this.commSetNameDisplay.getText());
    for (int j = 0; j < this.editCommentSetModel.size(); j++)
    {
      Comment localComment = (Comment)this.editCommentSetModel.elementAt(j);
      localCommentSet1.add(localComment);
    }
    updateCommentsList(localCommentSet1);
    this.statusDisplay.setText("Comment Set " + this.commSetNameDisplay.getText() + " saved");
    this.editCommentSetDialog.hide();
  }
  
  private void commSetCancelButtonActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    this.editCommentSetDialog.hide();
  }
  
  private void edlgDisplayExtension()
  {
    if (this.editExtensionSetModel.size() > 0)
    {
      Extension localExtension = (Extension)this.extensionList.getSelectedValue();
      if (localExtension != null)
      {
        this.extensionDisplay.setEnabled(true);
        this.commSetComboBox.setEnabled(true);
        this.extensionDisplay.setText(localExtension.getExtension());
        this.commSetComboBox.setSelectedItem(localExtension.getCommentSet());
        return;
      }
    }
    this.extensionDisplay.setText("");
    this.commSetComboBox.setSelectedIndex(0);
    this.extensionDisplay.setEnabled(false);
    this.commSetComboBox.setEnabled(false);
  }
  
  private boolean edlgVerifyExtension()
  {
    if (this.editExtensionSetModel.size() > 0)
    {
      Extension localExtension1 = (Extension)this.extensionList.getSelectedValue();
      if (localExtension1 != null)
      {
        if ((localExtension1.getExtension().indexOf('.') != -1) || (localExtension1.getExtension().indexOf(',') != -1))
        {
          JOptionPane.showMessageDialog(null, "extension cannot have a period or comma", "Invalid Extension", 0);
          localExtension1.setExtension("New");
          this.editExtensionSetModel.fireContentsChanged();
          this.extensionDisplay.setText(localExtension1.getExtension());
          this.extensionDisplay.selectAll();
          this.extensionDisplay.requestFocus();
          return false;
        }
        int i = this.extensionList.getSelectedIndex();
        for (int j = 0; j < this.editExtensionSetModel.size(); j++) {
          if (j != i)
          {
            Extension localExtension2 = (Extension)this.editExtensionSetModel.elementAt(j);
            if (localExtension2.getExtension().equals(localExtension1.getExtension()))
            {
              JOptionPane.showMessageDialog(null, "Extension " + localExtension1.getExtension() + " already exists", "Invalid Extension", 0);
              localExtension1.setExtension("New");
              this.editExtensionSetModel.fireContentsChanged();
              this.extensionDisplay.setText(localExtension1.getExtension());
              this.extensionDisplay.selectAll();
              this.extensionDisplay.requestFocus();
              return false;
            }
          }
        }
        return true;
      }
    }
    return true;
  }
  
  private void edlgSetExtension(String paramString, CommentSet paramCommentSet)
  {
    if (this.editExtensionSetModel.size() > 0)
    {
      Extension localExtension = (Extension)this.extensionList.getSelectedValue();
      if (localExtension != null)
      {
        if (paramString != null) {
          localExtension.setExtension(paramString);
        }
        if (paramCommentSet != null) {
          localExtension.setCommentSet(paramCommentSet);
        }
      }
    }
  }
  
  private Extension edlgGetExtension()
  {
    if (this.editExtensionSetModel.size() > 0)
    {
      Extension localExtension = (Extension)this.extensionList.getSelectedValue();
      if (localExtension != null) {
        return localExtension;
      }
    }
    return null;
  }
  
  private void addExtensionButtonActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    if (!edlgVerifyExtension()) {
      return;
    }
    Extension localExtension = edlgGetExtension();
    if ((localExtension != null) && (localExtension.getExtension().equals("New")))
    {
      JOptionPane.showMessageDialog(null, "Please rename the current extension before continuing", "Add Extension Failed", 0);
      this.extensionDisplay.selectAll();
      this.extensionDisplay.requestFocus();
      return;
    }
    CommentSet localCommentSet = (CommentSet)this.commSetComboBox.getItemAt(0);
    localExtension = new Extension("New", localCommentSet);
    this.editExtensionSetModel.add(localExtension);
    this.editExtensionSetModel.fireContentsChanged();
    this.extensionList.setSelectedIndex(this.editExtensionSetModel.size() - 1);
    this.extensionList.ensureIndexIsVisible(this.editExtensionSetModel.size() - 1);
    edlgDisplayExtension();
    this.extensionDisplay.selectAll();
    this.extensionDisplay.requestFocus();
  }
  
  private void delExtensionButtonActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    if (this.editExtensionSetModel.size() <= 0) {
      return;
    }
    int i = this.extensionList.getSelectedIndex();
    this.editExtensionSetModel.remove(i);
    this.editExtensionSetModel.fireContentsChanged();
    if (this.editExtensionSetModel.size() <= 0)
    {
      edlgDisplayExtension();
      return;
    }
    if (i != 0) {
      i--;
    }
    this.extensionList.setSelectedIndex(i);
    edlgDisplayExtension();
  }
  
  private void addFromExtMenuItemActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    String str = paramActionEvent.getActionCommand();
    Object localObject = null;
    for (int i = 0; i < this.extensionSets.size(); i++)
    {
      ExtensionSet localExtensionSet = (ExtensionSet)this.extensionSets.elementAt(i);
      if (localExtensionSet.toString().equals(str))
      {
        localObject = localExtensionSet;
        break;
      }
    }
    if (localObject == null) {
      return;
    }
    Vector localVector = localObject.getExtensionVector();
    for (int j = 0; j < localVector.size(); j++)
    {
      Extension localExtension1 = (Extension)localVector.elementAt(j);
      if (!this.editExtensionSetModel.contains(localExtension1))
      {
        Extension localExtension2 = new Extension(localExtension1);
        this.editExtensionSetModel.add(localExtension2);
      }
    }
    this.editExtensionSetModel.fireContentsChanged();
    this.extensionList.setSelectedIndex(this.editExtensionSetModel.size() - 1);
    this.extensionList.ensureIndexIsVisible(this.editExtensionSetModel.size() - 1);
    edlgDisplayExtension();
  }
  
  private void addFromExistingButtonActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    if (!edlgVerifyExtension()) {
      return;
    }
    Extension localExtension = edlgGetExtension();
    if ((localExtension != null) && (localExtension.getExtension().equals("New")))
    {
      JOptionPane.showMessageDialog(null, "Please rename the current extension before continuing", "Add Extension Failed", 0);
      this.extensionDisplay.selectAll();
      this.extensionDisplay.requestFocus();
      return;
    }
    JPopupMenu localJPopupMenu = new JPopupMenu();
    for (int i = 0; i < this.extensionSets.size(); i++)
    {
      JMenuItem localJMenuItem = new JMenuItem();
      ExtensionSet localExtensionSet = (ExtensionSet)this.extensionSets.elementAt(i);
      localJMenuItem.setText(localExtensionSet.toString());
      localJMenuItem.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          MainFrame.this.addFromExtMenuItemActionPerformed(paramAnonymousActionEvent);
        }
      });
      localJPopupMenu.add(localJMenuItem);
    }
    localJPopupMenu.show(this.addFromExistingButton, this.addFromExistingButton.getWidth() - 20, this.addFromExistingButton.getHeight() - 20);
  }
  
  private void extensionListValueChanged(ListSelectionEvent paramListSelectionEvent)
  {
    this.statusDisplay.setText("");
    edlgDisplayExtension();
  }
  
  private void extensionDisplayActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    edlgSetExtension(this.extensionDisplay.getText(), null);
    this.editExtensionSetModel.fireContentsChanged();
    if (edlgVerifyExtension()) {
      this.commSetComboBox.requestFocus();
    }
  }
  
  private void extensionDisplayFocusLost(FocusEvent paramFocusEvent)
  {
    if (!edlgVerifyExtension()) {
      return;
    }
    edlgSetExtension(this.extensionDisplay.getText(), null);
    this.editExtensionSetModel.fireContentsChanged();
  }
  
  private void commSetComboBoxActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    if (!edlgVerifyExtension()) {
      return;
    }
    CommentSet localCommentSet = (CommentSet)this.commSetComboBox.getSelectedItem();
    if (localCommentSet != null) {
      edlgSetExtension(null, localCommentSet);
    }
  }
  
  private void saveButtonActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    if (!edlgVerifyExtension()) {
      return;
    }
    if (this.extSetNameDisplay.getText().equals(""))
    {
      JOptionPane.showMessageDialog(null, "Select a name for this Extension Set", "Save Extension Set Failed", 0);
      this.extSetNameDisplay.requestFocus();
      return;
    }
    for (int i = 0; i < this.extensionSets.size(); i++)
    {
      ExtensionSet localExtensionSet2 = (ExtensionSet)this.extensionSets.elementAt(i);
      if (localExtensionSet2.toString().equals(this.extSetNameDisplay.getText()))
      {
        JOptionPane.showMessageDialog(null, "This Extension Set name already exists", "Save Extension Set Failed", 0);
        return;
      }
    }
    ExtensionSet localExtensionSet1 = new ExtensionSet(this.extSetNameDisplay.getText());
    for (int j = 0; j < this.editExtensionSetModel.size(); j++)
    {
      Extension localExtension = (Extension)this.editExtensionSetModel.elementAt(j);
      localExtensionSet1.add(localExtension);
    }
    updateExtensionsList(localExtensionSet1);
    this.statusDisplay.setText("Extension Set " + this.extSetNameDisplay.getText() + " saved");
    this.editExtensionSetDialog.hide();
  }
  
  private void cancelButtonActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    this.editExtensionSetDialog.hide();
  }
  
  private File reportsMenuGetFilename(String paramString)
  {
    String str1 = System.getProperty("user.home") + "/" + ".codeanalyzer";
    JFileChooser localJFileChooser = new JFileChooser(str1);
    localJFileChooser.setFileSelectionMode(0);
    localJFileChooser.setDialogTitle("Select Report File");
    localJFileChooser.setMultiSelectionEnabled(false);
    HashFileFilter localHashFileFilter = new HashFileFilter();
    localHashFileFilter.addExtension(paramString);
    localHashFileFilter.setDescription("Report Files");
    localJFileChooser.setFileFilter(localHashFileFilter);
    int i = localJFileChooser.showOpenDialog(this);
    if (i == 0)
    {
      Object localObject = localJFileChooser.getSelectedFile();
      String str2 = ((File)localObject).getName();
      if (!str2.endsWith("." + paramString))
      {
        str2 = str2.concat("." + paramString);
        File localFile = new File(((File)localObject).getParent(), str2);
        localObject = localFile;
      }
      if (!((File)localObject).exists()) {
        try
        {
          ((File)localObject).createNewFile();
        }
        catch (IOException localIOException) {}
      }
      return localObject;
    }
    return null;
  }
  
  private void menuReportFileActionPerformed(ActionEvent paramActionEvent)
  {
    if (this.analyzeRunState == true)
    {
      this.statusDisplay.setText("This action cannot be performed - the Analyzer is running!");
      return;
    }
    this.statusDisplay.setText("");
    TreePath localTreePath = this.codesetTree.getSelectionPath();
    FileNode localFileNode;
    if ((localTreePath == null) || ((localFileNode = (FileNode)localTreePath.getLastPathComponent()) == null))
    {
      JOptionPane.showMessageDialog(null, "No File/Directory selected in Code Set browser", "Create Report Failed", 0);
      return;
    }
    File localFile = reportsMenuGetFilename("txt");
    if (localFile == null) {
      return;
    }
    try
    {
      FileWriter localFileWriter = new FileWriter(localFile);
      localFileNode.stats.writeToFile(localFileWriter, localFileNode.toString());
      localFileWriter.close();
      this.statusDisplay.setText("Report " + localFile.toString() + " generated");
    }
    catch (IOException localIOException) {}
  }
  
  private void menuReportSummaryActionPerformed(ActionEvent paramActionEvent)
  {
    int i = this.rootNode.getChildCount();
    if (this.analyzeRunState == true)
    {
      this.statusDisplay.setText("This action cannot be performed - the Analyzer is running!");
      return;
    }
    this.statusDisplay.setText("");
    File localFile = reportsMenuGetFilename("txt");
    if (localFile == null) {
      return;
    }
    try
    {
      FileWriter localFileWriter = new FileWriter(localFile);
      Vector localVector = this.extensionSet.getExtensionVector();
      Object localObject;
      for (int j = 0; j < i; j++)
      {
        localObject = this.rootNode.getChild(j);
        if (((FileNode)localObject).extStats.length >= localVector.size()) {
          for (int k = 0; k < localVector.size(); k++)
          {
            Extension localExtension = (Extension)localVector.elementAt(k);
            localObject.extStats[k].writeToFile(localFileWriter, ((FileNode)localObject).toString() + " - " + localExtension.toString());
          }
        }
        ((FileNode)localObject).stats.writeToFile(localFileWriter, ((FileNode)localObject).toString() + " - Cumulative");
      }
      for (j = 0; j < localVector.size(); j++)
      {
        localObject = (Extension)localVector.elementAt(j);
        this.rootNode.extStats[j].writeToFile(localFileWriter, "Code Set " + this.rootNode.toString() + " - " + ((Extension)localObject).toString());
      }
      this.rootNode.stats.writeToFile(localFileWriter, "Code Set " + this.rootNode.toString() + " -  Cumulative");
      localFileWriter.write("\n");
      localFileWriter.close();
      this.statusDisplay.setText("Report " + localFile.toString() + " generated");
    }
    catch (IOException localIOException) {}
  }
  
  private void menuReportAllHTMLActionPerformed(ActionEvent paramActionEvent)
  {
    boolean bool = true;
    if (this.analyzeRunState == true)
    {
      this.statusDisplay.setText("This action cannot be performed - the Analyzer is running!");
      return;
    }
    this.statusDisplay.setText("");
    File localFile = reportsMenuGetFilename("html");
    if (localFile == null) {
      return;
    }
    Object[] arrayOfObject = { "Folders Only", "Files and Folders" };
    Object localObject = JOptionPane.showInputDialog(null, "Do you want to include all files?", "Define Report", 1, null, arrayOfObject, arrayOfObject[0]);
    if (localObject.equals(arrayOfObject[1])) {
      bool = false;
    }
    try
    {
      FileWriter localFileWriter = new FileWriter(localFile);
      Date localDate = new Date();
      localFileWriter.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\r\n");
      localFileWriter.write("<html>\r\n");
      localFileWriter.write("<head>\r\n");
      localFileWriter.write("<title>Code Analyzer Report: " + this.rootNode.toString() + " on " + localDate.toString() + "</title>\r\n");
      localFileWriter.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">\r\n");
      localFileWriter.write("</head>\r\n");
      localFileWriter.write("<body bgcolor=\"#E2E2C7\">\r\n");
      localFileWriter.write("<table width=\"98%\" border=\"2\" align=\"center\">\r\n");
      localFileWriter.write("  <tr>\r\n");
      localFileWriter.write("    <td>\r\n");
      localFileWriter.write("      <table width=\"100%\" border=\"0\" align=\"center\" bgcolor=\"#00008C\">\r\n");
      localFileWriter.write("        <tr>\r\n");
      localFileWriter.write("          <td width=\"50%\"><font color=\"#CCFFCC\" size=\"5\">Code Analyzer " + AboutDlg.versionString + "</font></td>\r\n");
      localFileWriter.write("        </tr>\r\n");
      localFileWriter.write("        <tr>\r\n");
      localFileWriter.write("          <td width=\"50%\"><font color=\"#CCFFCC\" size=\"5\">Report for Code Set:</font></td>\r\n");
      localFileWriter.write("          <td width=\"50%\"><font color=\"#CCFFCC\" size=\"5\">" + this.rootNode.toString() + "</font></td>\r\n");
      localFileWriter.write("        </tr>\r\n");
      localFileWriter.write("        <tr>\r\n");
      localFileWriter.write("          <td width=\"50%\"><font color=\"#CCFFCC\" size=\"5\">Extension Set:</font></td>\r\n");
      localFileWriter.write("          <td width=\"50%\"><font color=\"#CCFFCC\" size=\"5\">" + this.extensionSet.toString() + "</font></td>\r\n");
      localFileWriter.write("        </tr>\r\n");
      localFileWriter.write("        <tr>\r\n");
      localFileWriter.write("          <td width=\"50%\"><font color=\"#CCFFCC\" size=\"5\">Date:</font></td>\r\n");
      localFileWriter.write("          <td width=\"50%\"><font color=\"#CCFFCC\" size=\"5\">" + localDate.toString() + "</font></td>\r\n");
      localFileWriter.write("        </tr>\r\n");
      String str;
      if (bool) {
        str = "Folders Only";
      } else {
        str = "Files and Folders";
      }
      localFileWriter.write("        <tr>\r\n");
      localFileWriter.write("          <td width=\"50%\"><font color=\"#CCFFCC\" size=\"5\">Displaying:</font></td>\r\n");
      localFileWriter.write("          <td width=\"50%\"><font color=\"#CCFFCC\" size=\"5\">" + str + "</font></td>\r\n");
      localFileWriter.write("        </tr>\r\n");
      localFileWriter.write("      </table>\r\n");
      localFileWriter.write("    </td>\r\n");
      localFileWriter.write("  </tr>\r\n");
      localFileWriter.write("  <tr>\r\n");
      localFileWriter.write("    <td>\r\n");
      localFileWriter.write("      <table width=\"100%\" border=\"1\" bgcolor=\"#CAFFFF\" align=\"center\">\r\n");
      Stats.writeHTMLHdrToFile(localFileWriter, "File Name");
      localFileWriter.write("        <tr>\r\n");
      localFileWriter.write("          <td colspan=\"14\">\r\n");
      localFileWriter.write("            <hr color=\"#000080\">\r\n");
      localFileWriter.write("          </td>\r\n");
      localFileWriter.write("        </tr>\r\n");
      this.rootNode.getClass();
      this.rootNode.recursivePrintToFile(localFileWriter, 2, bool);
      localFileWriter.write("      </table>\r\n");
      localFileWriter.write("    </td>\r\n");
      localFileWriter.write("  </tr>\r\n");
      localFileWriter.write("</table>\r\n");
      localFileWriter.write("</body>\r\n");
      localFileWriter.write("</html>\r\n");
      localFileWriter.close();
    }
    catch (IOException localIOException) {}
  }
  
  private void menuReportAllCommaDelimActionPerformed(ActionEvent paramActionEvent)
  {
    boolean bool = true;
    if (this.analyzeRunState == true)
    {
      this.statusDisplay.setText("This action cannot be performed - the Analyzer is running!");
      return;
    }
    this.statusDisplay.setText("");
    File localFile = reportsMenuGetFilename("csv");
    if (localFile == null) {
      return;
    }
    Object[] arrayOfObject = { "Folders Only", "Files and Folders" };
    Object localObject = JOptionPane.showInputDialog(null, "Do you want to include all files?", "Define Report", 1, null, arrayOfObject, arrayOfObject[0]);
    if (localObject.equals(arrayOfObject[1])) {
      bool = false;
    }
    try
    {
      FileWriter localFileWriter = new FileWriter(localFile);
      localFileWriter.write("#File Name,");
      Stats.writeCommaDelimHdrToFile(localFileWriter);
      localFileWriter.write("\r\n");
      this.rootNode.getClass();
      this.rootNode.recursivePrintToFile(localFileWriter, 1, bool);
      localFileWriter.close();
    }
    catch (IOException localIOException) {}
  }
  
  private void menuReportAllTextActionPerformed(ActionEvent paramActionEvent)
  {
    boolean bool = true;
    if (this.analyzeRunState == true)
    {
      this.statusDisplay.setText("This action cannot be performed - the Analyzer is running!");
      return;
    }
    this.statusDisplay.setText("");
    File localFile = reportsMenuGetFilename("txt");
    if (localFile == null) {
      return;
    }
    Object[] arrayOfObject = { "Folders Only", "Files and Folders" };
    Object localObject = JOptionPane.showInputDialog(null, "Do you want to include all files?", "Define Report", 1, null, arrayOfObject, arrayOfObject[0]);
    if (localObject.equals(arrayOfObject[1])) {
      bool = false;
    }
    try
    {
      FileWriter localFileWriter = new FileWriter(localFile);
      localFileWriter.write("#######################################################################\r\n");
      localFileWriter.write("# Code Analyzer " + AboutDlg.versionString + "\r\n");
      localFileWriter.write("# Report for Code Set: " + this.rootNode.toString() + "\r\n");
      localFileWriter.write("# Extension Set      : " + this.extensionSet.toString() + "\r\n");
      Date localDate = new Date();
      localFileWriter.write("# Date               : " + localDate.toString() + "\r\n");
      if (bool) {
        localFileWriter.write("# Displaying         : Folders Only\r\n");
      } else {
        localFileWriter.write("# Displaying         : Files and Folders\r\n");
      }
      localFileWriter.write("#######################################################################\r\n\r\n");
      localFileWriter.write("File Name                          ");
      Stats.writeTextHdrToFile(localFileWriter, false);
      localFileWriter.write("\r\n");
      localFileWriter.write("--------------------------------   ");
      Stats.writeTextHdrToFile(localFileWriter, true);
      localFileWriter.write("\r\n");
      this.rootNode.getClass();
      this.rootNode.recursivePrintToFile(localFileWriter, 3, bool);
      localFileWriter.close();
    }
    catch (IOException localIOException) {}
  }
  
  private void menuHelpActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    this.progressBar.setValue(0);
    HelpHTML localHelpHTML = new HelpHTML("help.html");
  }
  
  private void menuAboutActionPerformed(ActionEvent paramActionEvent)
  {
    this.statusDisplay.setText("");
    this.progressBar.setValue(0);
    AboutDlg localAboutDlg = new AboutDlg(this);
  }
  
  private void exitForm(WindowEvent paramWindowEvent)
  {
    saveChangedCodeset(true);
    saveProperties();
    System.exit(0);
  }
  
  public static void main(String[] paramArrayOfString)
  {
    mainFrame = new MainFrame();
    mainFrame.show();
    mainFrame.loadLastCodeset();
  }
}


/* Location:           C:\Users\Usuario\Downloads\CodeAnalyzer-0.7.0.jar
 * Qualified Name:     MainFrame.MainFrame
 * JD-Core Version:    0.7.0.1
 */