package AboutDialog;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;

public class AboutDlg
  extends JDialog
{
  public static String versionString = "0.7.0";
  private JButton OKButton;
  private JLabel copyrightLabel;
  private JLabel titleLabel;
  private JLabel versionLabel;
  
  public AboutDlg(Frame paramFrame)
  {
    initComponents();
    this.titleLabel.setText("Code Analyzer");
    this.versionLabel.setText("Version " + versionString);
    this.copyrightLabel.setText("Copyright (c) 2004-2005, M.S. Teel");
    setVisible(true);
    show();
  }
  
  private void initComponents()
  {
    this.titleLabel = new JLabel();
    this.versionLabel = new JLabel();
    this.OKButton = new JButton();
    this.copyrightLabel = new JLabel();
    getContentPane().setLayout(new GridBagLayout());
    setDefaultCloseOperation(2);
    setTitle("About Code Analyzer");
    setName("About Code Analyzer");
    setResizable(false);
    addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent paramAnonymousWindowEvent)
      {
        AboutDlg.this.closeDialog(paramAnonymousWindowEvent);
      }
    });
    this.titleLabel.setFont(new Font("Century", 1, 24));
    this.titleLabel.setHorizontalAlignment(0);
    this.titleLabel.setText("Code Analyzer");
    this.titleLabel.setHorizontalTextPosition(0);
    GridBagConstraints localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 0;
    localGridBagConstraints.ipadx = 240;
    localGridBagConstraints.ipady = 30;
    localGridBagConstraints.anchor = 15;
    localGridBagConstraints.insets = new Insets(50, 64, 25, 64);
    getContentPane().add(this.titleLabel, localGridBagConstraints);
    this.versionLabel.setHorizontalAlignment(0);
    this.versionLabel.setText("VERSION");
    this.versionLabel.setAlignmentX(0.5F);
    this.versionLabel.setMaximumSize(new Dimension(80, 20));
    this.versionLabel.setMinimumSize(new Dimension(80, 20));
    this.versionLabel.setPreferredSize(new Dimension(80, 20));
    this.versionLabel.setHorizontalTextPosition(0);
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 1;
    localGridBagConstraints.ipadx = 140;
    localGridBagConstraints.anchor = 15;
    localGridBagConstraints.insets = new Insets(36, 0, 20, 0);
    getContentPane().add(this.versionLabel, localGridBagConstraints);
    this.OKButton.setText("OK");
    this.OKButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        AboutDlg.this.OKButtonActionPerformed(paramAnonymousActionEvent);
      }
    });
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 4;
    localGridBagConstraints.anchor = 15;
    localGridBagConstraints.insets = new Insets(60, 14, 34, 14);
    getContentPane().add(this.OKButton, localGridBagConstraints);
    this.copyrightLabel.setHorizontalAlignment(0);
    this.copyrightLabel.setText("COPY");
    this.copyrightLabel.setAlignmentX(0.5F);
    this.copyrightLabel.setMaximumSize(new Dimension(80, 20));
    this.copyrightLabel.setMinimumSize(new Dimension(80, 20));
    this.copyrightLabel.setPreferredSize(new Dimension(80, 20));
    this.copyrightLabel.setHorizontalTextPosition(0);
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 2;
    localGridBagConstraints.gridheight = 2;
    localGridBagConstraints.ipadx = 280;
    localGridBagConstraints.insets = new Insets(16, 0, 0, 0);
    getContentPane().add(this.copyrightLabel, localGridBagConstraints);
    Dimension localDimension = Toolkit.getDefaultToolkit().getScreenSize();
    setBounds((localDimension.width - 437) / 2, (localDimension.height - 339) / 2, 437, 339);
  }
  
  private void OKButtonActionPerformed(ActionEvent paramActionEvent)
  {
    dispose();
  }
  
  private void closeDialog(WindowEvent paramWindowEvent)
  {
    dispose();
  }
}


/* Location:           C:\Users\Usuario\Downloads\CodeAnalyzer-0.7.0.jar
 * Qualified Name:     AboutDialog.AboutDlg
 * JD-Core Version:    0.7.0.1
 */