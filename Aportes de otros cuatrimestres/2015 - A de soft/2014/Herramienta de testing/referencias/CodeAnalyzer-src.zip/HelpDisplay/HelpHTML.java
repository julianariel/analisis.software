package HelpDisplay;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.URL;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkEvent.EventType;
import javax.swing.event.HyperlinkListener;

public class HelpHTML
  extends JDialog
{
  private JEditorPane htmlEditorPane;
  private JLabel jLabel1;
  private JScrollPane jScrollPane1;
  private JButton okButton;
  
  public HelpHTML(String paramString)
  {
    initComponents();
    initValues(paramString);
    show();
  }
  
  private void initValues(String paramString)
  {
    URL localURL = HelpHTML.class.getResource(paramString);
    this.jLabel1.setText(paramString);
    this.htmlEditorPane.setContentType("text/html");
    try
    {
      this.htmlEditorPane.setPage(localURL);
    }
    catch (IOException localIOException) {}
  }
  
  private void initComponents()
  {
    this.jLabel1 = new JLabel();
    this.jScrollPane1 = new JScrollPane();
    this.htmlEditorPane = new JEditorPane();
    this.okButton = new JButton();
    getContentPane().setLayout(new GridBagLayout());
    setDefaultCloseOperation(2);
    setTitle("Help");
    addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent paramAnonymousWindowEvent)
      {
        HelpHTML.this.exitForm(paramAnonymousWindowEvent);
      }
    });
    this.jLabel1.setFont(new Font("Dialog", 1, 14));
    this.jLabel1.setHorizontalAlignment(0);
    this.jLabel1.setText("Help File Name");
    this.jLabel1.setMaximumSize(new Dimension(360, 16));
    this.jLabel1.setMinimumSize(new Dimension(180, 16));
    this.jLabel1.setPreferredSize(new Dimension(180, 16));
    GridBagConstraints localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.insets = new Insets(12, 0, 10, 0);
    getContentPane().add(this.jLabel1, localGridBagConstraints);
    this.jScrollPane1.setMinimumSize(new Dimension(800, 700));
    this.jScrollPane1.setPreferredSize(new Dimension(800, 700));
    this.htmlEditorPane.setEditable(false);
    this.htmlEditorPane.addHyperlinkListener(new HyperlinkListener()
    {
      public void hyperlinkUpdate(HyperlinkEvent paramAnonymousHyperlinkEvent)
      {
        HelpHTML.this.htmlEditorPaneHyperlinkUpdate(paramAnonymousHyperlinkEvent);
      }
    });
    this.jScrollPane1.setViewportView(this.htmlEditorPane);
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 1;
    localGridBagConstraints.fill = 1;
    localGridBagConstraints.weightx = 0.92D;
    localGridBagConstraints.weighty = 0.92D;
    localGridBagConstraints.insets = new Insets(12, 0, 20, 0);
    getContentPane().add(this.jScrollPane1, localGridBagConstraints);
    this.okButton.setText("OK");
    this.okButton.setMaximumSize(new Dimension(100, 26));
    this.okButton.setMinimumSize(new Dimension(100, 26));
    this.okButton.setPreferredSize(new Dimension(100, 26));
    this.okButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        HelpHTML.this.okButtonActionPerformed(paramAnonymousActionEvent);
      }
    });
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 2;
    localGridBagConstraints.insets = new Insets(8, 0, 16, 0);
    getContentPane().add(this.okButton, localGridBagConstraints);
    Dimension localDimension = Toolkit.getDefaultToolkit().getScreenSize();
    setBounds((localDimension.width - 892) / 2, (localDimension.height - 800) / 2, 892, 800);
  }
  
  private void htmlEditorPaneHyperlinkUpdate(HyperlinkEvent paramHyperlinkEvent)
  {
    if (paramHyperlinkEvent.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
      try
      {
        this.htmlEditorPane.setPage(paramHyperlinkEvent.getURL());
      }
      catch (Throwable localThrowable)
      {
        localThrowable.printStackTrace();
      }
    }
  }
  
  private void okButtonActionPerformed(ActionEvent paramActionEvent)
  {
    dispose();
  }
  
  private void exitForm(WindowEvent paramWindowEvent)
  {
    dispose();
  }
}


/* Location:           C:\Users\Usuario\Downloads\CodeAnalyzer-0.7.0.jar
 * Qualified Name:     HelpDisplay.HelpHTML
 * JD-Core Version:    0.7.0.1
 */