package ResultsDisplay;

import CodeAnalysis.Stats;
import CodeSetTreeModel.FileNode;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class AnalyzerResults
  extends JPanel
{
  private FileNode fileNode = null;
  private int type = -1;
  private JTextField codeLinesDisplay;
  private JProgressBar codeLinesProgressBar;
  private JTextField commentLinesDisplay;
  private JProgressBar commentLinesProgressBar;
  private JLabel jLabel1;
  private JLabel jLabel2;
  private JLabel jLabel3;
  private JLabel jLabel4;
  private JLabel jLabel5;
  private JSeparator jSeparator1;
  private JTextArea resultsTextArea;
  private JTextField totalLinesDisplay;
  private JProgressBar totalLinesProgressBar;
  private JTextField wsLinesDisplay;
  private JProgressBar wsLinesProgressBar;
  
  public AnalyzerResults(FileNode paramFileNode, int paramInt)
  {
    this.fileNode = paramFileNode;
    this.type = paramInt;
    initComponents();
    initValues();
    show();
  }
  
  private void initValues()
  {
    this.jLabel1.setText("Results for " + this.fileNode.toString());
    Stats localStats;
    if (this.type == -1) {
      localStats = this.fileNode.stats;
    } else {
      localStats = this.fileNode.extStats[this.type];
    }
    this.totalLinesProgressBar.setMinimum(0);
    this.totalLinesProgressBar.setMaximum(localStats.get(Stats.TOTAL_LINES));
    this.totalLinesProgressBar.setStringPainted(true);
    this.totalLinesProgressBar.setValue(localStats.get(Stats.TOTAL_LINES));
    this.totalLinesDisplay.setText("" + localStats.get(Stats.TOTAL_LINES));
    this.codeLinesProgressBar.setMinimum(0);
    this.codeLinesProgressBar.setMaximum(localStats.get(Stats.TOTAL_LINES));
    this.codeLinesProgressBar.setStringPainted(true);
    this.codeLinesProgressBar.setValue(localStats.get(Stats.CODE));
    this.codeLinesDisplay.setText("" + localStats.get(Stats.CODE));
    this.commentLinesProgressBar.setMinimum(0);
    this.commentLinesProgressBar.setMaximum(localStats.get(Stats.TOTAL_LINES));
    this.commentLinesProgressBar.setStringPainted(true);
    this.commentLinesProgressBar.setValue(localStats.get(Stats.COMMENTS));
    this.commentLinesDisplay.setText("" + localStats.get(Stats.COMMENTS));
    this.wsLinesProgressBar.setMinimum(0);
    this.wsLinesProgressBar.setMaximum(localStats.get(Stats.TOTAL_LINES));
    this.wsLinesProgressBar.setStringPainted(true);
    this.wsLinesProgressBar.setValue(localStats.get(Stats.WHITESPACE));
    this.wsLinesDisplay.setText("" + localStats.get(Stats.WHITESPACE));
    localStats.display(this.resultsTextArea);
  }
  
  private void initComponents()
  {
    this.totalLinesProgressBar = new JProgressBar();
    this.codeLinesProgressBar = new JProgressBar();
    this.commentLinesProgressBar = new JProgressBar();
    this.wsLinesProgressBar = new JProgressBar();
    this.jLabel1 = new JLabel();
    this.jLabel2 = new JLabel();
    this.jLabel3 = new JLabel();
    this.jLabel4 = new JLabel();
    this.jLabel5 = new JLabel();
    this.jSeparator1 = new JSeparator();
    this.resultsTextArea = new JTextArea();
    this.totalLinesDisplay = new JTextField();
    this.codeLinesDisplay = new JTextField();
    this.commentLinesDisplay = new JTextField();
    this.wsLinesDisplay = new JTextField();
    setLayout(new GridBagLayout());
    this.totalLinesProgressBar.setForeground(new Color(102, 102, 255));
    this.totalLinesProgressBar.setOrientation(1);
    this.totalLinesProgressBar.setBorder(null);
    this.totalLinesProgressBar.setMaximumSize(new Dimension(20, 100));
    this.totalLinesProgressBar.setMinimumSize(new Dimension(20, 100));
    this.totalLinesProgressBar.setPreferredSize(new Dimension(20, 100));
    GridBagConstraints localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 1;
    localGridBagConstraints.insets = new Insets(0, 42, 0, 42);
    add(this.totalLinesProgressBar, localGridBagConstraints);
    this.codeLinesProgressBar.setForeground(new Color(102, 102, 255));
    this.codeLinesProgressBar.setOrientation(1);
    this.codeLinesProgressBar.setBorder(null);
    this.codeLinesProgressBar.setMaximumSize(new Dimension(20, 100));
    this.codeLinesProgressBar.setMinimumSize(new Dimension(20, 100));
    this.codeLinesProgressBar.setPreferredSize(new Dimension(20, 100));
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 1;
    localGridBagConstraints.gridy = 1;
    localGridBagConstraints.insets = new Insets(0, 42, 0, 42);
    add(this.codeLinesProgressBar, localGridBagConstraints);
    this.commentLinesProgressBar.setForeground(new Color(102, 102, 255));
    this.commentLinesProgressBar.setOrientation(1);
    this.commentLinesProgressBar.setBorder(null);
    this.commentLinesProgressBar.setMaximumSize(new Dimension(20, 100));
    this.commentLinesProgressBar.setMinimumSize(new Dimension(20, 100));
    this.commentLinesProgressBar.setPreferredSize(new Dimension(20, 100));
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 2;
    localGridBagConstraints.gridy = 1;
    localGridBagConstraints.insets = new Insets(0, 42, 0, 42);
    add(this.commentLinesProgressBar, localGridBagConstraints);
    this.wsLinesProgressBar.setForeground(new Color(102, 102, 255));
    this.wsLinesProgressBar.setOrientation(1);
    this.wsLinesProgressBar.setBorder(null);
    this.wsLinesProgressBar.setMaximumSize(new Dimension(20, 100));
    this.wsLinesProgressBar.setMinimumSize(new Dimension(20, 100));
    this.wsLinesProgressBar.setPreferredSize(new Dimension(20, 100));
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 3;
    localGridBagConstraints.gridy = 1;
    localGridBagConstraints.insets = new Insets(0, 42, 0, 42);
    add(this.wsLinesProgressBar, localGridBagConstraints);
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridwidth = 0;
    localGridBagConstraints.insets = new Insets(12, 0, 16, 0);
    add(this.jLabel1, localGridBagConstraints);
    this.jLabel2.setHorizontalAlignment(0);
    this.jLabel2.setText("Total");
    this.jLabel2.setMaximumSize(new Dimension(70, 16));
    this.jLabel2.setMinimumSize(new Dimension(70, 16));
    this.jLabel2.setPreferredSize(new Dimension(70, 16));
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 3;
    add(this.jLabel2, localGridBagConstraints);
    this.jLabel3.setHorizontalAlignment(0);
    this.jLabel3.setText("Code");
    this.jLabel3.setMaximumSize(new Dimension(70, 16));
    this.jLabel3.setMinimumSize(new Dimension(70, 16));
    this.jLabel3.setPreferredSize(new Dimension(70, 16));
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 1;
    localGridBagConstraints.gridy = 3;
    add(this.jLabel3, localGridBagConstraints);
    this.jLabel4.setHorizontalAlignment(0);
    this.jLabel4.setText("Comment");
    this.jLabel4.setMaximumSize(new Dimension(70, 16));
    this.jLabel4.setMinimumSize(new Dimension(70, 16));
    this.jLabel4.setPreferredSize(new Dimension(70, 16));
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 2;
    localGridBagConstraints.gridy = 3;
    add(this.jLabel4, localGridBagConstraints);
    this.jLabel5.setHorizontalAlignment(0);
    this.jLabel5.setText("Whitespace");
    this.jLabel5.setMaximumSize(new Dimension(70, 16));
    this.jLabel5.setMinimumSize(new Dimension(70, 16));
    this.jLabel5.setPreferredSize(new Dimension(70, 16));
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 3;
    localGridBagConstraints.gridy = 3;
    add(this.jLabel5, localGridBagConstraints);
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 4;
    localGridBagConstraints.gridwidth = 0;
    localGridBagConstraints.fill = 2;
    localGridBagConstraints.insets = new Insets(16, 0, 18, 0);
    add(this.jSeparator1, localGridBagConstraints);
    this.resultsTextArea.setEditable(false);
    this.resultsTextArea.setFont(new Font("Monospaced", 0, 12));
    this.resultsTextArea.setMargin(new Insets(8, 8, 8, 8));
    this.resultsTextArea.setMaximumSize(new Dimension(385, 300));
    this.resultsTextArea.setMinimumSize(new Dimension(385, 300));
    this.resultsTextArea.setPreferredSize(new Dimension(385, 300));
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 5;
    localGridBagConstraints.gridwidth = 0;
    add(this.resultsTextArea, localGridBagConstraints);
    this.totalLinesDisplay.setBackground(new Color(204, 204, 204));
    this.totalLinesDisplay.setText("jTextField1");
    this.totalLinesDisplay.setBorder(null);
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 0;
    localGridBagConstraints.gridy = 2;
    localGridBagConstraints.insets = new Insets(4, 0, 0, 0);
    add(this.totalLinesDisplay, localGridBagConstraints);
    this.codeLinesDisplay.setBackground(new Color(204, 204, 204));
    this.codeLinesDisplay.setText("jTextField2");
    this.codeLinesDisplay.setBorder(null);
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 1;
    localGridBagConstraints.gridy = 2;
    localGridBagConstraints.insets = new Insets(4, 0, 0, 0);
    add(this.codeLinesDisplay, localGridBagConstraints);
    this.commentLinesDisplay.setBackground(new Color(204, 204, 204));
    this.commentLinesDisplay.setText("jTextField3");
    this.commentLinesDisplay.setBorder(null);
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 2;
    localGridBagConstraints.gridy = 2;
    localGridBagConstraints.insets = new Insets(4, 0, 0, 0);
    add(this.commentLinesDisplay, localGridBagConstraints);
    this.wsLinesDisplay.setBackground(new Color(204, 204, 204));
    this.wsLinesDisplay.setText("jTextField4");
    this.wsLinesDisplay.setBorder(null);
    localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridx = 3;
    localGridBagConstraints.gridy = 2;
    localGridBagConstraints.insets = new Insets(4, 0, 0, 0);
    add(this.wsLinesDisplay, localGridBagConstraints);
  }
}


/* Location:           C:\Users\Usuario\Downloads\CodeAnalyzer-0.7.0.jar
 * Qualified Name:     ResultsDisplay.AnalyzerResults
 * JD-Core Version:    0.7.0.1
 */