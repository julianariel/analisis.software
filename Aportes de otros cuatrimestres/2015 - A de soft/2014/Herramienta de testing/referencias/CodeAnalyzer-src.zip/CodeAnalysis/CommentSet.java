/*---------------------------------------------------------------------------

  FILENAME:
        CommentSet.java

  PURPOSE:
        Provide the Code Analyzer Comment Set object.

  REVISION HISTORY:
        Date            Engineer        Revision        Remarks
        03/13/2004      M.S. Teel       0               Original

  NOTES:
        

  LICENSE:
        Copyright (c) 2004, Mark S. Teel (mark@teel.ws)
  
        This source code is released for free distribution under the terms 
        of the GNU General Public License.
  
----------------------------------------------------------------------------*/

package CodeAnalysis;

/*
 * CommentSet.java
 *
 * Created on February 27, 2004, 3:33 PM
 */
import javax.swing.tree.*;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;
import JavaUtils.*;
import AboutDialog.*;
import CodeSetTreeModel.*;

/**
 *
 * @author  mteel
 */
public class CommentSet extends java.lang.Object
{
    public Vector   comments;
    private String  name = "";
    
    
    // Creates a new instance of CommentSet
    public CommentSet (String newname)
    {
        name = new String (newname);
        comments = new Vector ();
    }
    
    // Creates a new instance of CommentSet from an existing instance
    public CommentSet (CommentSet set)
    {
        name = new String (set.toString ());
        comments = new Vector ();
        for (int i = 0; i < set.comments.size (); i ++)
        {
            Comment temp = new Comment ((Comment)set.comments.elementAt (i));
            comments.addElement (temp);
        }
    }
    
    public boolean equals (Object obj)
    {
        CommentSet temp = (CommentSet)obj;
        
        if (!temp.toString ().equals (name))
            return false;
        
        if (temp.comments.size () != comments.size ())
            return false;
        
        for (int i = 0; i < comments.size (); i ++)
        {
            Comment mine = (Comment)comments.elementAt(i);
            Comment theirs = (Comment)temp.comments.elementAt(i);
            
            if (!mine.equals (theirs))
                return false;
        }
        return true;
    }
    
    public String toString ()
    {
        return new String (name);
    }
    
    public Vector getCommentVector ()
    {
        return comments;
    }
    
    public String showContents ()
    {
        String      retVal = "";
        
        for (int i = 0; i < comments.size (); i ++)
        {
            Comment temp = (Comment)comments.elementAt (i);
            retVal += temp.toString ();
            retVal += "  ";
        }
        
        return new String (retVal);
    }
    
    public void add (Comment comment)
    {
        if (!comments.contains (comment))
        {
            Comment ncomm = new Comment (comment);
            comments.addElement (ncomm);
        }
    }
    
    public void remove (Comment comment)
    {
        comments.remove (comment);
    }
    
    public Comment getOpening (String str)
    {
        int     len = comments.size ();
        
        for (int i = 0; i < len; i ++)
        {
            if (((Comment)comments.elementAt (i)).isOpening (str))
            {
                return new Comment ((Comment)comments.elementAt (i));
            }
        }
        
        return null;
    }
    
    public Comment getClosing (String str)
    {
        int     len = comments.size ();
        
        for (int i = 0; i < len; i ++)
        {
            if (((Comment)comments.elementAt(i)).isClosing (str))
            {
                return new Comment ((Comment)comments.elementAt (i));
            }
        }
        
        return null;
    }

    public boolean isEOL (String str)
    {
        int     len = comments.size ();
        
        for (int i = 0; i < len; i ++)
        {
            if (((Comment)comments.elementAt (i)).isOpening (str))
            {
                if (((Comment)comments.elementAt (i)).isEOL ())
                    return true;
            }
        }
        
        return false;
    }
    
    public String getPropertyValue ()
    {
        String      retVal = name + "_";
        int         len = comments.size ();
        
        for (int i = 0; i < len; i ++)
        {
            Comment comm = (Comment)comments.elementAt(i);
            retVal += comm.toString ();
            if (i < len-1)
                retVal += "_";            
        }
        
        return new String (retVal);
    }
    
    public void setPropertyValue (String value)
    {
        comments.clear ();
        String [] comms = value.split ("_");
        name = new String (comms[0]);
        for (int i = 1; i < comms.length; i ++)
        {
            String [] vals = comms[i].split (":");
            String close = ((vals.length > 2) ? vals[1] : "");
            String eolstr = ((vals.length > 2) ? vals[2] : vals[1]);
            boolean eol;
            if (eolstr.equals ("EOL"))
                eol = true;
            else
                eol = false;
            Comment temp = new Comment (vals[0], close, eol);
            comments.addElement (temp);
        }
    }
}
