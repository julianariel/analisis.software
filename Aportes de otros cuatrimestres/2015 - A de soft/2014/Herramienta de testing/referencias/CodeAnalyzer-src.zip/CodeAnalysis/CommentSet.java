package CodeAnalysis;

import java.util.Vector;

public class CommentSet
{
  public Vector comments;
  private String name = "";
  
  public CommentSet(String paramString)
  {
    this.name = new String(paramString);
    this.comments = new Vector();
  }
  
  public CommentSet(CommentSet paramCommentSet)
  {
    this.name = new String(paramCommentSet.toString());
    this.comments = new Vector();
    for (int i = 0; i < paramCommentSet.comments.size(); i++)
    {
      Comment localComment = new Comment((Comment)paramCommentSet.comments.elementAt(i));
      this.comments.addElement(localComment);
    }
  }
  
  public boolean equals(Object paramObject)
  {
    CommentSet localCommentSet = (CommentSet)paramObject;
    if (!localCommentSet.toString().equals(this.name)) {
      return false;
    }
    if (localCommentSet.comments.size() != this.comments.size()) {
      return false;
    }
    for (int i = 0; i < this.comments.size(); i++)
    {
      Comment localComment1 = (Comment)this.comments.elementAt(i);
      Comment localComment2 = (Comment)localCommentSet.comments.elementAt(i);
      if (!localComment1.equals(localComment2)) {
        return false;
      }
    }
    return true;
  }
  
  public String toString()
  {
    return new String(this.name);
  }
  
  public Vector getCommentVector()
  {
    return this.comments;
  }
  
  public String showContents()
  {
    String str = "";
    for (int i = 0; i < this.comments.size(); i++)
    {
      Comment localComment = (Comment)this.comments.elementAt(i);
      str = str + localComment.toString();
      str = str + "  ";
    }
    return new String(str);
  }
  
  public void add(Comment paramComment)
  {
    if (!this.comments.contains(paramComment))
    {
      Comment localComment = new Comment(paramComment);
      this.comments.addElement(localComment);
    }
  }
  
  public void remove(Comment paramComment)
  {
    this.comments.remove(paramComment);
  }
  
  public Comment getOpening(String paramString)
  {
    int i = this.comments.size();
    for (int j = 0; j < i; j++) {
      if (((Comment)this.comments.elementAt(j)).isOpening(paramString)) {
        return new Comment((Comment)this.comments.elementAt(j));
      }
    }
    return null;
  }
  
  public Comment getClosing(String paramString)
  {
    int i = this.comments.size();
    for (int j = 0; j < i; j++) {
      if (((Comment)this.comments.elementAt(j)).isClosing(paramString)) {
        return new Comment((Comment)this.comments.elementAt(j));
      }
    }
    return null;
  }
  
  public boolean isEOL(String paramString)
  {
    int i = this.comments.size();
    for (int j = 0; j < i; j++) {
      if ((((Comment)this.comments.elementAt(j)).isOpening(paramString)) && (((Comment)this.comments.elementAt(j)).isEOL())) {
        return true;
      }
    }
    return false;
  }
  
  public String getPropertyValue()
  {
    String str = this.name + "_";
    int i = this.comments.size();
    for (int j = 0; j < i; j++)
    {
      Comment localComment = (Comment)this.comments.elementAt(j);
      str = str + localComment.toString();
      if (j < i - 1) {
        str = str + "_";
      }
    }
    return new String(str);
  }
  
  public void setPropertyValue(String paramString)
  {
    this.comments.clear();
    String[] arrayOfString1 = paramString.split("_");
    this.name = new String(arrayOfString1[0]);
    for (int i = 1; i < arrayOfString1.length; i++)
    {
      String[] arrayOfString2 = arrayOfString1[i].split(":");
      String str1 = arrayOfString2.length > 2 ? arrayOfString2[1] : "";
      String str2 = arrayOfString2.length > 2 ? arrayOfString2[2] : arrayOfString2[1];
      boolean bool;
      if (str2.equals("EOL")) {
        bool = true;
      } else {
        bool = false;
      }
      Comment localComment = new Comment(arrayOfString2[0], str1, bool);
      this.comments.addElement(localComment);
    }
  }
}


/* Location:           C:\Users\Usuario\Downloads\CodeAnalyzer-0.7.0.jar
 * Qualified Name:     CodeAnalysis.CommentSet
 * JD-Core Version:    0.7.0.1
 */