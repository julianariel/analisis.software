package CodeAnalysis;

import CodeSetTreeModel.FileNode;

public class FolderProcessor
{
  private FileNode file;
  
  public FolderProcessor(FileNode paramFileNode)
  {
    this.file = paramFileNode;
  }
  
  public void process()
  {
    if (this.file.isLeaf()) {
      return;
    }
    this.file.stats.clear();
    for (int i = 0; i < this.file.extStats.length; i++) {
      this.file.extStats[i].clear();
    }
    i = this.file.getChildCount();
    for (int j = 0; j < i; j++)
    {
      FileNode localFileNode = this.file.getChild(j);
      if (localFileNode.isIncluded())
      {
        this.file.stats.add(localFileNode.stats);
        if (localFileNode.isLeaf()) {
          this.file.extStats[localFileNode.myExtIndex].add(localFileNode.stats);
        } else {
          for (int k = 0; k < this.file.extStats.length; k++) {
            this.file.extStats[k].add(localFileNode.extStats[k]);
          }
        }
      }
    }
  }
}


/* Location:           C:\Users\Usuario\Downloads\CodeAnalyzer-0.7.0.jar
 * Qualified Name:     CodeAnalysis.FolderProcessor
 * JD-Core Version:    0.7.0.1
 */