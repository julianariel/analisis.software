/*---------------------------------------------------------------------------

  FILENAME:
        FolderProcessor.java

  PURPOSE:
        Provide the Code Analyzer FolderProcessor object.

  REVISION HISTORY:
        Date            Engineer        Revision        Remarks
        03/13/2004      M.S. Teel       0               Original

  NOTES:
        

  LICENSE:
        Copyright (c) 2004, Mark S. Teel (mark@teel.ws)
  
        This source code is released for free distribution under the terms 
        of the GNU General Public License.
  
----------------------------------------------------------------------------*/

package CodeAnalysis;


import java.io.File;
import CodeSetTreeModel.*;

/**
 *
 * @author  mteel
 */
public class FolderProcessor
{
    private FileNode file;
    
    
    /** Creates a new instance of FolderProcessor */
    public FolderProcessor (FileNode newfile)
    {
        file = newfile;
    }
    
    public void process ()
    {
        if (file.isLeaf ())
            return;
        
        file.stats.clear ();
        for (int i = 0; i < file.extStats.length; i ++)
        {
            file.extStats[i].clear ();
        }
        
        int len = file.getChildCount ();
        for (int i = 0; i < len; i ++)
        {
            FileNode node = file.getChild (i);
            if (node.isIncluded ())
            {
                file.stats.add (node.stats);
                
                if (node.isLeaf ())
                {
                    file.extStats[node.myExtIndex].add (node.stats);
                }
                else
                {
                    for (int j = 0; j < file.extStats.length; j ++)
                    {
                        file.extStats[j].add (node.extStats[j]);
                    }
                }
            }
        }
    }
}
