/*---------------------------------------------------------------------------

  FILENAME:
        Extension.java

  PURPOSE:
        Provide the Code Analyzer Extension object.

  REVISION HISTORY:
        Date            Engineer        Revision        Remarks
        03/13/2004      M.S. Teel       0               Original

  NOTES:
        

  LICENSE:
        Copyright (c) 2004, Mark S. Teel (mark@teel.ws)
  
        This source code is released for free distribution under the terms 
        of the GNU General Public License.
  
----------------------------------------------------------------------------*/

package CodeAnalysis;


import java.io.File;

/**
 *
 * @author  mteel
 */
public class Extension extends java.lang.Object
{
    public String       extension = "";
    public String       display = "";
    public CommentSet   comments = null;
    
    
    /** Creates a new instance of Extension */
    public Extension (String newext, CommentSet cset)
    {
        extension = new String (newext);
        display = new String ("*." + newext);
        if (cset != null)
            comments = new CommentSet (cset);
    }
    
    /** Creates a new instance of Extension */
    public Extension (Extension old)
    {
        extension = new String (old.extension);
        display = new String (old.display);
        comments = new CommentSet (old.comments);
    }
    
    public void setExtension (String newext)
    {
        extension = new String (newext);
        display = new String ("*." + newext);
    }
    
    public String getExtension ()
    {
        return new String (extension);
    }
    
    public void setCommentSet (CommentSet newset)
    {
        comments = new CommentSet (newset);
    }
    
    public CommentSet getCommentSet ()
    {
        return comments;
    }
    
    public boolean equals (Object obj)
    {
        Extension temp = (Extension)obj;
        
        if (temp.extension.equals(extension))
        {
            if (temp.comments.equals (comments))
                return true;
        }
        return false;
    }
    
    public String toString ()
    {
        return new String (display);
    }
    
    private String getFileExtension (File f)
    {
        if (f != null)
        {
            String filename = f.getName ();
            int i = filename.lastIndexOf ('.');
            if (i > 0 && i < filename.length () - 1)
            {
                return filename.substring (i+1);
            }
        }
        return null;
    }

    private String getFileExtension (String f)
    {
        if (f != null)
        {
            int i = f.lastIndexOf ('.');
            if (i > 0 && i < f.length () - 1)
            {
                return f.substring (i+1);
            }
        }
        return null;
    }

    public boolean matches (File file)
    {
        String thisext = getFileExtension (file);
        if (thisext != null)
            return thisext.equals (extension);
        else
            return false;
    }

    public boolean matches (String file)
    {
        String thisext = getFileExtension (file);
        if (thisext != null)
            return thisext.equals (extension);
        else
            return false;
    }
}
