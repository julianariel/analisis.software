package CodeAnalysis;

import java.io.File;

public class Extension
{
  public String extension = "";
  public String display = "";
  public CommentSet comments = null;
  
  public Extension(String paramString, CommentSet paramCommentSet)
  {
    this.extension = new String(paramString);
    this.display = new String("*." + paramString);
    if (paramCommentSet != null) {
      this.comments = new CommentSet(paramCommentSet);
    }
  }
  
  public Extension(Extension paramExtension)
  {
    this.extension = new String(paramExtension.extension);
    this.display = new String(paramExtension.display);
    this.comments = new CommentSet(paramExtension.comments);
  }
  
  public void setExtension(String paramString)
  {
    this.extension = new String(paramString);
    this.display = new String("*." + paramString);
  }
  
  public String getExtension()
  {
    return new String(this.extension);
  }
  
  public void setCommentSet(CommentSet paramCommentSet)
  {
    this.comments = new CommentSet(paramCommentSet);
  }
  
  public CommentSet getCommentSet()
  {
    return this.comments;
  }
  
  public boolean equals(Object paramObject)
  {
    Extension localExtension = (Extension)paramObject;
    return (localExtension.extension.equals(this.extension)) && (localExtension.comments.equals(this.comments));
  }
  
  public String toString()
  {
    return new String(this.display);
  }
  
  private String getFileExtension(File paramFile)
  {
    if (paramFile != null)
    {
      String str = paramFile.getName();
      int i = str.lastIndexOf('.');
      if ((i > 0) && (i < str.length() - 1)) {
        return str.substring(i + 1);
      }
    }
    return null;
  }
  
  private String getFileExtension(String paramString)
  {
    if (paramString != null)
    {
      int i = paramString.lastIndexOf('.');
      if ((i > 0) && (i < paramString.length() - 1)) {
        return paramString.substring(i + 1);
      }
    }
    return null;
  }
  
  public boolean matches(File paramFile)
  {
    String str = getFileExtension(paramFile);
    if (str != null) {
      return str.equals(this.extension);
    }
    return false;
  }
  
  public boolean matches(String paramString)
  {
    String str = getFileExtension(paramString);
    if (str != null) {
      return str.equals(this.extension);
    }
    return false;
  }
}


/* Location:           C:\Users\Usuario\Downloads\CodeAnalyzer-0.7.0.jar
 * Qualified Name:     CodeAnalysis.Extension
 * JD-Core Version:    0.7.0.1
 */