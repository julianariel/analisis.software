/*---------------------------------------------------------------------------

  FILENAME:
        FileProcessor.java

  PURPOSE:
        Provide the Code Analyzer FileProcessor object.

  REVISION HISTORY:
        Date            Engineer        Revision        Remarks
        03/13/2004      M.S. Teel       0               Original

  NOTES:
        

  LICENSE:
        Copyright (c) 2004, Mark S. Teel (mark@teel.ws)
  
        This source code is released for free distribution under the terms 
        of the GNU General Public License.
  
----------------------------------------------------------------------------*/

package CodeAnalysis;


import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import CodeSetTreeModel.*;

/**
 *
 * @author  mteel
 */
public class FileProcessor extends FileReader 
{
    private FileNode        fnode;
    private CommentSet      commentSet;
    
    
    /** Creates a new instance of FileProcessor */
    public FileProcessor (FileNode file, CommentSet cset)
    throws FileNotFoundException
    {
        super ((File)file);
            
    
        fnode           = file;
        commentSet      = cset;
    }
    

    private class SearchResult
    {
        public boolean      found = false;
        public boolean      isOpen;
        public boolean      isEOL;
        public int          offset;
        public boolean      codeFound;
        
        public SearchResult () {}
        
        public void reset ()
        {
            found = false;
            codeFound = false;
        }
    }
    
//  ... returns index > 0 if open match found, 
//  ... 0 if no match found,
//  ... index < 0 if close match found
    private void findCommentToken (SearchResult res, String string)
    {
        int             index = 0;
        String          tempStr = string;
        Comment         comm;
        
        res.reset ();
                    
        for (; tempStr.length () > 0; tempStr = tempStr.substring (1))
        {
            comm = commentSet.getOpening (tempStr);
            if (comm != null)
            {
                res.found = true;
                res.isOpen = true;
                res.isEOL = comm.isEOL ();
                if (index > 0)
                    res.codeFound = true;
                res.offset = index + comm.openLength ();
                return;
            }
            comm = commentSet.getClosing (tempStr);
            if (comm != null)
            {
                res.found = true;
                res.isOpen = false;
                res.isEOL = false;
                res.offset = index + comm.closeLength ();
                return;
            }
            index ++;
        }

        return;
    }

    public void process () throws IOException
    {
        boolean     cCommentOpen, tokenFinished, lineFinished;
        boolean     codeOnLine, commentOnLine;
        String      inLine;
        
        SearchResult result = new SearchResult();
        
        BufferedReader reader = new BufferedReader (this);
        
        cCommentOpen = false;
        fnode.stats.clear ();

        fnode.stats.add (fnode.stats.NUM_FILES, 1);

        for (inLine = reader.readLine ();
             inLine != null;
             inLine = reader.readLine ())
        {
//          ... get line length BEFORE trimming the leading whitespace        
            fnode.stats.add (fnode.stats.LINE_LENGTH, inLine.length ());
            fnode.stats.add (fnode.stats.TOTAL_LINES, 1);
            
            inLine = inLine.trim ();

            if (inLine.length () == 0)
            {
                fnode.stats.add (fnode.stats.WHITESPACE, 1);
                continue;
            }

            if (cCommentOpen)
            {
                fnode.stats.add (fnode.stats.COMMENTS, 1);
            }

            tokenFinished   = false;
            lineFinished    = false;
            codeOnLine      = false;
            commentOnLine   = false;
        
            String [] tokens = inLine.split ("\\s");
            for (int i = 0; i < tokens.length && !lineFinished; i ++)
            {
                tokenFinished = false;
                while (tokenFinished == false)
                {
                    // ... now empty?
                    if (tokens[i].length () == 0)
                    {
                        tokenFinished = true;
                        continue;
                    }
                    
                    // ... if inside "C" comment block
                    if (cCommentOpen)
                    {
                        findCommentToken (result, tokens[i]);
                        if (!result.found || result.isOpen)
                        {
                            tokenFinished = true;
                        }
                        else
                        {
                            cCommentOpen = false;
                            tokens[i] = tokens[i].substring (result.offset);
                        }
                        continue;
                    }

                    // ... are next n chars a comment open?
                    findCommentToken (result, tokens[i]);
                    if (result.found && result.isOpen)
                    {
                        cCommentOpen = true;
                        commentOnLine = true;
                        if (result.codeFound)
                            codeOnLine = true;
                        tokens[i] = tokens[i].substring (result.offset);
                        if (result.isEOL)
                        {
                            tokenFinished = true;
                            lineFinished = true;
                            cCommentOpen = false;
                        }
                        continue;
                    }

                    // ... it must be source code if we are here
                    codeOnLine = true;
                    tokens[i] = tokens[i].substring (1);
                }
            }

            if (codeOnLine)
            {
                fnode.stats.add (fnode.stats.CODE, 1);
            }

            if (commentOnLine)
            {
                fnode.stats.add (fnode.stats.COMMENTS, 1);
            }
        }
    }
}
