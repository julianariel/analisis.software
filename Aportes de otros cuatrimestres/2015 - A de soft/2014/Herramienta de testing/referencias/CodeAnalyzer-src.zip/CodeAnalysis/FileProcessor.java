package CodeAnalysis;

import CodeSetTreeModel.FileNode;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileProcessor
  extends FileReader
{
  private FileNode fnode;
  private CommentSet commentSet;
  
  public FileProcessor(FileNode paramFileNode, CommentSet paramCommentSet)
    throws FileNotFoundException
  {
    super(paramFileNode);
    this.fnode = paramFileNode;
    this.commentSet = paramCommentSet;
  }
  
  private void findCommentToken(SearchResult paramSearchResult, String paramString)
  {
    int i = 0;
    String str = paramString;
    paramSearchResult.reset();
    while (str.length() > 0)
    {
      Comment localComment = this.commentSet.getOpening(str);
      if (localComment != null)
      {
        paramSearchResult.found = true;
        paramSearchResult.isOpen = true;
        paramSearchResult.isEOL = localComment.isEOL();
        if (i > 0) {
          paramSearchResult.codeFound = true;
        }
        paramSearchResult.offset = (i + localComment.openLength());
        return;
      }
      localComment = this.commentSet.getClosing(str);
      if (localComment != null)
      {
        paramSearchResult.found = true;
        paramSearchResult.isOpen = false;
        paramSearchResult.isEOL = false;
        paramSearchResult.offset = (i + localComment.closeLength());
        return;
      }
      i++;
      str = str.substring(1);
    }
  }
  
  public void process()
    throws IOException
  {
    SearchResult localSearchResult = new SearchResult();
    BufferedReader localBufferedReader = new BufferedReader(this);
    int i = 0;
    this.fnode.stats.clear();
    this.fnode.stats.add(Stats.NUM_FILES, 1);
    for (String str = localBufferedReader.readLine(); str != null; str = localBufferedReader.readLine())
    {
      this.fnode.stats.add(Stats.LINE_LENGTH, str.length());
      this.fnode.stats.add(Stats.TOTAL_LINES, 1);
      str = str.trim();
      if (str.length() == 0)
      {
        this.fnode.stats.add(Stats.WHITESPACE, 1);
      }
      else
      {
        if (i != 0) {
          this.fnode.stats.add(Stats.COMMENTS, 1);
        }
        int j = 0;
        int k = 0;
        int m = 0;
        int n = 0;
        String[] arrayOfString = str.split("\\s");
        for (int i1 = 0; (i1 < arrayOfString.length) && (k == 0); i1++)
        {
          j = 0;
          while (j == 0) {
            if (arrayOfString[i1].length() == 0)
            {
              j = 1;
            }
            else if (i != 0)
            {
              findCommentToken(localSearchResult, arrayOfString[i1]);
              if ((!localSearchResult.found) || (localSearchResult.isOpen))
              {
                j = 1;
              }
              else
              {
                i = 0;
                arrayOfString[i1] = arrayOfString[i1].substring(localSearchResult.offset);
              }
            }
            else
            {
              findCommentToken(localSearchResult, arrayOfString[i1]);
              if ((localSearchResult.found) && (localSearchResult.isOpen))
              {
                i = 1;
                n = 1;
                if (localSearchResult.codeFound) {
                  m = 1;
                }
                arrayOfString[i1] = arrayOfString[i1].substring(localSearchResult.offset);
                if (localSearchResult.isEOL)
                {
                  j = 1;
                  k = 1;
                  i = 0;
                }
              }
              else
              {
                m = 1;
                arrayOfString[i1] = arrayOfString[i1].substring(1);
              }
            }
          }
        }
        if (m != 0) {
          this.fnode.stats.add(Stats.CODE, 1);
        }
        if (n != 0) {
          this.fnode.stats.add(Stats.COMMENTS, 1);
        }
      }
    }
  }
  
  private class SearchResult
  {
    public boolean found = false;
    public boolean isOpen;
    public boolean isEOL;
    public int offset;
    public boolean codeFound;
    
    public SearchResult() {}
    
    public void reset()
    {
      this.found = false;
      this.codeFound = false;
    }
  }
}


/* Location:           C:\Users\Usuario\Downloads\CodeAnalyzer-0.7.0.jar
 * Qualified Name:     CodeAnalysis.FileProcessor
 * JD-Core Version:    0.7.0.1
 */