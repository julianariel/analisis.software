/*---------------------------------------------------------------------------

  FILENAME:
        Comment.java

  PURPOSE:
        Provide the Code Analyzer Comment object.

  REVISION HISTORY:
        Date            Engineer        Revision        Remarks
        03/13/2004      M.S. Teel       0               Original

  NOTES:
        

  LICENSE:
        Copyright (c) 2004, Mark S. Teel (mark@teel.ws)
  
        This source code is released for free distribution under the terms 
        of the GNU General Public License.
  
----------------------------------------------------------------------------*/

package CodeAnalysis;

/**
 *
 * @author  mteel
 */
public class Comment extends java.lang.Object
{
    public String       open = "";
    public String       close = "";
    public boolean      eol = false;
    public String       display = "";
    
    
    /** Creates a new instance of Comment */
    public Comment (String opening, String closing, boolean endofline)
    {
        open = new String (opening);
        eol = endofline;
        if (eol)
            close = new String ("");
        else
            close = new String (closing);
        
        display = new String (open + ":" + close + ":" + ((eol) ? "EOL" : "~EOL"));
    }
    
    /** Creates a new instance of Comment */
    public Comment (Comment old)
    {
        open = new String (old.open);
        close = new String (old.close);
        eol = old.eol;
        display = new String (old.display);
    }
    
    
    public boolean equals (Object obj)
    {
        Comment temp = (Comment)obj;
        
        if (!temp.open.equals(open))
            return false;
        if (!temp.close.equals(close))
            return false;
        if (temp.eol != eol)
            return false;
        return true;
    }
    
    public String toString ()
    {
        return new String (display);
    }
    
    public String getOpening ()
    {
        return new String (open);
    }
    
    public String getClosing ()
    {
        return new String (close);
    }
    
    public void setOpening (String val)
    {
        open = new String (val);
        display = new String (open + ":" + close + ":" + ((eol) ? "EOL" : "~EOL"));
    }
    
    public void setClosing (String val)
    {
        if (eol)
            return;
        
        close = new String (val);
        display = new String (open + ":" + close + ":" + ((eol) ? "EOL" : "~EOL"));
    }
    
    public void setEOL (boolean val)
    {
        eol = val;
        if (eol)
            close = new String ("");
        display = new String (open + ":" + close + ":" + ((eol) ? "EOL" : "~EOL"));
    }
    
    public boolean isEOL ()
    {
        return eol;
    }
    
    public boolean isOpening (String str)
    {
        return str.startsWith (open);
    }
    
    public boolean isClosing (String str)
    {
        if (eol)
            return false;
        
        return str.startsWith (close);
    }
    
    public int openLength ()
    {
        return open.length ();
    }
    
    public int closeLength ()
    {
        return close.length ();
    }
}
