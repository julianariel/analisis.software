package CodeAnalysis;

public class Comment
{
  public String open = "";
  public String close = "";
  public boolean eol = false;
  public String display = "";
  
  public Comment(String paramString1, String paramString2, boolean paramBoolean)
  {
    this.open = new String(paramString1);
    this.eol = paramBoolean;
    if (this.eol) {
      this.close = new String("");
    } else {
      this.close = new String(paramString2);
    }
    this.display = new String(this.open + ":" + this.close + ":" + (this.eol ? "EOL" : "~EOL"));
  }
  
  public Comment(Comment paramComment)
  {
    this.open = new String(paramComment.open);
    this.close = new String(paramComment.close);
    this.eol = paramComment.eol;
    this.display = new String(paramComment.display);
  }
  
  public boolean equals(Object paramObject)
  {
    Comment localComment = (Comment)paramObject;
    if (!localComment.open.equals(this.open)) {
      return false;
    }
    if (!localComment.close.equals(this.close)) {
      return false;
    }
    return localComment.eol == this.eol;
  }
  
  public String toString()
  {
    return new String(this.display);
  }
  
  public String getOpening()
  {
    return new String(this.open);
  }
  
  public String getClosing()
  {
    return new String(this.close);
  }
  
  public void setOpening(String paramString)
  {
    this.open = new String(paramString);
    this.display = new String(this.open + ":" + this.close + ":" + (this.eol ? "EOL" : "~EOL"));
  }
  
  public void setClosing(String paramString)
  {
    if (this.eol) {
      return;
    }
    this.close = new String(paramString);
    this.display = new String(this.open + ":" + this.close + ":" + (this.eol ? "EOL" : "~EOL"));
  }
  
  public void setEOL(boolean paramBoolean)
  {
    this.eol = paramBoolean;
    if (this.eol) {
      this.close = new String("");
    }
    this.display = new String(this.open + ":" + this.close + ":" + (this.eol ? "EOL" : "~EOL"));
  }
  
  public boolean isEOL()
  {
    return this.eol;
  }
  
  public boolean isOpening(String paramString)
  {
    return paramString.startsWith(this.open);
  }
  
  public boolean isClosing(String paramString)
  {
    if (this.eol) {
      return false;
    }
    return paramString.startsWith(this.close);
  }
  
  public int openLength()
  {
    return this.open.length();
  }
  
  public int closeLength()
  {
    return this.close.length();
  }
}


/* Location:           C:\Users\Usuario\Downloads\CodeAnalyzer-0.7.0.jar
 * Qualified Name:     CodeAnalysis.Comment
 * JD-Core Version:    0.7.0.1
 */