/*---------------------------------------------------------------------------

  FILENAME:
        Stats.java

  PURPOSE:
        Provide the Code Analyzer metrics object.

  REVISION HISTORY:
        Date            Engineer        Revision        Remarks
        03/13/2004      M.S. Teel       0               Original

  NOTES:
        

  LICENSE:
        Copyright (c) 2004, Mark S. Teel (mark@teel.ws)
  
        This source code is released for free distribution under the terms 
        of the GNU General Public License.
  
----------------------------------------------------------------------------*/

package CodeAnalysis;


import javax.swing.JTextArea;
import java.io.*;
import java.text.DecimalFormat;

/**
 *
 * @author  mteel
 */
public class Stats
{
    public static int   LINE_LENGTH     = 0;
    public static int   TOTAL_LINES     = 1;
    public static int   WHITESPACE      = 2;
    public static int   CODE            = 3;
    public static int   COMMENTS        = 4;
    public static int   NUM_FILES       = 5;
    public static int   NUM_TYPES       = 6;
    
    private int[]       values;
    
    
    /** Creates a new instance of Stats */
    public Stats ()
    {
        values = new int[NUM_TYPES];
        clear ();
    }
    
    public void clear ()
    {
        for (int i = 0; i < NUM_TYPES; i ++)
            values[i] = 0;
    }
    
    public void add (int type, int val)
    {
        if (type < 0 || type >= NUM_TYPES)
            return;
        
        values[type] += val;
    }
    
    public void add (Stats stats)
    {
        for (int i = 0; i < NUM_TYPES; i ++)
            values[i] += stats.get (i);
    }
    
    public int get (int type)
    {
        if (type < 0 || type >= NUM_TYPES)
            return 0;
        
        return values[type];
    }
    
    public void display (JTextArea area)
    {
        String          tempStr, t1;
        int             a1;
        float           f1;
        String []       pad = {"        ","       ","      ","     ","    ","   ","  "," "};
        DecimalFormat   format = new DecimalFormat ("0.00");
        
        area.setText ("");
        
        area.append ("\n");
        tempStr = "    Metric\t\t\t\tValue\n";
        area.append (tempStr);
        tempStr = "    -------------------------------\t--------\n";
        area.append (tempStr);
        
        t1 = "" + get (NUM_FILES);
        tempStr = "    Total Files\t\t\t\t" + pad[t1.length ()] + t1 + "\n";
        area.append (tempStr);
        
        t1 = "" + get (TOTAL_LINES);
        tempStr = "    Total Lines\t\t\t\t" + pad[t1.length ()] + t1 + "\n";
        area.append (tempStr);
        
        if (get (TOTAL_LINES) > 0)
            a1 = get (LINE_LENGTH)/get (TOTAL_LINES);
        else
            a1 = 0;
        t1 = "" + a1;
        tempStr = "    Avg Line Length\t\t\t" + pad[t1.length ()] + t1 + "\n";
        area.append (tempStr);
        
        t1 = "" + get (CODE);
        tempStr = "    Code Lines\t\t\t\t" + pad[t1.length ()] + t1 + "\n";
        area.append (tempStr);
        
        t1 = "" + get (COMMENTS);
        tempStr = "    Comment Lines\t\t\t" + pad[t1.length ()] + t1 + "\n";
        area.append (tempStr);
        
        t1 = "" + get (WHITESPACE);
        tempStr = "    Whitespace Lines\t\t\t" + pad[t1.length ()] + t1 + "\n";
        area.append (tempStr);
        
        if ((get (COMMENTS) + get (WHITESPACE)) > 0)
            f1 = (float)get (CODE)/(float)(get (COMMENTS) + get (WHITESPACE));
        else
            f1 = 0;
        t1 = "" + format.format (f1);
        tempStr = "    Code/(Comment+Whitespace) Ratio\t" + pad[t1.length ()] + t1 + "\n";
        area.append (tempStr);
        
        if (get (COMMENTS) > 0)
            f1 = (float)get (CODE)/(float)(get (COMMENTS));
        else
            f1 = 0;
        t1 = "" + format.format (f1);
        tempStr = "    Code/Comment Ratio\t\t\t" + pad[t1.length ()] + t1 + "\n";
        area.append (tempStr);
        
        if (get (WHITESPACE) > 0)
            f1 = (float)get (CODE)/(float)(get (WHITESPACE));
        else
            f1 = 0;
        t1 = "" + format.format (f1);
        tempStr = "    Code/Whitespace Ratio\t\t" + pad[t1.length ()] + t1 + "\n";
        area.append (tempStr);
        
        if (get (TOTAL_LINES) > 0)
            f1 = (float)get (CODE)/(float)(get (TOTAL_LINES));
        else
            f1 = 0;
        t1 = "" + format.format (f1);
        tempStr = "    Code/Total Lines Ratio\t\t" + pad[t1.length ()] + t1 + "\n";
        area.append (tempStr);
        
        if (get (NUM_FILES) > 0)
            a1 = get (CODE)/get (NUM_FILES);
        else
            a1 = 0;
        t1 = "" + a1;
        tempStr = "    Code Lines Per File\t\t\t" + pad[t1.length ()] + t1 + "\n";
        area.append (tempStr);
        
        if (get (NUM_FILES) > 0)
            a1 = get (COMMENTS)/get (NUM_FILES);
        else
            a1 = 0;
        t1 = "" + a1;
        tempStr = "    Comment Lines Per File\t\t" + pad[t1.length ()] + t1 + "\n";
        area.append (tempStr);
        
        if (get (NUM_FILES) > 0)
            a1 = get (WHITESPACE)/get (NUM_FILES);
        else
            a1 = 0;
        t1 = "" + a1;
        tempStr = "    Whitespace Lines Per File\t\t" + pad[t1.length ()] + t1 + "\n";
        area.append (tempStr);
    }

    public void writeToFile (FileWriter file, String fname) throws IOException
    {
        String          tempStr, t1;
        int             a1;
        float           f1;
        String []       pad = {"        ","       ","      ","     ","    ","   ","  "," "};
        DecimalFormat   format = new DecimalFormat ("0.00");
        
        file.write ("\n****************************************************\n");
        file.write ("****************************************************\n");
        file.write (fname + "\n\n");
        
        tempStr = "    Metric                             Value\n";
        file.write (tempStr);
        tempStr = "    -------------------------------    --------\n";
        file.write (tempStr);
        
        t1 = "" + get (NUM_FILES);
        tempStr = "    Total Files                        " + pad[t1.length ()] + t1 + "\n";
        file.write (tempStr);
        
        t1 = "" + get (TOTAL_LINES);
        tempStr = "    Total Lines                        " + pad[t1.length ()] + t1 + "\n";
        file.write (tempStr);
        
        if (get (TOTAL_LINES) > 0)
            a1 = get (LINE_LENGTH)/get (TOTAL_LINES);
        else
            a1 = 0;
        t1 = "" + a1;
        tempStr = "    Avg Line Length                    " + pad[t1.length ()] + t1 + "\n";
        file.write (tempStr);
        
        t1 = "" + get (CODE);
        tempStr = "    Code Lines                         " + pad[t1.length ()] + t1 + "\n";
        file.write (tempStr);
        
        t1 = "" + get (COMMENTS);
        tempStr = "    Comment Lines                      " + pad[t1.length ()] + t1 + "\n";
        file.write (tempStr);
        
        t1 = "" + get (WHITESPACE);
        tempStr = "    Whitespace Lines                   " + pad[t1.length ()] + t1 + "\n";
        file.write (tempStr);
        
        if ((get (COMMENTS) + get (WHITESPACE)) > 0)
            f1 = (float)get (CODE)/(float)(get (COMMENTS) + get (WHITESPACE));
        else
            f1 = 0;
        t1 = "" + format.format (f1);
        tempStr = "    Code/(Comment+Whitespace) Ratio    " + pad[t1.length ()] + t1 + "\n";
        file.write (tempStr);
        
        if (get (COMMENTS) > 0)
            f1 = (float)get (CODE)/(float)(get (COMMENTS));
        else
            f1 = 0;
        t1 = "" + format.format (f1);
        tempStr = "    Code/Comment Ratio                 " + pad[t1.length ()] + t1 + "\n";
        file.write (tempStr);
        
        if (get (WHITESPACE) > 0)
            f1 = (float)get (CODE)/(float)(get (WHITESPACE));
        else
            f1 = 0;
        t1 = "" + format.format (f1);
        tempStr = "    Code/Whitespace Ratio              " + pad[t1.length ()] + t1 + "\n";
        file.write (tempStr);
        
        if (get (TOTAL_LINES) > 0)
            f1 = (float)get (CODE)/(float)(get (TOTAL_LINES));
        else
            f1 = 0;
        t1 = "" + format.format (f1);
        tempStr = "    Code/Total Lines Ratio             " + pad[t1.length ()] + t1 + "\n";
        file.write (tempStr);
        
        if (get (NUM_FILES) > 0)
            a1 = get (CODE)/get (NUM_FILES);
        else
            a1 = 0;
        t1 = "" + a1;
        tempStr = "    Code Lines Per File                " + pad[t1.length ()] + t1 + "\n";
        file.write (tempStr);
        
        if (get (NUM_FILES) > 0)
            a1 = get (COMMENTS)/get (NUM_FILES);
        else
            a1 = 0;
        t1 = "" + a1;
        tempStr = "    Comment Lines Per File             " + pad[t1.length ()] + t1 + "\n";
        file.write (tempStr);
        
        if (get (NUM_FILES) > 0)
            a1 = get (WHITESPACE)/get (NUM_FILES);
        else
            a1 = 0;
        t1 = "" + a1;
        tempStr = "    Whitespace Lines Per File          " + pad[t1.length ()] + t1 + "\n";
        file.write (tempStr);
    }

    public static void writeTextHdrToFile (FileWriter file, boolean underline) 
    throws IOException
    {
        String          underln = "-------- ";
        String []       hdrs = 
            {
                "Files    ",
                "Lines    ",
                "AVG Len  ",
                "Code     ",
                "Comments ",
                "White SP ",
                "Cd/Cm+WS ",
                "Cd/Cm    ",
                "Cd/WS    ",
                "% Code   ",
                "Cd/File  ",
                "Cm/File  ",
                "WS/File  ",
                ""
            };
        
        for (int i = 0; hdrs[i].length () != 0; i ++)
        {
            if (underline)
                file.write (underln);
            else
                file.write (hdrs[i]);
        }
    }
    
    public void writeTextToFile (FileWriter file) throws IOException
    {
        String          tempStr, t1;
        int             a1;
        float           f1;
        String []       pad = 
            {
                "         ",
                "        ",
                "       ",
                "      ",
                "     ",
                "    ",
                "   ",
                "  ",
                " "
            };
        DecimalFormat   format = new DecimalFormat ("0.00");
        
        t1 = "" + get (NUM_FILES);
        tempStr = pad[t1.length ()] + t1;
        file.write (tempStr);
        
        t1 = "" + get (TOTAL_LINES);
        tempStr = pad[t1.length ()] + t1;
        file.write (tempStr);
        
        if (get (TOTAL_LINES) > 0)
            a1 = get (LINE_LENGTH)/get (TOTAL_LINES);
        else
            a1 = 0;
        t1 = "" + a1;
        tempStr = pad[t1.length ()] + t1;
        file.write (tempStr);
        
        t1 = "" + get (CODE);
        tempStr = pad[t1.length ()] + t1;
        file.write (tempStr);
        
        t1 = "" + get (COMMENTS);
        tempStr = pad[t1.length ()] + t1;
        file.write (tempStr);
        
        t1 = "" + get (WHITESPACE);
        tempStr = pad[t1.length ()] + t1;
        file.write (tempStr);
        
        if ((get (COMMENTS) + get (WHITESPACE)) > 0)
            f1 = (float)get (CODE)/(float)(get (COMMENTS) + get (WHITESPACE));
        else
            f1 = 0;
        t1 = "" + format.format (f1);
        tempStr = pad[t1.length ()] + t1;
        file.write (tempStr);
        
        if (get (COMMENTS) > 0)
            f1 = (float)get (CODE)/(float)(get (COMMENTS));
        else
            f1 = 0;
        t1 = "" + format.format (f1);
        tempStr = pad[t1.length ()] + t1;
        file.write (tempStr);
        
        if (get (WHITESPACE) > 0)
            f1 = (float)get (CODE)/(float)(get (WHITESPACE));
        else
            f1 = 0;
        t1 = "" + format.format (f1);
        tempStr = pad[t1.length ()] + t1;
        file.write (tempStr);
        
        if (get (TOTAL_LINES) > 0)
            f1 = (float)get (CODE)/(float)(get (TOTAL_LINES));
        else
            f1 = 0;
        t1 = "" + format.format (f1);
        tempStr = pad[t1.length ()] + t1;
        file.write (tempStr);
        
        if (get (NUM_FILES) > 0)
            a1 = get (CODE)/get (NUM_FILES);
        else
            a1 = 0;
        t1 = "" + a1;
        tempStr = pad[t1.length ()] + t1;
        file.write (tempStr);
        
        if (get (NUM_FILES) > 0)
            a1 = get (COMMENTS)/get (NUM_FILES);
        else
            a1 = 0;
        t1 = "" + a1;
        tempStr = pad[t1.length ()] + t1;
        file.write (tempStr);
        
        if (get (NUM_FILES) > 0)
            a1 = get (WHITESPACE)/get (NUM_FILES);
        else
            a1 = 0;
        t1 = "" + a1;
        tempStr = pad[t1.length ()] + t1;
        file.write (tempStr);
    }

    public static void writeHTMLHdrToFile (FileWriter file, String prefix) 
    throws IOException
    {
        String []       hdrs = 
            {
                "Total&nbsp;&nbsp;&nbsp;&nbsp; Files&nbsp;&nbsp;",
                "Total&nbsp;&nbsp; Lines&nbsp;&nbsp;&nbsp;",
                "AVG Line&nbsp;Len",
                "Total Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Lines&nbsp;&nbsp;",
                "Total Comment Lines&nbsp;&nbsp;",
                "Total WS&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Lines&nbsp;",
                "Cd/~Cd Ratio&nbsp;",
                "Cd/Cm&nbsp; &nbsp;Ratio&nbsp;",
                "Cd/WS&nbsp; &nbsp;Ratio&nbsp;",
                "%&nbsp;Code Lines",
                "Code&nbsp; Lines/File",
                "Comment Lines/File",
                "WS&nbsp;&nbsp; Lines/File",
                ""
            };
        
        file.write ("        <tr>\r\n");
        file.write ("          <td>" + prefix + "</td>\r\n");
        for (int i = 0; hdrs[i].length () != 0; i ++)
        {
            file.write ("          <td>" + hdrs[i] + "</td>\r\n");
        }
        file.write ("        </tr>\r\n");
    }
    
    public void writeHTMLToFile (FileWriter file, String prefix) throws IOException
    {
        String          t1;
        int             a1;
        float           f1;
        DecimalFormat   format = new DecimalFormat ("0.00");
        
        file.write ("        <tr>\r\n");
        file.write ("          <td>" + prefix + "</td>\r\n");

        t1 = "          <td>" + get (NUM_FILES) + "</td>\r\n";
        file.write (t1);
        
        t1 = "          <td>" + get (TOTAL_LINES) + "</td>\r\n";
        file.write (t1);
        
        if (get (TOTAL_LINES) > 0)
            a1 = get (LINE_LENGTH)/get (TOTAL_LINES);
        else
            a1 = 0;
        t1 = "          <td>" + a1 + "</td>\r\n";
        file.write (t1);
        
        t1 = "          <td>" + get (CODE) + "</td>\r\n";
        file.write (t1);
        
        t1 = "          <td>" + get (COMMENTS) + "</td>\r\n";
        file.write (t1);
        
        t1 = "          <td>" + get (WHITESPACE) + "</td>\r\n";
        file.write (t1);
        
        if ((get (COMMENTS) + get (WHITESPACE)) > 0)
            f1 = (float)get (CODE)/(float)(get (COMMENTS) + get (WHITESPACE));
        else
            f1 = 0;
        t1 = "          <td>" + format.format (f1) + "</td>\r\n";
        file.write (t1);
        
        if (get (COMMENTS) > 0)
            f1 = (float)get (CODE)/(float)(get (COMMENTS));
        else
            f1 = 0;
        t1 = "          <td>" + format.format (f1) + "</td>\r\n";
        file.write (t1);
        
        if (get (WHITESPACE) > 0)
            f1 = (float)get (CODE)/(float)(get (WHITESPACE));
        else
            f1 = 0;
        t1 = "          <td>" + format.format (f1) + "</td>\r\n";
        file.write (t1);
        
        if (get (TOTAL_LINES) > 0)
            f1 = (float)get (CODE)/(float)(get (TOTAL_LINES));
        else
            f1 = 0;
        t1 = "          <td>" + format.format (f1) + "</td>\r\n";
        file.write (t1);
        
        if (get (NUM_FILES) > 0)
            a1 = get (CODE)/get (NUM_FILES);
        else
            a1 = 0;
        t1 = "          <td>" + a1 + "</td>\r\n";
        file.write (t1);
        
        if (get (NUM_FILES) > 0)
            a1 = get (COMMENTS)/get (NUM_FILES);
        else
            a1 = 0;
        t1 = "          <td>" + a1 + "</td>\r\n";
        file.write (t1);
        
        if (get (NUM_FILES) > 0)
            a1 = get (WHITESPACE)/get (NUM_FILES);
        else
            a1 = 0;
        t1 = "          <td>" + a1 + "</td>\r\n";
        file.write (t1);

        file.write ("        </tr>\r\n");
    }

    public static void writeCommaDelimHdrToFile (FileWriter file) throws IOException
    {
        String []       hdrs = 
            {
                "Files,",
                "Lines,",
                "AVG Len,",
                "Code,",
                "Comments,",
                "White SP,",
                "Cd/Cm+WS,",
                "Cd/Cm,",
                "Cd/WS,",
                "% Code,",
                "Cd/File,",
                "Cm/File,",
                "WS/File,",
                ""
            };
        
        for (int i = 0; hdrs[i].length () != 0; i ++)
        {
            file.write (hdrs[i]);
        }
    }
    
    public void writeCommaDelimToFile (FileWriter file) throws IOException
    {
        String          tempStr, t1;
        int             a1;
        float           f1;
        DecimalFormat   format = new DecimalFormat ("0.00");
        
        t1 = "" + get (NUM_FILES) + ",";
        file.write (t1);
        
        t1 = "" + get (TOTAL_LINES) + ",";
        file.write (t1);
        
        if (get (TOTAL_LINES) > 0)
            a1 = get (LINE_LENGTH)/get (TOTAL_LINES);
        else
            a1 = 0;
        t1 = "" + a1 + ",";
        file.write (t1);
        
        t1 = "" + get (CODE) + ",";
        file.write (t1);
        
        t1 = "" + get (COMMENTS) + ",";
        file.write (t1);
        
        t1 = "" + get (WHITESPACE) + ",";
        file.write (t1);
        
        if ((get (COMMENTS) + get (WHITESPACE)) > 0)
            f1 = (float)get (CODE)/(float)(get (COMMENTS) + get (WHITESPACE));
        else
            f1 = 0;
        t1 = "" + format.format (f1) + ",";
        file.write (t1);
        
        if (get (COMMENTS) > 0)
            f1 = (float)get (CODE)/(float)(get (COMMENTS));
        else
            f1 = 0;
        t1 = "" + format.format (f1) + ",";
        file.write (t1);
        
        if (get (WHITESPACE) > 0)
            f1 = (float)get (CODE)/(float)(get (WHITESPACE));
        else
            f1 = 0;
        t1 = "" + format.format (f1) + ",";
        file.write (t1);
        
        if (get (TOTAL_LINES) > 0)
            f1 = (float)get (CODE)/(float)(get (TOTAL_LINES));
        else
            f1 = 0;
        t1 = "" + format.format (f1) + ",";
        file.write (t1);
        
        if (get (NUM_FILES) > 0)
            a1 = get (CODE)/get (NUM_FILES);
        else
            a1 = 0;
        t1 = "" + a1 + ",";
        file.write (t1);
        
        if (get (NUM_FILES) > 0)
            a1 = get (COMMENTS)/get (NUM_FILES);
        else
            a1 = 0;
        t1 = "" + a1 + ",";
        file.write (t1);
        
        if (get (NUM_FILES) > 0)
            a1 = get (WHITESPACE)/get (NUM_FILES);
        else
            a1 = 0;
        t1 = "" + a1;       // no comma for last
        file.write (t1);
    }
}
