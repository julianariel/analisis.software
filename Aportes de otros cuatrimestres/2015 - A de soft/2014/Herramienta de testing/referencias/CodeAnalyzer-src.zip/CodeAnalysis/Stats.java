package CodeAnalysis;

import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import javax.swing.JTextArea;

public class Stats
{
  public static int LINE_LENGTH = 0;
  public static int TOTAL_LINES = 1;
  public static int WHITESPACE = 2;
  public static int CODE = 3;
  public static int COMMENTS = 4;
  public static int NUM_FILES = 5;
  public static int NUM_TYPES = 6;
  private int[] values = new int[NUM_TYPES];
  
  public Stats()
  {
    clear();
  }
  
  public void clear()
  {
    for (int i = 0; i < NUM_TYPES; i++) {
      this.values[i] = 0;
    }
  }
  
  public void add(int paramInt1, int paramInt2)
  {
    if ((paramInt1 < 0) || (paramInt1 >= NUM_TYPES)) {
      return;
    }
    this.values[paramInt1] += paramInt2;
  }
  
  public void add(Stats paramStats)
  {
    for (int i = 0; i < NUM_TYPES; i++) {
      this.values[i] += paramStats.get(i);
    }
  }
  
  public int get(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= NUM_TYPES)) {
      return 0;
    }
    return this.values[paramInt];
  }
  
  public void display(JTextArea paramJTextArea)
  {
    String[] arrayOfString = { "        ", "       ", "      ", "     ", "    ", "   ", "  ", " " };
    DecimalFormat localDecimalFormat = new DecimalFormat("0.00");
    paramJTextArea.setText("");
    paramJTextArea.append("\n");
    String str1 = "    Metric\t\t\t\tValue\n";
    paramJTextArea.append(str1);
    str1 = "    -------------------------------\t--------\n";
    paramJTextArea.append(str1);
    String str2 = "" + get(NUM_FILES);
    str1 = "    Total Files\t\t\t\t" + arrayOfString[str2.length()] + str2 + "\n";
    paramJTextArea.append(str1);
    str2 = "" + get(TOTAL_LINES);
    str1 = "    Total Lines\t\t\t\t" + arrayOfString[str2.length()] + str2 + "\n";
    paramJTextArea.append(str1);
    int i;
    if (get(TOTAL_LINES) > 0) {
      i = get(LINE_LENGTH) / get(TOTAL_LINES);
    } else {
      i = 0;
    }
    str2 = "" + i;
    str1 = "    Avg Line Length\t\t\t" + arrayOfString[str2.length()] + str2 + "\n";
    paramJTextArea.append(str1);
    str2 = "" + get(CODE);
    str1 = "    Code Lines\t\t\t\t" + arrayOfString[str2.length()] + str2 + "\n";
    paramJTextArea.append(str1);
    str2 = "" + get(COMMENTS);
    str1 = "    Comment Lines\t\t\t" + arrayOfString[str2.length()] + str2 + "\n";
    paramJTextArea.append(str1);
    str2 = "" + get(WHITESPACE);
    str1 = "    Whitespace Lines\t\t\t" + arrayOfString[str2.length()] + str2 + "\n";
    paramJTextArea.append(str1);
    float f;
    if (get(COMMENTS) + get(WHITESPACE) > 0) {
      f = get(CODE) / (get(COMMENTS) + get(WHITESPACE));
    } else {
      f = 0.0F;
    }
    str2 = "" + localDecimalFormat.format(f);
    str1 = "    Code/(Comment+Whitespace) Ratio\t" + arrayOfString[str2.length()] + str2 + "\n";
    paramJTextArea.append(str1);
    if (get(COMMENTS) > 0) {
      f = get(CODE) / get(COMMENTS);
    } else {
      f = 0.0F;
    }
    str2 = "" + localDecimalFormat.format(f);
    str1 = "    Code/Comment Ratio\t\t\t" + arrayOfString[str2.length()] + str2 + "\n";
    paramJTextArea.append(str1);
    if (get(WHITESPACE) > 0) {
      f = get(CODE) / get(WHITESPACE);
    } else {
      f = 0.0F;
    }
    str2 = "" + localDecimalFormat.format(f);
    str1 = "    Code/Whitespace Ratio\t\t" + arrayOfString[str2.length()] + str2 + "\n";
    paramJTextArea.append(str1);
    if (get(TOTAL_LINES) > 0) {
      f = get(CODE) / get(TOTAL_LINES);
    } else {
      f = 0.0F;
    }
    str2 = "" + localDecimalFormat.format(f);
    str1 = "    Code/Total Lines Ratio\t\t" + arrayOfString[str2.length()] + str2 + "\n";
    paramJTextArea.append(str1);
    if (get(NUM_FILES) > 0) {
      i = get(CODE) / get(NUM_FILES);
    } else {
      i = 0;
    }
    str2 = "" + i;
    str1 = "    Code Lines Per File\t\t\t" + arrayOfString[str2.length()] + str2 + "\n";
    paramJTextArea.append(str1);
    if (get(NUM_FILES) > 0) {
      i = get(COMMENTS) / get(NUM_FILES);
    } else {
      i = 0;
    }
    str2 = "" + i;
    str1 = "    Comment Lines Per File\t\t" + arrayOfString[str2.length()] + str2 + "\n";
    paramJTextArea.append(str1);
    if (get(NUM_FILES) > 0) {
      i = get(WHITESPACE) / get(NUM_FILES);
    } else {
      i = 0;
    }
    str2 = "" + i;
    str1 = "    Whitespace Lines Per File\t\t" + arrayOfString[str2.length()] + str2 + "\n";
    paramJTextArea.append(str1);
  }
  
  public void writeToFile(FileWriter paramFileWriter, String paramString)
    throws IOException
  {
    String[] arrayOfString = { "        ", "       ", "      ", "     ", "    ", "   ", "  ", " " };
    DecimalFormat localDecimalFormat = new DecimalFormat("0.00");
    paramFileWriter.write("\n****************************************************\n");
    paramFileWriter.write("****************************************************\n");
    paramFileWriter.write(paramString + "\n\n");
    String str1 = "    Metric                             Value\n";
    paramFileWriter.write(str1);
    str1 = "    -------------------------------    --------\n";
    paramFileWriter.write(str1);
    String str2 = "" + get(NUM_FILES);
    str1 = "    Total Files                        " + arrayOfString[str2.length()] + str2 + "\n";
    paramFileWriter.write(str1);
    str2 = "" + get(TOTAL_LINES);
    str1 = "    Total Lines                        " + arrayOfString[str2.length()] + str2 + "\n";
    paramFileWriter.write(str1);
    int i;
    if (get(TOTAL_LINES) > 0) {
      i = get(LINE_LENGTH) / get(TOTAL_LINES);
    } else {
      i = 0;
    }
    str2 = "" + i;
    str1 = "    Avg Line Length                    " + arrayOfString[str2.length()] + str2 + "\n";
    paramFileWriter.write(str1);
    str2 = "" + get(CODE);
    str1 = "    Code Lines                         " + arrayOfString[str2.length()] + str2 + "\n";
    paramFileWriter.write(str1);
    str2 = "" + get(COMMENTS);
    str1 = "    Comment Lines                      " + arrayOfString[str2.length()] + str2 + "\n";
    paramFileWriter.write(str1);
    str2 = "" + get(WHITESPACE);
    str1 = "    Whitespace Lines                   " + arrayOfString[str2.length()] + str2 + "\n";
    paramFileWriter.write(str1);
    float f;
    if (get(COMMENTS) + get(WHITESPACE) > 0) {
      f = get(CODE) / (get(COMMENTS) + get(WHITESPACE));
    } else {
      f = 0.0F;
    }
    str2 = "" + localDecimalFormat.format(f);
    str1 = "    Code/(Comment+Whitespace) Ratio    " + arrayOfString[str2.length()] + str2 + "\n";
    paramFileWriter.write(str1);
    if (get(COMMENTS) > 0) {
      f = get(CODE) / get(COMMENTS);
    } else {
      f = 0.0F;
    }
    str2 = "" + localDecimalFormat.format(f);
    str1 = "    Code/Comment Ratio                 " + arrayOfString[str2.length()] + str2 + "\n";
    paramFileWriter.write(str1);
    if (get(WHITESPACE) > 0) {
      f = get(CODE) / get(WHITESPACE);
    } else {
      f = 0.0F;
    }
    str2 = "" + localDecimalFormat.format(f);
    str1 = "    Code/Whitespace Ratio              " + arrayOfString[str2.length()] + str2 + "\n";
    paramFileWriter.write(str1);
    if (get(TOTAL_LINES) > 0) {
      f = get(CODE) / get(TOTAL_LINES);
    } else {
      f = 0.0F;
    }
    str2 = "" + localDecimalFormat.format(f);
    str1 = "    Code/Total Lines Ratio             " + arrayOfString[str2.length()] + str2 + "\n";
    paramFileWriter.write(str1);
    if (get(NUM_FILES) > 0) {
      i = get(CODE) / get(NUM_FILES);
    } else {
      i = 0;
    }
    str2 = "" + i;
    str1 = "    Code Lines Per File                " + arrayOfString[str2.length()] + str2 + "\n";
    paramFileWriter.write(str1);
    if (get(NUM_FILES) > 0) {
      i = get(COMMENTS) / get(NUM_FILES);
    } else {
      i = 0;
    }
    str2 = "" + i;
    str1 = "    Comment Lines Per File             " + arrayOfString[str2.length()] + str2 + "\n";
    paramFileWriter.write(str1);
    if (get(NUM_FILES) > 0) {
      i = get(WHITESPACE) / get(NUM_FILES);
    } else {
      i = 0;
    }
    str2 = "" + i;
    str1 = "    Whitespace Lines Per File          " + arrayOfString[str2.length()] + str2 + "\n";
    paramFileWriter.write(str1);
  }
  
  public static void writeTextHdrToFile(FileWriter paramFileWriter, boolean paramBoolean)
    throws IOException
  {
    String str = "-------- ";
    String[] arrayOfString = { "Files    ", "Lines    ", "AVG Len  ", "Code     ", "Comments ", "White SP ", "Cd/Cm+WS ", "Cd/Cm    ", "Cd/WS    ", "% Code   ", "Cd/File  ", "Cm/File  ", "WS/File  ", "" };
    for (int i = 0; arrayOfString[i].length() != 0; i++) {
      if (paramBoolean) {
        paramFileWriter.write(str);
      } else {
        paramFileWriter.write(arrayOfString[i]);
      }
    }
  }
  
  public void writeTextToFile(FileWriter paramFileWriter)
    throws IOException
  {
    String[] arrayOfString = { "         ", "        ", "       ", "      ", "     ", "    ", "   ", "  ", " " };
    DecimalFormat localDecimalFormat = new DecimalFormat("0.00");
    String str2 = "" + get(NUM_FILES);
    String str1 = arrayOfString[str2.length()] + str2;
    paramFileWriter.write(str1);
    str2 = "" + get(TOTAL_LINES);
    str1 = arrayOfString[str2.length()] + str2;
    paramFileWriter.write(str1);
    int i;
    if (get(TOTAL_LINES) > 0) {
      i = get(LINE_LENGTH) / get(TOTAL_LINES);
    } else {
      i = 0;
    }
    str2 = "" + i;
    str1 = arrayOfString[str2.length()] + str2;
    paramFileWriter.write(str1);
    str2 = "" + get(CODE);
    str1 = arrayOfString[str2.length()] + str2;
    paramFileWriter.write(str1);
    str2 = "" + get(COMMENTS);
    str1 = arrayOfString[str2.length()] + str2;
    paramFileWriter.write(str1);
    str2 = "" + get(WHITESPACE);
    str1 = arrayOfString[str2.length()] + str2;
    paramFileWriter.write(str1);
    float f;
    if (get(COMMENTS) + get(WHITESPACE) > 0) {
      f = get(CODE) / (get(COMMENTS) + get(WHITESPACE));
    } else {
      f = 0.0F;
    }
    str2 = "" + localDecimalFormat.format(f);
    str1 = arrayOfString[str2.length()] + str2;
    paramFileWriter.write(str1);
    if (get(COMMENTS) > 0) {
      f = get(CODE) / get(COMMENTS);
    } else {
      f = 0.0F;
    }
    str2 = "" + localDecimalFormat.format(f);
    str1 = arrayOfString[str2.length()] + str2;
    paramFileWriter.write(str1);
    if (get(WHITESPACE) > 0) {
      f = get(CODE) / get(WHITESPACE);
    } else {
      f = 0.0F;
    }
    str2 = "" + localDecimalFormat.format(f);
    str1 = arrayOfString[str2.length()] + str2;
    paramFileWriter.write(str1);
    if (get(TOTAL_LINES) > 0) {
      f = get(CODE) / get(TOTAL_LINES);
    } else {
      f = 0.0F;
    }
    str2 = "" + localDecimalFormat.format(f);
    str1 = arrayOfString[str2.length()] + str2;
    paramFileWriter.write(str1);
    if (get(NUM_FILES) > 0) {
      i = get(CODE) / get(NUM_FILES);
    } else {
      i = 0;
    }
    str2 = "" + i;
    str1 = arrayOfString[str2.length()] + str2;
    paramFileWriter.write(str1);
    if (get(NUM_FILES) > 0) {
      i = get(COMMENTS) / get(NUM_FILES);
    } else {
      i = 0;
    }
    str2 = "" + i;
    str1 = arrayOfString[str2.length()] + str2;
    paramFileWriter.write(str1);
    if (get(NUM_FILES) > 0) {
      i = get(WHITESPACE) / get(NUM_FILES);
    } else {
      i = 0;
    }
    str2 = "" + i;
    str1 = arrayOfString[str2.length()] + str2;
    paramFileWriter.write(str1);
  }
  
  public static void writeHTMLHdrToFile(FileWriter paramFileWriter, String paramString)
    throws IOException
  {
    String[] arrayOfString = { "Total&nbsp;&nbsp;&nbsp;&nbsp; Files&nbsp;&nbsp;", "Total&nbsp;&nbsp; Lines&nbsp;&nbsp;&nbsp;", "AVG Line&nbsp;Len", "Total Code&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Lines&nbsp;&nbsp;", "Total Comment Lines&nbsp;&nbsp;", "Total WS&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Lines&nbsp;", "Cd/~Cd Ratio&nbsp;", "Cd/Cm&nbsp; &nbsp;Ratio&nbsp;", "Cd/WS&nbsp; &nbsp;Ratio&nbsp;", "%&nbsp;Code Lines", "Code&nbsp; Lines/File", "Comment Lines/File", "WS&nbsp;&nbsp; Lines/File", "" };
    paramFileWriter.write("        <tr>\r\n");
    paramFileWriter.write("          <td>" + paramString + "</td>\r\n");
    for (int i = 0; arrayOfString[i].length() != 0; i++) {
      paramFileWriter.write("          <td>" + arrayOfString[i] + "</td>\r\n");
    }
    paramFileWriter.write("        </tr>\r\n");
  }
  
  public void writeHTMLToFile(FileWriter paramFileWriter, String paramString)
    throws IOException
  {
    DecimalFormat localDecimalFormat = new DecimalFormat("0.00");
    paramFileWriter.write("        <tr>\r\n");
    paramFileWriter.write("          <td>" + paramString + "</td>\r\n");
    String str = "          <td>" + get(NUM_FILES) + "</td>\r\n";
    paramFileWriter.write(str);
    str = "          <td>" + get(TOTAL_LINES) + "</td>\r\n";
    paramFileWriter.write(str);
    int i;
    if (get(TOTAL_LINES) > 0) {
      i = get(LINE_LENGTH) / get(TOTAL_LINES);
    } else {
      i = 0;
    }
    str = "          <td>" + i + "</td>\r\n";
    paramFileWriter.write(str);
    str = "          <td>" + get(CODE) + "</td>\r\n";
    paramFileWriter.write(str);
    str = "          <td>" + get(COMMENTS) + "</td>\r\n";
    paramFileWriter.write(str);
    str = "          <td>" + get(WHITESPACE) + "</td>\r\n";
    paramFileWriter.write(str);
    float f;
    if (get(COMMENTS) + get(WHITESPACE) > 0) {
      f = get(CODE) / (get(COMMENTS) + get(WHITESPACE));
    } else {
      f = 0.0F;
    }
    str = "          <td>" + localDecimalFormat.format(f) + "</td>\r\n";
    paramFileWriter.write(str);
    if (get(COMMENTS) > 0) {
      f = get(CODE) / get(COMMENTS);
    } else {
      f = 0.0F;
    }
    str = "          <td>" + localDecimalFormat.format(f) + "</td>\r\n";
    paramFileWriter.write(str);
    if (get(WHITESPACE) > 0) {
      f = get(CODE) / get(WHITESPACE);
    } else {
      f = 0.0F;
    }
    str = "          <td>" + localDecimalFormat.format(f) + "</td>\r\n";
    paramFileWriter.write(str);
    if (get(TOTAL_LINES) > 0) {
      f = get(CODE) / get(TOTAL_LINES);
    } else {
      f = 0.0F;
    }
    str = "          <td>" + localDecimalFormat.format(f) + "</td>\r\n";
    paramFileWriter.write(str);
    if (get(NUM_FILES) > 0) {
      i = get(CODE) / get(NUM_FILES);
    } else {
      i = 0;
    }
    str = "          <td>" + i + "</td>\r\n";
    paramFileWriter.write(str);
    if (get(NUM_FILES) > 0) {
      i = get(COMMENTS) / get(NUM_FILES);
    } else {
      i = 0;
    }
    str = "          <td>" + i + "</td>\r\n";
    paramFileWriter.write(str);
    if (get(NUM_FILES) > 0) {
      i = get(WHITESPACE) / get(NUM_FILES);
    } else {
      i = 0;
    }
    str = "          <td>" + i + "</td>\r\n";
    paramFileWriter.write(str);
    paramFileWriter.write("        </tr>\r\n");
  }
  
  public static void writeCommaDelimHdrToFile(FileWriter paramFileWriter)
    throws IOException
  {
    String[] arrayOfString = { "Files,", "Lines,", "AVG Len,", "Code,", "Comments,", "White SP,", "Cd/Cm+WS,", "Cd/Cm,", "Cd/WS,", "% Code,", "Cd/File,", "Cm/File,", "WS/File,", "" };
    for (int i = 0; arrayOfString[i].length() != 0; i++) {
      paramFileWriter.write(arrayOfString[i]);
    }
  }
  
  public void writeCommaDelimToFile(FileWriter paramFileWriter)
    throws IOException
  {
    DecimalFormat localDecimalFormat = new DecimalFormat("0.00");
    String str = "" + get(NUM_FILES) + ",";
    paramFileWriter.write(str);
    str = "" + get(TOTAL_LINES) + ",";
    paramFileWriter.write(str);
    int i;
    if (get(TOTAL_LINES) > 0) {
      i = get(LINE_LENGTH) / get(TOTAL_LINES);
    } else {
      i = 0;
    }
    str = "" + i + ",";
    paramFileWriter.write(str);
    str = "" + get(CODE) + ",";
    paramFileWriter.write(str);
    str = "" + get(COMMENTS) + ",";
    paramFileWriter.write(str);
    str = "" + get(WHITESPACE) + ",";
    paramFileWriter.write(str);
    float f;
    if (get(COMMENTS) + get(WHITESPACE) > 0) {
      f = get(CODE) / (get(COMMENTS) + get(WHITESPACE));
    } else {
      f = 0.0F;
    }
    str = "" + localDecimalFormat.format(f) + ",";
    paramFileWriter.write(str);
    if (get(COMMENTS) > 0) {
      f = get(CODE) / get(COMMENTS);
    } else {
      f = 0.0F;
    }
    str = "" + localDecimalFormat.format(f) + ",";
    paramFileWriter.write(str);
    if (get(WHITESPACE) > 0) {
      f = get(CODE) / get(WHITESPACE);
    } else {
      f = 0.0F;
    }
    str = "" + localDecimalFormat.format(f) + ",";
    paramFileWriter.write(str);
    if (get(TOTAL_LINES) > 0) {
      f = get(CODE) / get(TOTAL_LINES);
    } else {
      f = 0.0F;
    }
    str = "" + localDecimalFormat.format(f) + ",";
    paramFileWriter.write(str);
    if (get(NUM_FILES) > 0) {
      i = get(CODE) / get(NUM_FILES);
    } else {
      i = 0;
    }
    str = "" + i + ",";
    paramFileWriter.write(str);
    if (get(NUM_FILES) > 0) {
      i = get(COMMENTS) / get(NUM_FILES);
    } else {
      i = 0;
    }
    str = "" + i + ",";
    paramFileWriter.write(str);
    if (get(NUM_FILES) > 0) {
      i = get(WHITESPACE) / get(NUM_FILES);
    } else {
      i = 0;
    }
    str = "" + i;
    paramFileWriter.write(str);
  }
}


/* Location:           C:\Users\Usuario\Downloads\CodeAnalyzer-0.7.0.jar
 * Qualified Name:     CodeAnalysis.Stats
 * JD-Core Version:    0.7.0.1
 */