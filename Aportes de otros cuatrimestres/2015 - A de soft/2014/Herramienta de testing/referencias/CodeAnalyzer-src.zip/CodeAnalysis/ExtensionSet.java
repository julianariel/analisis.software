package CodeAnalysis;

import java.io.File;
import java.util.Vector;

public class ExtensionSet
{
  private Vector extensions;
  private String name = "";
  
  public ExtensionSet(String paramString)
  {
    this.name = new String(paramString);
    this.extensions = new Vector();
  }
  
  public ExtensionSet(ExtensionSet paramExtensionSet)
  {
    this.name = new String(paramExtensionSet.toString());
    this.extensions = new Vector();
    for (int i = 0; i < paramExtensionSet.extensions.size(); i++)
    {
      Extension localExtension = new Extension((Extension)paramExtensionSet.extensions.elementAt(i));
      this.extensions.addElement(localExtension);
    }
  }
  
  public int getCount()
  {
    return this.extensions.size();
  }
  
  public Vector getExtensionVector()
  {
    return this.extensions;
  }
  
  public boolean equals(Object paramObject)
  {
    ExtensionSet localExtensionSet = (ExtensionSet)paramObject;
    if (localExtensionSet.toString().equals(this.name)) {
      return false;
    }
    return localExtensionSet.extensions.equals(this.extensions);
  }
  
  public String toString()
  {
    return new String(this.name);
  }
  
  public Extension getExtension(File paramFile)
  {
    int i = this.extensions.size();
    for (int j = 0; j < i; j++)
    {
      Extension localExtension = (Extension)this.extensions.elementAt(j);
      if (localExtension.matches(paramFile)) {
        return localExtension;
      }
    }
    return null;
  }
  
  public int getMatchingIndex(File paramFile)
  {
    int i = this.extensions.size();
    for (int j = 0; j < i; j++)
    {
      Extension localExtension = (Extension)this.extensions.elementAt(j);
      if (localExtension.matches(paramFile)) {
        return j;
      }
    }
    return -1;
  }
  
  public void add(Extension paramExtension)
  {
    if (!this.extensions.contains(paramExtension))
    {
      Extension localExtension = new Extension(paramExtension);
      this.extensions.addElement(localExtension);
    }
  }
  
  public String showContents()
  {
    String str = "";
    for (int i = 0; i < this.extensions.size(); i++)
    {
      Extension localExtension = (Extension)this.extensions.elementAt(i);
      str = str + localExtension.toString();
      str = str + " ";
    }
    return new String(str);
  }
  
  public void remove(Extension paramExtension)
  {
    this.extensions.remove(paramExtension);
  }
  
  public boolean fileMatches(File paramFile)
  {
    int i = this.extensions.size();
    for (int j = 0; j < i; j++) {
      if (((Extension)this.extensions.elementAt(j)).matches(paramFile)) {
        return true;
      }
    }
    return false;
  }
  
  public boolean fileMatches(String paramString)
  {
    int i = this.extensions.size();
    for (int j = 0; j < i; j++) {
      if (((Extension)this.extensions.elementAt(j)).matches(paramString)) {
        return true;
      }
    }
    return false;
  }
  
  public String getPropertyValue()
  {
    String str = this.name + ",";
    int i = this.extensions.size();
    for (int j = 0; j < i; j++)
    {
      Extension localExtension = (Extension)this.extensions.elementAt(j);
      str = str + localExtension.extension;
      str = str + ",";
      str = str + localExtension.comments.toString();
      if (j < i - 1) {
        str = str + ",";
      }
    }
    return new String(str);
  }
  
  public void setPropertyValue(String paramString, Vector paramVector)
  {
    this.extensions.clear();
    String[] arrayOfString = paramString.split(",");
    this.name = new String(arrayOfString[0]);
    for (int i = 1; i < arrayOfString.length; i += 2)
    {
      if (i + 1 > arrayOfString.length - 1) {
        return;
      }
      CommentSet localCommentSet = null;
      for (int j = 0; j < paramVector.size(); j++)
      {
        localCommentSet = (CommentSet)paramVector.elementAt(j);
        if (localCommentSet.toString().equals(arrayOfString[(i + 1)])) {
          break;
        }
        localCommentSet = null;
      }
      if (localCommentSet != null)
      {
        Extension localExtension = new Extension(arrayOfString[i], localCommentSet);
        this.extensions.addElement(localExtension);
      }
    }
  }
}


/* Location:           C:\Users\Usuario\Downloads\CodeAnalyzer-0.7.0.jar
 * Qualified Name:     CodeAnalysis.ExtensionSet
 * JD-Core Version:    0.7.0.1
 */