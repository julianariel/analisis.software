/*---------------------------------------------------------------------------

  FILENAME:
        ExtensionSet.java

  PURPOSE:
        Provide the Code Analyzer Extension Set object.

  REVISION HISTORY:
        Date            Engineer        Revision        Remarks
        03/13/2004      M.S. Teel       0               Original

  NOTES:
        

  LICENSE:
        Copyright (c) 2004, Mark S. Teel (mark@teel.ws)
  
        This source code is released for free distribution under the terms 
        of the GNU General Public License.
  
----------------------------------------------------------------------------*/

package CodeAnalysis;


import java.io.File;
import java.util.Vector;

/**
 *
 * @author  mteel
 */
public class ExtensionSet extends java.lang.Object
{
    private Vector  extensions;
    private String  name = "";
    
    
    /** Creates a new instance of ExtensionSet */
    public ExtensionSet (String newname)
    {
        name = new String (newname);
        extensions = new Vector ();
    }
    
    // Creates a new instance of CommentSet from an existing instance
    public ExtensionSet (ExtensionSet set)
    {
        name = new String (set.toString ());
        extensions = new Vector ();
        for (int i = 0; i < set.extensions.size (); i ++)
        {
            Extension temp = new Extension ((Extension)set.extensions.elementAt (i));
            extensions.addElement (temp);
        }
    }
    
    public int getCount ()
    {
        return extensions.size ();
    }
    
    public Vector getExtensionVector ()
    {
        return extensions;
    }
    
    public boolean equals (Object obj)
    {
        ExtensionSet  temp = (ExtensionSet)obj;
        
        if (temp.toString ().equals (name))
            return false;
        
        if (!temp.extensions.equals(extensions))
            return false;
        
        return true;
    }
    
    public String toString ()
    {
        return new String (name);
    }
    
    public Extension getExtension (File file)
    {
        int     len = extensions.size ();
        
        for (int i = 0; i < len; i ++)
        {
            Extension temp = (Extension)extensions.elementAt(i);
            if (temp.matches (file))
                return temp;
        }
        
        return null;
    }
    
    public int getMatchingIndex (File file)
    {
        int     len = extensions.size ();
        
        for (int i = 0; i < len; i ++)
        {
            Extension temp = (Extension)extensions.elementAt(i);
            if (temp.matches (file))
                return i;
        }
        
        return -1;
    }
    
    public void add (Extension newExt)
    {
        if (!extensions.contains (newExt))
        {
            Extension next = new Extension (newExt);
            extensions.addElement (next);
        }
    }
    
    public String showContents ()
    {
        String      retVal = "";
        
        for (int i = 0; i < extensions.size (); i ++)
        {
            Extension temp = (Extension)extensions.elementAt (i);
            retVal += temp.toString ();
            retVal += " ";
        }
        
        return new String (retVal);
    }
    
    public void remove (Extension oldExt)
    {
        extensions.remove (oldExt);
    }
    
    public boolean fileMatches (File file)
    {
        int     len = extensions.size ();
        
        for (int i = 0; i < len; i ++)
        {
            if (((Extension)extensions.elementAt(i)).matches (file))
                return true;
        }
        
        return false;
    }
    
    public boolean fileMatches (String file)
    {
        int     len = extensions.size ();
        
        for (int i = 0; i < len; i ++)
        {
            if (((Extension)extensions.elementAt(i)).matches (file))
                return true;
        }
        
        return false;
    }
    
    public String getPropertyValue ()
    {
        String      retVal = name + ",";
        int         len = extensions.size ();
        
        for (int i = 0; i < len; i ++)
        {
            Extension ext = (Extension)extensions.elementAt(i);
            retVal += ext.extension;
            retVal += ",";
            retVal += ext.comments.toString ();
            if (i < len-1)
                retVal += ",";            
        }
        
        return new String (retVal);
    }
    
    public void setPropertyValue (String value, Vector commSets)
    {
        extensions.clear ();
        String [] exts = value.split (",");

        name = new String (exts[0]);
        for (int i = 1; i < exts.length; i += 2)
        {
            if ((i + 1) > (exts.length - 1))
                return;
            
            CommentSet tempset = null;
            for (int j = 0; j < commSets.size (); j ++)
            {
                tempset = (CommentSet)commSets.elementAt(j);
                if (tempset.toString ().equals (exts[i+1]))
                    break;
                else
                    tempset = null;
            }
            
            if (tempset == null)
                continue;
            
            Extension temp = new Extension (exts[i], tempset);
            extensions.addElement (temp);
        }
    }
}
