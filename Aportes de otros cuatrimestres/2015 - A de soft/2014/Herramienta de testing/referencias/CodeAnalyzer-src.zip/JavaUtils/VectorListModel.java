package JavaUtils;

import java.util.Vector;
import javax.swing.AbstractListModel;

public class VectorListModel
  extends AbstractListModel
{
  private Vector vlist = null;
  
  public int getSize()
  {
    return this.vlist.size();
  }
  
  public int size()
  {
    return this.vlist.size();
  }
  
  public Object getElementAt(int paramInt)
  {
    return this.vlist.elementAt(paramInt);
  }
  
  public Object elementAt(int paramInt)
  {
    return this.vlist.elementAt(paramInt);
  }
  
  public boolean remove(Object paramObject)
  {
    return this.vlist.remove(paramObject);
  }
  
  public Object remove(int paramInt)
  {
    return this.vlist.remove(paramInt);
  }
  
  public void clear()
  {
    this.vlist.clear();
  }
  
  public void add(int paramInt, Object paramObject)
  {
    this.vlist.add(paramInt, paramObject);
  }
  
  public boolean add(Object paramObject)
  {
    return this.vlist.add(paramObject);
  }
  
  public boolean contains(Object paramObject)
  {
    return this.vlist.contains(paramObject);
  }
  
  public void fireContentsChanged()
  {
    super.fireContentsChanged(this, 0, this.vlist.size());
  }
}


/* Location:           C:\Users\Usuario\Downloads\CodeAnalyzer-0.7.0.jar
 * Qualified Name:     JavaUtils.VectorListModel
 * JD-Core Version:    0.7.0.1
 */