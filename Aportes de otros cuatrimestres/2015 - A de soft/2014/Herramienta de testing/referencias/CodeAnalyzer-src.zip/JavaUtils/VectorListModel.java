/*---------------------------------------------------------------------------

  FILENAME:
        VectorListModel.java

  PURPOSE:
        Provide the Code Analyzer vector list model.

  REVISION HISTORY:
        Date            Engineer        Revision        Remarks
        03/13/2004      M.S. Teel       0               Original

  NOTES:
        

  LICENSE:
        Copyright (c) 2004, Mark S. Teel (mark@teel.ws)
  
        This source code is released for free distribution under the terms 
        of the GNU General Public License.
  
----------------------------------------------------------------------------*/

package JavaUtils;


import javax.swing.*;
import java.io.*;
import java.util.*;

/**
 *
 * @author  mteel
 */
public class VectorListModel extends AbstractListModel
{
    
    private Vector vlist = null;
    
    
    /** Creates a new instance of VectorListModel */
    public VectorListModel ()
    {
        vlist = new Vector ();
    }
    
    public int getSize ()
    {
        return vlist.size ();
    }
    
    public int size ()
    {
        return vlist.size ();
    }
    
    public Object getElementAt (int index)
    {
        return vlist.elementAt(index);
    }
    
    public Object elementAt (int index)
    {
        return vlist.elementAt(index);
    }
    
    public boolean remove (Object obj)
    {
        return vlist.remove (obj);
    }
    
    public Object remove (int index)
    {
        return vlist.remove (index);
    }
    
    public void clear ()
    {
        vlist.clear ();
    }
    
    public void add (int index, Object obj)
    {
        vlist.add (index, obj);
    }
    
    public boolean add (Object obj)
    {
        return vlist.add (obj);
    }
    
    public boolean contains (Object obj)
    {
        return vlist.contains (obj);
    }
    
    public void fireContentsChanged ()
    {
        super.fireContentsChanged (this, 0, vlist.size ());
    }
}
