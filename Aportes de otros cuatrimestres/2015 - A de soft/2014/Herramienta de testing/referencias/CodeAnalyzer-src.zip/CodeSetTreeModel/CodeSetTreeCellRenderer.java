/*---------------------------------------------------------------------------

  FILENAME:
        CodeSetTreeCellRenderer.java

  PURPOSE:
        Provide the Code Analyzer tree cell renderer object.

  REVISION HISTORY:
        Date            Engineer        Revision        Remarks
        03/13/2004      M.S. Teel       0               Original

  NOTES:
        

  LICENSE:
        Copyright (c) 2004, Mark S. Teel (mark@teel.ws)
  
        This source code is released for free distribution under the terms 
        of the GNU General Public License.
  
----------------------------------------------------------------------------*/

package CodeSetTreeModel;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTree;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.DefaultMutableTreeNode;
import java.awt.Component;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.net.URL;

public class CodeSetTreeCellRenderer extends JLabel implements TreeCellRenderer
{
    static protected Font             defaultFont;

    // Icon to use for the root
    static protected ImageIcon        rootIcon;
    // Icon to use for the root with stats
    static protected ImageIcon        rootIconStats;
    // Icon to use when the item is a leaf and included
    static protected ImageIcon        includedLeafIcon;
    // Icon to use when the item is a leaf and included with stats
    static protected ImageIcon        includedStatsLeafIcon;
    // Icon to use when the item is a leaf and NOT included
    static protected ImageIcon        notIncludedLeafIcon;
    // Icon to use when the item is a branch and included
    static protected ImageIcon        includedBranchIcon;
    // Icon to use when the item is a branch and included with stats
    static protected ImageIcon        includedStatsBranchIcon;
    // Icon to use when the item is a branch and NOT included
    static protected ImageIcon        notIncludedBranchIcon;

    /** Color to use for the background when selected. */
    static protected final Color SelBGColor = Color.lightGray;

    /** Returns an ImageIcon, or null if the path was invalid. */
    protected static ImageIcon createImageIcon (String path) 
    {
        java.net.URL imgURL = CodeSetTreeCellRenderer.class.getResource(path);
        if (imgURL != null) 
        {
            return new ImageIcon (imgURL);
        } 
        else 
        {
            System.err.println ("Couldn't find file: " + path);
            return null;
        }
    }
    

    static
    {
	try {
	    defaultFont = new Font("SansSerif", 0, 11);
	} catch (Exception e) {}
    
    rootIcon = createImageIcon ("/images/root16.png");
    rootIconStats = createImageIcon ("/images/root16-green.png");
    includedLeafIcon = createImageIcon ("/images/file16.png");
    includedStatsLeafIcon = createImageIcon ("/images/file16-green.png");
    notIncludedLeafIcon = createImageIcon ("/images/file16-red.png");
    includedBranchIcon = createImageIcon ("/images/folder16.png");
    includedStatsBranchIcon = createImageIcon ("/images/folder16-green.png");
    notIncludedBranchIcon = createImageIcon ("/images/folder16-red.png");
    }

    // Whether or not the item that was last configured is selected
    protected boolean            selected;

    /**
      * This is messaged from JTree whenever it needs to get the size
      * of the component or it wants to draw it.
      * This attempts to set the font based on value, which will be
      * a TreeNode.
      */
    public Component getTreeCellRendererComponent
    (
        JTree       tree, 
        Object      value,
		boolean     selected, 
        boolean     expanded,
		boolean     leaf, 
        int         row,
		boolean     hasFocus
    )
    {
        Font        font;
        String      stringValue = tree.convertValueToText(value, 
                                                          selected,
                                                          expanded, 
                                                          leaf, 
                                                          row, 
                                                          hasFocus);

        // Set the text
        setText(stringValue);
        // Tooltips used by the tree
        setToolTipText(stringValue);

        // get the file node
        FileNode node = (FileNode)value;
    
        setFont(defaultFont);
	
        // Update the selected flag for the next paint
        this.selected = selected;

        // Set the image
        if (leaf)
        {
            if (!node.isIncluded ())
                setIcon (notIncludedLeafIcon);
            else
            {
                if (node.stats.get (node.stats.NUM_FILES) > 0)
                    setIcon (includedStatsLeafIcon);
                else
                    setIcon (includedLeafIcon);
            }
        }
        else if (!leaf && !node.isRoot ())
        {
            if (!node.isIncluded ())
                setIcon (notIncludedBranchIcon);
            else
            {
                if (node.stats.get (node.stats.NUM_FILES) > 0)
                    setIcon (includedStatsBranchIcon);
                else
                    setIcon (includedBranchIcon);
            }
        }
        else
        {
            if (node.stats.get (node.stats.NUM_FILES) > 0)
                setIcon (rootIconStats);
            else
                setIcon (rootIcon);
        }

        return this;
    }

    /**
      * paint is subclassed to draw the background correctly.  JLabel
      * currently does not allow backgrounds other than white, and it
      * will also fill behind the icon.  Something that isn't desirable.
      */
    public void paint(Graphics g) 
    {
        Color            bColor;
        Icon             currentI = getIcon();

        if(selected)
            bColor = SelBGColor;
        else if(getParent() != null)
            /* Pick background color up from parent (which will come from
               the JTree we're contained in). */
            bColor = getParent().getBackground();
        else
            bColor = getBackground();
        g.setColor(bColor);
        
        if (currentI != null && getText() != null) 
        {
            int offset = (currentI.getIconWidth() + getIconTextGap());

            if (getComponentOrientation().isLeftToRight()) 
            {
                g.fillRect(offset, 0, getWidth() - 1 - offset,
                           getHeight() - 1);
            }
            else 
            {
                g.fillRect(0, 0, getWidth() - 1 - offset, getHeight() - 1);
            }
        }
        else
            g.fillRect(0, 0, getWidth()-1, getHeight()-1);
	
        super.paint(g);
    }
}
