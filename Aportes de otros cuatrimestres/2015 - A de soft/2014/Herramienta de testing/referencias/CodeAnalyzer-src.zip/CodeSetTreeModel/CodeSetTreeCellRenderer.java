package CodeSetTreeModel;

import CodeAnalysis.Stats;
import java.awt.Color;
import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.io.PrintStream;
import java.net.URL;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTree;
import javax.swing.tree.TreeCellRenderer;

public class CodeSetTreeCellRenderer
  extends JLabel
  implements TreeCellRenderer
{
  protected static Font defaultFont;
  protected static ImageIcon rootIcon = createImageIcon("/images/root16.png");
  protected static ImageIcon rootIconStats = createImageIcon("/images/root16-green.png");
  protected static ImageIcon includedLeafIcon = createImageIcon("/images/file16.png");
  protected static ImageIcon includedStatsLeafIcon = createImageIcon("/images/file16-green.png");
  protected static ImageIcon notIncludedLeafIcon = createImageIcon("/images/file16-red.png");
  protected static ImageIcon includedBranchIcon = createImageIcon("/images/folder16.png");
  protected static ImageIcon includedStatsBranchIcon = createImageIcon("/images/folder16-green.png");
  protected static ImageIcon notIncludedBranchIcon = createImageIcon("/images/folder16-red.png");
  protected static final Color SelBGColor = Color.lightGray;
  protected boolean selected;
  
  protected static ImageIcon createImageIcon(String paramString)
  {
    URL localURL = CodeSetTreeCellRenderer.class.getResource(paramString);
    if (localURL != null) {
      return new ImageIcon(localURL);
    }
    System.err.println("Couldn't find file: " + paramString);
    return null;
  }
  
  public Component getTreeCellRendererComponent(JTree paramJTree, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt, boolean paramBoolean4)
  {
    String str = paramJTree.convertValueToText(paramObject, paramBoolean1, paramBoolean2, paramBoolean3, paramInt, paramBoolean4);
    setText(str);
    setToolTipText(str);
    FileNode localFileNode = (FileNode)paramObject;
    setFont(defaultFont);
    this.selected = paramBoolean1;
    if (paramBoolean3)
    {
      if (!localFileNode.isIncluded()) {
        setIcon(notIncludedLeafIcon);
      } else if (localFileNode.stats.get(Stats.NUM_FILES) > 0) {
        setIcon(includedStatsLeafIcon);
      } else {
        setIcon(includedLeafIcon);
      }
    }
    else if ((!paramBoolean3) && (!localFileNode.isRoot()))
    {
      if (!localFileNode.isIncluded()) {
        setIcon(notIncludedBranchIcon);
      } else if (localFileNode.stats.get(Stats.NUM_FILES) > 0) {
        setIcon(includedStatsBranchIcon);
      } else {
        setIcon(includedBranchIcon);
      }
    }
    else if (localFileNode.stats.get(Stats.NUM_FILES) > 0) {
      setIcon(rootIconStats);
    } else {
      setIcon(rootIcon);
    }
    return this;
  }
  
  public void paint(Graphics paramGraphics)
  {
    Icon localIcon = getIcon();
    Color localColor;
    if (this.selected) {
      localColor = SelBGColor;
    } else if (getParent() != null) {
      localColor = getParent().getBackground();
    } else {
      localColor = getBackground();
    }
    paramGraphics.setColor(localColor);
    if ((localIcon != null) && (getText() != null))
    {
      int i = localIcon.getIconWidth() + getIconTextGap();
      if (getComponentOrientation().isLeftToRight()) {
        paramGraphics.fillRect(i, 0, getWidth() - 1 - i, getHeight() - 1);
      } else {
        paramGraphics.fillRect(0, 0, getWidth() - 1 - i, getHeight() - 1);
      }
    }
    else
    {
      paramGraphics.fillRect(0, 0, getWidth() - 1, getHeight() - 1);
    }
    super.paint(paramGraphics);
  }
  
  static
  {
    try
    {
      defaultFont = new Font("SansSerif", 0, 11);
    }
    catch (Exception localException) {}
  }
}


/* Location:           C:\Users\Usuario\Downloads\CodeAnalyzer-0.7.0.jar
 * Qualified Name:     CodeSetTreeModel.CodeSetTreeCellRenderer
 * JD-Core Version:    0.7.0.1
 */