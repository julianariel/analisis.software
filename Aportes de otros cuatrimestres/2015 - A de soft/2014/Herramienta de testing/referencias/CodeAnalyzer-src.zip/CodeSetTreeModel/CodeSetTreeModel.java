package CodeSetTreeModel;

import java.util.Vector;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

public class CodeSetTreeModel
  implements TreeModel, CodeSetTreeTraversal
{
  protected FileNode root;
  private Vector treeModelListeners = new Vector();
  final int NODE_INCLUDE = 1;
  final int NODE_EXCLUDE = 2;
  final int NODE_FIND = 3;
  final int NODE_CHECK = 4;
  private int traverseType;
  private String childToFind;
  private FileNode nodeToFind;
  private boolean nodesChanged;
  private int checkNodesIncluded;
  
  public CodeSetTreeModel(FileNode paramFileNode)
  {
    this.root = paramFileNode;
  }
  
  public Object getRoot()
  {
    return this.root;
  }
  
  public boolean isLeaf(Object paramObject)
  {
    if (((FileNode)paramObject).isRoot()) {
      return false;
    }
    return ((FileNode)paramObject).isFile();
  }
  
  public int getChildCount(Object paramObject)
  {
    return ((FileNode)paramObject).getChildCount();
  }
  
  public Object getChild(Object paramObject, int paramInt)
  {
    return ((FileNode)paramObject).getChild(paramInt);
  }
  
  public int getIndexOfChild(Object paramObject1, Object paramObject2)
  {
    return ((FileNode)paramObject1).getChildIndex((FileNode)paramObject2);
  }
  
  public void fireTreeStructureChanged(TreePath paramTreePath)
  {
    int i = this.treeModelListeners.size();
    TreeModelEvent localTreeModelEvent = new TreeModelEvent(this, paramTreePath);
    for (int j = 0; j < i; j++) {
      ((TreeModelListener)this.treeModelListeners.elementAt(j)).treeStructureChanged(localTreeModelEvent);
    }
  }
  
  public void addTreeModelListener(TreeModelListener paramTreeModelListener)
  {
    this.treeModelListeners.addElement(paramTreeModelListener);
  }
  
  public void removeTreeModelListener(TreeModelListener paramTreeModelListener)
  {
    this.treeModelListeners.removeElement(paramTreeModelListener);
  }
  
  public void valueForPathChanged(TreePath paramTreePath, Object paramObject) {}
  
  public boolean executeForNode(FileNode paramFileNode)
  {
    switch (this.traverseType)
    {
    case 1: 
      if (!paramFileNode.isIncluded())
      {
        paramFileNode.include();
        this.nodesChanged = true;
      }
      break;
    case 2: 
      if (paramFileNode.isIncluded())
      {
        paramFileNode.exclude();
        this.nodesChanged = true;
      }
      break;
    case 3: 
      if (this.childToFind.equals(paramFileNode.getPath()))
      {
        this.nodeToFind = paramFileNode;
        return false;
      }
      break;
    case 4: 
      if (paramFileNode.isIncluded())
      {
        this.checkNodesIncluded += 1;
        if (!paramFileNode.isLeaf()) {
          return false;
        }
      }
      break;
    }
    return true;
  }
  
  public Object getChildNode(String paramString)
  {
    this.childToFind = paramString;
    this.nodeToFind = null;
    this.traverseType = 3;
    traverseDepthLast(this.root, this);
    return this.nodeToFind;
  }
  
  public boolean nodeInclude(FileNode paramFileNode)
  {
    this.nodesChanged = false;
    if (!paramFileNode.isIncluded())
    {
      paramFileNode.include();
      this.nodesChanged = true;
    }
    if (!paramFileNode.isLeaf())
    {
      this.traverseType = 1;
      traverseDepthLast(paramFileNode, this);
    }
    if (!this.nodesChanged) {
      return false;
    }
    for (FileNode localFileNode = paramFileNode.getParentNode(); (localFileNode != null) && (!localFileNode.isRoot()); localFileNode = localFileNode.getParentNode())
    {
      this.checkNodesIncluded = 0;
      this.traverseType = 4;
      traverseDepthLast(localFileNode, this);
      if (this.checkNodesIncluded > 0) {
        localFileNode.include();
      } else {
        localFileNode.exclude();
      }
    }
    return true;
  }
  
  public boolean nodeExclude(FileNode paramFileNode)
  {
    this.nodesChanged = false;
    if (paramFileNode.isIncluded())
    {
      paramFileNode.exclude();
      this.nodesChanged = true;
    }
    if (!paramFileNode.isLeaf())
    {
      this.traverseType = 2;
      traverseDepthLast(paramFileNode, this);
    }
    if (!this.nodesChanged) {
      return false;
    }
    for (FileNode localFileNode = paramFileNode.getParentNode(); (localFileNode != null) && (!localFileNode.isRoot()); localFileNode = localFileNode.getParentNode())
    {
      this.checkNodesIncluded = 0;
      this.traverseType = 4;
      traverseDepthLast(localFileNode, this);
      if (this.checkNodesIncluded > 0) {
        localFileNode.include();
      } else {
        localFileNode.exclude();
      }
    }
    return true;
  }
  
  public void traverseDepthFirst(Object paramObject, CodeSetTreeTraversal paramCodeSetTreeTraversal)
  {
    int i = getChildCount(paramObject);
    for (int j = 0; j < i; j++)
    {
      Object localObject = getChild(paramObject, j);
      if (!isLeaf(localObject)) {
        traverseDepthFirst(localObject, paramCodeSetTreeTraversal);
      }
      paramCodeSetTreeTraversal.executeForNode((FileNode)localObject);
    }
  }
  
  public void traverseDepthLast(Object paramObject, CodeSetTreeTraversal paramCodeSetTreeTraversal)
  {
    int i = getChildCount(paramObject);
    for (int j = 0; j < i; j++)
    {
      Object localObject = getChild(paramObject, j);
      boolean bool = paramCodeSetTreeTraversal.executeForNode((FileNode)localObject);
      if ((bool) && (!isLeaf(localObject))) {
        traverseDepthLast(localObject, paramCodeSetTreeTraversal);
      }
    }
  }
}


/* Location:           C:\Users\Usuario\Downloads\CodeAnalyzer-0.7.0.jar
 * Qualified Name:     CodeSetTreeModel.CodeSetTreeModel
 * JD-Core Version:    0.7.0.1
 */