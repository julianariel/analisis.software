/*---------------------------------------------------------------------------

  FILENAME:
        CodeSetTreeModel.java

  PURPOSE:
        Provide the Code Analyzer tree view model.

  REVISION HISTORY:
        Date            Engineer        Revision        Remarks
        03/13/2004      M.S. Teel       0               Original

  NOTES:
        

  LICENSE:
        Copyright (c) 2004, Mark S. Teel (mark@teel.ws)
  
        This source code is released for free distribution under the terms 
        of the GNU General Public License.
  
----------------------------------------------------------------------------*/

package CodeSetTreeModel;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.io.File;
import java.util.Vector;



public class CodeSetTreeModel implements TreeModel,CodeSetTreeTraversal
{
    protected FileNode  root;
    private Vector      treeModelListeners = new Vector();

    final int           NODE_INCLUDE        = 1;
    final int           NODE_EXCLUDE        = 2;
    final int           NODE_FIND           = 3;
    final int           NODE_CHECK          = 4;
    private int         traverseType;
    
    private String      childToFind;
    private FileNode    nodeToFind;
    
    private boolean     nodesChanged;
    
    private int         checkNodesIncluded;

    
    public CodeSetTreeModel (FileNode root)
    { 
        this.root = root; 
    }
    
    // The model knows how to return the root object of the tree
    public Object getRoot ()
    { 
        return root; 
    }
    
    // Tell JTree whether an object in the tree is a leaf
    public boolean isLeaf (Object node)
    {
        if (((FileNode)node).isRoot())
            return false;
        
        return ((FileNode)node).isFile (); 
    }
    
    // Tell JTree how many children a node has
    public int getChildCount (Object parent)
    {
        return ((FileNode)parent).getChildCount();
    }
    
    // Fetch any numbered child of a node for the JTree.
    // Our model returns File objects for all nodes in the tree.  The
    // JTree displays these by calling the File.toString() method.
    public Object getChild (Object parent, int index)
    {
        return (Object)(((FileNode)parent).getChild (index));
    }
    
    // Figure out a child's position in its parent node.
    public int getIndexOfChild (Object parent, Object child)
    {
        return ((FileNode)parent).getChildIndex ((FileNode)child);
    }
    
    // The only event raised by this model is TreeStructureChanged with the
    // root as path, i.e. the whole tree has changed
    public void fireTreeStructureChanged (TreePath changeNode) 
    {
        int len = treeModelListeners.size();
        TreeModelEvent e = new TreeModelEvent(this, changeNode);
                                              
        for (int i = 0; i < len; i++) 
        {
            ((TreeModelListener)treeModelListeners.elementAt(i)).
                                                treeStructureChanged(e);
        }
    }

    // Adds a listener for the TreeModelEvent posted after the tree changes
    public void addTreeModelListener(TreeModelListener l) 
    {
        treeModelListeners.addElement(l);
    }

    // Removes a listener previously added with addTreeModelListener()
    public void removeTreeModelListener(TreeModelListener l) 
    {
        treeModelListeners.removeElement(l);
    }

    // This method is invoked by the JTree only for editable trees.
    // This TreeModel does not allow editing, so we do not implement
    // this method.  The JTree editable property is false by default.
    public void valueForPathChanged (TreePath path, Object newvalue) {}
    

    // implemented for CodeSetTreeTraversal Interface:
    // return true if this node should be recursed, false if not
    public boolean executeForNode (FileNode node)
    {
        switch (traverseType)
        {
            case NODE_INCLUDE:
                if (!node.isIncluded ())
                {
                    node.include ();
                    nodesChanged = true;
                }
                break;
                
            case NODE_EXCLUDE:
                if (node.isIncluded ())
                {
                    node.exclude ();
                    nodesChanged = true;
                }
                break;
                
            case NODE_FIND:
                if (childToFind.equals(node.getPath ()))
                {
                    nodeToFind = node;
                    return false;
                }
                break;
                
            case NODE_CHECK:
                if (node.isIncluded ())
                {
                    checkNodesIncluded ++;
                    if (!node.isLeaf ())
                        return false;
                }
                break;
        }
        
        return true;
    }

    // find the node for the given path string, start at the root
    public Object getChildNode (String path)
    {
        childToFind = path;
        nodeToFind = null;
        traverseType = NODE_FIND;
        traverseDepthLast ((Object)root, this);
        
        return (Object)nodeToFind;
    }
    
    
    // include a node and deal with child nodes and parental node status changes
    // returns true if any nodes were affected, false otherwise
    public boolean nodeInclude (FileNode node)
    {
        nodesChanged = false;
        
        if (!node.isIncluded ())
        {
            node.include ();
            nodesChanged = true;
        }
        
        // if a branch, update the children
        if (!node.isLeaf ())
        {
            traverseType = NODE_INCLUDE;
            traverseDepthLast (node, this);
        }
        
        if (!nodesChanged)
            return false;
        
        // now walk up the parental ladder, checking statuses
        for (FileNode pnode = node.getParentNode (); 
             pnode != null && !pnode.isRoot(); 
             pnode = pnode.getParentNode ())
        {
            checkNodesIncluded = 0;
            traverseType = NODE_CHECK;
            traverseDepthLast (pnode, this);
            if (checkNodesIncluded > 0)
                pnode.include ();
            else
                pnode.exclude ();
        }
        
        return true;
    }
    
    
    // exclude a node and deal with child nodes and parental node status changes
    // returns true if any nodes were affected, false otherwise
    public boolean nodeExclude (FileNode node)
    {
        nodesChanged = false;
        
        if (node.isIncluded ())
        {
            node.exclude ();
            nodesChanged = true;
        }
        
        // if a branch, update the children
        if (!node.isLeaf ())
        {
            traverseType = NODE_EXCLUDE;
            traverseDepthLast (node, this);
        }
        
        if (!nodesChanged)
            return false;
        
        // now walk up the parental ladder, checking statuses
        for (FileNode pnode = node.getParentNode (); 
             pnode != null && !pnode.isRoot(); 
             pnode = pnode.getParentNode ())
        {
            checkNodesIncluded = 0;
            traverseType = NODE_CHECK;
            traverseDepthLast (pnode, this);
            if (checkNodesIncluded > 0)
                pnode.include ();
            else
                pnode.exclude ();
        }
        
        return true;
    }
    
    
   
    // this method traverses the tree depth first, executing the 
    // supplied method; we ignore the return value of the execute routine
    public void traverseDepthFirst (Object parent, CodeSetTreeTraversal execute)
    {
        int         count = getChildCount (parent);
        
        for (int i = 0; i < count; i ++) 
        {
            Object child = getChild (parent, i);

            // a bit of recursion here...
            if (!isLeaf (child))
            {
                traverseDepthFirst (child, execute); 
            }

            execute.executeForNode ((FileNode)child);
        }
    } 
    
    
   
    // this method traverses the tree, executing the supplied method
    public void traverseDepthLast (Object parent, CodeSetTreeTraversal execute)
    {
        boolean     doRecursion;
        int         count = getChildCount (parent);
        
        for (int i = 0; i < count; i ++) 
        {
            Object child = getChild (parent, i);
            doRecursion = execute.executeForNode ((FileNode)child);
            
            // a bit of recursion here...
            if (doRecursion && !isLeaf (child))
            {
                traverseDepthLast (child, execute); 
            }
        }
    } 
}
