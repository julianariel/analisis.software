package CodeSetTreeModel;

public abstract interface CodeSetTreeTraversal
{
  public abstract boolean executeForNode(FileNode paramFileNode);
}


/* Location:           C:\Users\Usuario\Downloads\CodeAnalyzer-0.7.0.jar
 * Qualified Name:     CodeSetTreeModel.CodeSetTreeTraversal
 * JD-Core Version:    0.7.0.1
 */