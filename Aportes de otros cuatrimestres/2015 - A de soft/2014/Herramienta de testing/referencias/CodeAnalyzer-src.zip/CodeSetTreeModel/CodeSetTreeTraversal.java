/*---------------------------------------------------------------------------

  FILENAME:
        CodeSetTreeTraversal.java

  PURPOSE:
        Provide the Code Analyzer tree traversal interface.

  REVISION HISTORY:
        Date            Engineer        Revision        Remarks
        03/13/2004      M.S. Teel       0               Original

  NOTES:
        

  LICENSE:
        Copyright (c) 2004, Mark S. Teel (mark@teel.ws)
  
        This source code is released for free distribution under the terms 
        of the GNU General Public License.
  
----------------------------------------------------------------------------*/

package CodeSetTreeModel;

/**
 *
 * @author  mteel
 */
//  ... define an interface for tree traversal processing
public interface CodeSetTreeTraversal 
{
    // return true if this node should be recursed, false if not
    public boolean executeForNode (FileNode node);
}

