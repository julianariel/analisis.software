/*---------------------------------------------------------------------------

  FILENAME:
        FileNode.java

  PURPOSE:
        Provide the Code Analyzer FileNode object.

  REVISION HISTORY:
        Date            Engineer        Revision        Remarks
        03/13/2004      M.S. Teel       0               Original

  NOTES:
        

  LICENSE:
        Copyright (c) 2004, Mark S. Teel (mark@teel.ws)
  
        This source code is released for free distribution under the terms 
        of the GNU General Public License.
  
----------------------------------------------------------------------------*/

package CodeSetTreeModel;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.io.*;
import java.util.*;
import JavaUtils.*;
import CodeAnalysis.*;

/**
 *
 * @author  mteel
 */
public class FileNode extends File
{
    private boolean         included = true;
    private boolean         isRoot = false;
    private boolean         isLevel1 = false;
    private String          rootName;
    private FileNode        parent = null;
    private FileNode []     children;
    public Stats            stats;
    public Stats []         extStats;
    public int              fileCount = 0;
    ExtensionSet            extensions = null;
    public int              myExtIndex;
    private TreePath        findPathStore;
    private JProgressBar    progressBar;
    public final int        PRINT_COMMA_DELIM   = 1;
    public final int        PRINT_HTML          = 2;
    public final int        PRINT_TEXT          = 3;
    
    final int               MAX_FILENAME_LEN    = 32;

    // the default constructor (only used for array instantiation)
    public FileNode ()
    {
        super (System.getProperty("user.home"));
    }
    
    // Creates a new "root" instance of FileNode
    public FileNode 
    (
    String          rName, 
    String []       fsRoots, 
    ExtensionSet    exts, 
    JProgressBar    bar
    )
    {
        super (System.getProperty("user.home"));
        stats = new Stats ();
        if (exts == null)
        {
            extensions = new ExtensionSet ("New");
            extStats = new Stats[0];
        }
        else
        {
            extensions = new ExtensionSet (exts);
            extStats = new Stats[exts.getCount()];
            for (int i = 0; i < extStats.length; i ++)
            {
                extStats[i] = new Stats ();
            }
        }
        
        isRoot = true;
        included = false;
        rootName = new String (rName);
        myExtIndex = -1;
        
        if (bar != null)
        {
            progressBar = bar;
            int max = bar.getMaximum ();
            if (((3*max)/4) <= bar.getValue ())
                bar.setMaximum (2*max);
            
            Runnable updateProgressBar = new Runnable ()
            {
                public void run () 
                { 
                    progressBar.setValue (progressBar.getValue () + 1); 
                }
            };
            SwingUtilities.invokeLater (updateProgressBar);
        }
        
        if (fsRoots == null)
            children = new FileNode[0];
        else
            children = new FileNode[fsRoots.length];
        
        for (int i = 0; i < children.length; i ++)
        {
            children[i] = new FileNode (this, fsRoots[i], true, extensions, bar);
        }
    }
    
    // Creates a new node instance of FileNode
    public FileNode 
    (
    FileNode        newparent, 
    String          path, 
    boolean         level1, 
    ExtensionSet    exts, 
    JProgressBar    bar
    )
    {
        super (path);
        parent = newparent;
        isLevel1 = level1;
        stats = new Stats ();
        extensions = new ExtensionSet (exts);

        if (bar != null)
        {
            progressBar = bar;
            int max = bar.getMaximum ();
            if (((3*max)/4) <= bar.getValue ())
                bar.setMaximum (2*max);
            
            Runnable updateProgressBar = new Runnable ()
            {
                public void run () 
                { 
                    progressBar.setValue (progressBar.getValue () + 1); 
                }
            };
            SwingUtilities.invokeLater (updateProgressBar);
        }
        
        String[] childlist = super.list ();
        if (childlist == null)
        {
            children = new FileNode[0];
            if (super.isFile ())
            {
                extStats = new Stats[0];
                myExtIndex = exts.getMatchingIndex (this);
            }
            else
            {
                extStats = new Stats[exts.getCount()];
                for (int i = 0; i < extStats.length; i ++)
                {
                    extStats[i] = new Stats ();
                }
                myExtIndex = -1;
            }
            return;
        }
        
        extStats = new Stats[exts.getCount()];
        for (int i = 0; i < extStats.length; i ++)
        {
            extStats[i] = new Stats ();
        }

        Vector temp = new Vector ();
        for (int i = 0; i < childlist.length; i ++)
        {
            String newpath = new String (path + "/" + childlist[i]);
            File tempfile = new File (newpath);
            
            if (tempfile.isFile () && !extensions.fileMatches (childlist[i]))
                continue;
            
            temp.add (newpath);
        }

        children = new FileNode[temp.size ()];
        for (int i = 0; i < temp.size (); i ++)
        {
            String newpath = (String)temp.elementAt (i);
            children[i] = new FileNode (this, newpath, false, extensions, bar);
        }
    }

    
//  ... some overloads
    public String toString ()
    {
        if (isRoot)
            return new String (rootName);
        else if (isLevel1)
            return new String (getPath());
        else
            return new String (getName());
    }
    
    public String [] list ()
    {
        if (children.length == 0)
            return null;
        
        String [] retArray = new String[children.length];
        for (int i = 0; i < children.length; i ++)
        {
            retArray[i] = children[i].toString();
        }
        return retArray;
    }
    
    public FileNode getParentNode ()
    {
        return parent;
    }
    
    public int getChildCount ()
    {
        return children.length;
    }
    
    public int getChildIndex (FileNode child)
    {
        for (int i = 0; i < children.length; i ++)
        {
            if (children[i] == child)
            {
                return i;
            }
        }
        
        return -1;
    }
    
    public FileNode getChild (int index)
    {
        if (children.length <= index)
            return null;
        
        return children[index];
    }
    
    public void addBranches (File [] branches)
    {
        int             count;
        FileNode []     newChildren;
        
        if (!isRoot ())
            return;
        
        count = branches.length + children.length;
        newChildren = new FileNode[count];
        
        for (int i = 0; i < children.length; i ++)
        {
            newChildren[i] = children[i];
        }
        for (int i = children.length; i < count; i ++)
        {
            newChildren[i] = 
                new FileNode (this, branches[i-children.length].getPath(), 
                              true, extensions, null);
        }
        
        children = newChildren;
    }

    public void removeBranch (String branch)
    {
        int             j = 0, count;
        FileNode []     newChildren;
        
        if (!isRoot ())
            return;
        
        newChildren = new FileNode[children.length - 1];
        
        for (int i = 0; i < children.length; i ++)
        {
            if (branch.equals(children[i].getPath()))
            {
                continue;
            }
            
            newChildren[j++] = children[i];
        }
        
        children = newChildren;
    }
    
    private TreePath searchPath (String path)
    {
        if (path.equals (getPath ()))
        {
            Vector parents = new Vector ();
            for (FileNode node = this; 
                 node != null; 
                 node = node.getParentNode ())
            {
                parents.insertElementAt (node, 0);
            }
            
            FileNode [] temp = new FileNode[parents.size ()];
            for (int i = 0; i < parents.size (); i ++)
            {
                temp[i] = (FileNode)parents.elementAt (i);
            }
            
            findPathStore = new TreePath (temp);
            return findPathStore;
        }
        
        // otherwise, recurse through my children
        for (int i = 0; i < children.length; i ++)
        {
            findPathStore = children[i].searchPath (path);
            if (findPathStore != null)
            {
                return findPathStore;
            }
        }
        
        return null;
    }
    
    public TreePath findPath (String path)
    {
        findPathStore = searchPath (path);
        
        if (findPathStore != null)
        {
            return findPathStore;
        }
        else
        {
            return null;
        }
    }

    public int getCount ()
    {
        if (isRoot () || isIncluded ())
        {
            fileCount = ((isRoot ()) ? 0 : 1);
        
            // recurse through my children
            for (int i = 0; i < children.length; i ++)
            {
                fileCount += children[i].getCount ();
            }

            return fileCount;
        }
        else
        {
            return 0;
        }
    }

    public void recursivePrintToFile 
    (
        FileWriter  file, 
        int         printMode, 
        boolean     foldersOnly
    )
    throws IOException
    {
        String      temp;
        
        // if stats have not been computed, bail out!
        if (stats.get(stats.NUM_FILES) == 0)
            return;
        
        // first print my stuff
        switch (printMode)
        {
            case PRINT_COMMA_DELIM:
                if (foldersOnly && isFile ())
                    break;
                
                // don't print empties
                if (!isFile () && getChildCount () == 0)
                    break;
                    
                if (isRoot ())
                    file.write (rootName + ",");
                else
                    file.write (getPath () + ",");
                
                stats.writeCommaDelimToFile (file);
                
                file.write ("\r\n");
                break;
                
            case PRINT_HTML:
                if (foldersOnly && isFile ())
                    break;
                
                if (isFile ())
                {
                    if (getName().length () > MAX_FILENAME_LEN)
                        temp = getName().substring (0, MAX_FILENAME_LEN);
                    else
                        temp = getName ();
                }
                else
                {
                    // don't print empties
                    if (getChildCount () == 0 || 
                        stats.get(stats.NUM_FILES) == 0)
                        break;
                    
                    if (isRoot ())
                        temp = rootName;
                    else
                        temp = getPath ();
                    
                    file.write ("          <td bgcolor=\42#C6C6FF\42 colspan=\4214\42>" + temp + "</td>\r\n");
                    temp = "-Cumulative-";
                }
                
                stats.writeHTMLToFile (file, temp);
                break;
                
            case PRINT_TEXT:
                if (foldersOnly && isFile ())
                    break;
                
                if (isFile ())
                {
                    if (getName().length () > MAX_FILENAME_LEN)
                        temp = getName().substring (0, MAX_FILENAME_LEN);
                    else
                        temp = getName ();
                    for (int i = temp.length(); i < MAX_FILENAME_LEN; i ++)
                    {
                        temp += " ";
                    }
                    file.write (temp + "  ");
                }
                else
                {
                    // don't print empties
                    if (getChildCount () == 0 || 
                        stats.get(stats.NUM_FILES) == 0)
                        break;
                    
                    if (isRoot ())
                        temp = rootName;
                    else
                        temp = getPath ();
                    file.write ("\r\n" + temp + "\r\n");
                    for (int i = 0; i < MAX_FILENAME_LEN; i ++)
                    {
                        file.write ("-");
                    }
                    file.write ("  ");
                }
                
                stats.writeTextToFile (file);
                file.write ("\r\n");
                break;
                
            default:
                return;
        }
       
        // then recurse through my children
        for (int i = 0; i < children.length; i ++)
        {
            children[i].recursivePrintToFile (file, printMode, foldersOnly);
        }

        return;
    }

    public void rename (String newName)
    {
        if (!isRoot)
            return;
        
        rootName = newName;
    }
    
    public void include ()
    {
        if (!isRoot)
            included = true;
    }
    
    public void exclude ()
    {
        included = false;
    }
    
    public boolean isIncluded ()
    {
        return included;
    }

    public boolean isRoot ()
    {
        return isRoot;
    }

    public boolean isLevel1 ()
    {
        return isLevel1;
    }

    public boolean isLeaf ()
    {
        return super.isFile ();
    }
}
