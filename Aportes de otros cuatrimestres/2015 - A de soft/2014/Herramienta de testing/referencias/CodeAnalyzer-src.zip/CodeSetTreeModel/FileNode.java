package CodeSetTreeModel;

import CodeAnalysis.ExtensionSet;
import CodeAnalysis.Stats;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;
import javax.swing.JProgressBar;
import javax.swing.SwingUtilities;
import javax.swing.tree.TreePath;

public class FileNode
  extends File
{
  private boolean included = true;
  private boolean isRoot = false;
  private boolean isLevel1 = false;
  private String rootName;
  private FileNode parent = null;
  private FileNode[] children;
  public Stats stats;
  public Stats[] extStats;
  public int fileCount = 0;
  ExtensionSet extensions = null;
  public int myExtIndex;
  private TreePath findPathStore;
  private JProgressBar progressBar;
  public final int PRINT_COMMA_DELIM = 1;
  public final int PRINT_HTML = 2;
  public final int PRINT_TEXT = 3;
  final int MAX_FILENAME_LEN = 32;
  
  public FileNode()
  {
    super(System.getProperty("user.home"));
  }
  
  public FileNode(String paramString, String[] paramArrayOfString, ExtensionSet paramExtensionSet, JProgressBar paramJProgressBar)
  {
    super(System.getProperty("user.home"));
    this.stats = new Stats();
    if (paramExtensionSet == null)
    {
      this.extensions = new ExtensionSet("New");
      this.extStats = new Stats[0];
    }
    else
    {
      this.extensions = new ExtensionSet(paramExtensionSet);
      this.extStats = new Stats[paramExtensionSet.getCount()];
      for (i = 0; i < this.extStats.length; i++) {
        this.extStats[i] = new Stats();
      }
    }
    this.isRoot = true;
    this.included = false;
    this.rootName = new String(paramString);
    this.myExtIndex = -1;
    if (paramJProgressBar != null)
    {
      this.progressBar = paramJProgressBar;
      i = paramJProgressBar.getMaximum();
      if (3 * i / 4 <= paramJProgressBar.getValue()) {
        paramJProgressBar.setMaximum(2 * i);
      }
      Runnable local1 = new Runnable()
      {
        public void run()
        {
          FileNode.this.progressBar.setValue(FileNode.this.progressBar.getValue() + 1);
        }
      };
      SwingUtilities.invokeLater(local1);
    }
    if (paramArrayOfString == null) {
      this.children = new FileNode[0];
    } else {
      this.children = new FileNode[paramArrayOfString.length];
    }
    for (int i = 0; i < this.children.length; i++) {
      this.children[i] = new FileNode(this, paramArrayOfString[i], true, this.extensions, paramJProgressBar);
    }
  }
  
  public FileNode(FileNode paramFileNode, String paramString, boolean paramBoolean, ExtensionSet paramExtensionSet, JProgressBar paramJProgressBar)
  {
    super(paramString);
    this.parent = paramFileNode;
    this.isLevel1 = paramBoolean;
    this.stats = new Stats();
    this.extensions = new ExtensionSet(paramExtensionSet);
    if (paramJProgressBar != null)
    {
      this.progressBar = paramJProgressBar;
      int i = paramJProgressBar.getMaximum();
      if (3 * i / 4 <= paramJProgressBar.getValue()) {
        paramJProgressBar.setMaximum(2 * i);
      }
      Runnable local2 = new Runnable()
      {
        public void run()
        {
          FileNode.this.progressBar.setValue(FileNode.this.progressBar.getValue() + 1);
        }
      };
      SwingUtilities.invokeLater(local2);
    }
    String[] arrayOfString = super.list();
    if (arrayOfString == null)
    {
      this.children = new FileNode[0];
      if (super.isFile())
      {
        this.extStats = new Stats[0];
        this.myExtIndex = paramExtensionSet.getMatchingIndex(this);
      }
      else
      {
        this.extStats = new Stats[paramExtensionSet.getCount()];
        for (j = 0; j < this.extStats.length; j++) {
          this.extStats[j] = new Stats();
        }
        this.myExtIndex = -1;
      }
      return;
    }
    this.extStats = new Stats[paramExtensionSet.getCount()];
    for (int j = 0; j < this.extStats.length; j++) {
      this.extStats[j] = new Stats();
    }
    Vector localVector = new Vector();
    String str;
    for (int k = 0; k < arrayOfString.length; k++)
    {
      str = new String(paramString + "/" + arrayOfString[k]);
      File localFile = new File(str);
      if ((!localFile.isFile()) || (this.extensions.fileMatches(arrayOfString[k]))) {
        localVector.add(str);
      }
    }
    this.children = new FileNode[localVector.size()];
    for (k = 0; k < localVector.size(); k++)
    {
      str = (String)localVector.elementAt(k);
      this.children[k] = new FileNode(this, str, false, this.extensions, paramJProgressBar);
    }
  }
  
  public String toString()
  {
    if (this.isRoot) {
      return new String(this.rootName);
    }
    if (this.isLevel1) {
      return new String(getPath());
    }
    return new String(getName());
  }
  
  public String[] list()
  {
    if (this.children.length == 0) {
      return null;
    }
    String[] arrayOfString = new String[this.children.length];
    for (int i = 0; i < this.children.length; i++) {
      arrayOfString[i] = this.children[i].toString();
    }
    return arrayOfString;
  }
  
  public FileNode getParentNode()
  {
    return this.parent;
  }
  
  public int getChildCount()
  {
    return this.children.length;
  }
  
  public int getChildIndex(FileNode paramFileNode)
  {
    for (int i = 0; i < this.children.length; i++) {
      if (this.children[i] == paramFileNode) {
        return i;
      }
    }
    return -1;
  }
  
  public FileNode getChild(int paramInt)
  {
    if (this.children.length <= paramInt) {
      return null;
    }
    return this.children[paramInt];
  }
  
  public void addBranches(File[] paramArrayOfFile)
  {
    if (!isRoot()) {
      return;
    }
    int i = paramArrayOfFile.length + this.children.length;
    FileNode[] arrayOfFileNode = new FileNode[i];
    for (int j = 0; j < this.children.length; j++) {
      arrayOfFileNode[j] = this.children[j];
    }
    for (j = this.children.length; j < i; j++) {
      arrayOfFileNode[j] = new FileNode(this, paramArrayOfFile[(j - this.children.length)].getPath(), true, this.extensions, null);
    }
    this.children = arrayOfFileNode;
  }
  
  public void removeBranch(String paramString)
  {
    int i = 0;
    if (!isRoot()) {
      return;
    }
    FileNode[] arrayOfFileNode = new FileNode[this.children.length - 1];
    for (int j = 0; j < this.children.length; j++) {
      if (!paramString.equals(this.children[j].getPath())) {
        arrayOfFileNode[(i++)] = this.children[j];
      }
    }
    this.children = arrayOfFileNode;
  }
  
  private TreePath searchPath(String paramString)
  {
    if (paramString.equals(getPath()))
    {
      Vector localVector = new Vector();
      for (Object localObject = this; localObject != null; localObject = ((FileNode)localObject).getParentNode()) {
        localVector.insertElementAt(localObject, 0);
      }
      localObject = new FileNode[localVector.size()];
      for (int j = 0; j < localVector.size(); j++) {
        localObject[j] = ((FileNode)localVector.elementAt(j));
      }
      this.findPathStore = new TreePath((Object[])localObject);
      return this.findPathStore;
    }
    for (int i = 0; i < this.children.length; i++)
    {
      this.findPathStore = this.children[i].searchPath(paramString);
      if (this.findPathStore != null) {
        return this.findPathStore;
      }
    }
    return null;
  }
  
  public TreePath findPath(String paramString)
  {
    this.findPathStore = searchPath(paramString);
    if (this.findPathStore != null) {
      return this.findPathStore;
    }
    return null;
  }
  
  public int getCount()
  {
    if ((isRoot()) || (isIncluded()))
    {
      this.fileCount = (isRoot() ? 0 : 1);
      for (int i = 0; i < this.children.length; i++) {
        this.fileCount += this.children[i].getCount();
      }
      return this.fileCount;
    }
    return 0;
  }
  
  public void recursivePrintToFile(FileWriter paramFileWriter, int paramInt, boolean paramBoolean)
    throws IOException
  {
    if (this.stats.get(Stats.NUM_FILES) == 0) {
      return;
    }
    String str;
    switch (paramInt)
    {
    case 1: 
      if (((!paramBoolean) || (!isFile())) && ((isFile()) || (getChildCount() != 0)))
      {
        if (isRoot()) {
          paramFileWriter.write(this.rootName + ",");
        } else {
          paramFileWriter.write(getPath() + ",");
        }
        this.stats.writeCommaDelimToFile(paramFileWriter);
        paramFileWriter.write("\r\n");
      }
      break;
    case 2: 
      if ((!paramBoolean) || (!isFile()))
      {
        if (isFile())
        {
          if (getName().length() > 32) {
            str = getName().substring(0, 32);
          } else {
            str = getName();
          }
        }
        else
        {
          if ((getChildCount() == 0) || (this.stats.get(Stats.NUM_FILES) == 0)) {
            break;
          }
          if (isRoot()) {
            str = this.rootName;
          } else {
            str = getPath();
          }
          paramFileWriter.write("          <td bgcolor=\"#C6C6FF\" colspan=\"14\">" + str + "</td>\r\n");
          str = "-Cumulative-";
        }
        this.stats.writeHTMLToFile(paramFileWriter, str);
      }
      break;
    case 3: 
      if ((!paramBoolean) || (!isFile()))
      {
        if (isFile())
        {
          if (getName().length() > 32) {
            str = getName().substring(0, 32);
          } else {
            str = getName();
          }
          for (i = str.length(); i < 32; i++) {
            str = str + " ";
          }
          paramFileWriter.write(str + "  ");
        }
        else
        {
          if ((getChildCount() == 0) || (this.stats.get(Stats.NUM_FILES) == 0)) {
            break;
          }
          if (isRoot()) {
            str = this.rootName;
          } else {
            str = getPath();
          }
          paramFileWriter.write("\r\n" + str + "\r\n");
          for (i = 0; i < 32; i++) {
            paramFileWriter.write("-");
          }
          paramFileWriter.write("  ");
        }
        this.stats.writeTextToFile(paramFileWriter);
        paramFileWriter.write("\r\n");
      }
      break;
    default: 
      return;
    }
    for (int i = 0; i < this.children.length; i++) {
      this.children[i].recursivePrintToFile(paramFileWriter, paramInt, paramBoolean);
    }
  }
  
  public void rename(String paramString)
  {
    if (!this.isRoot) {
      return;
    }
    this.rootName = paramString;
  }
  
  public void include()
  {
    if (!this.isRoot) {
      this.included = true;
    }
  }
  
  public void exclude()
  {
    this.included = false;
  }
  
  public boolean isIncluded()
  {
    return this.included;
  }
  
  public boolean isRoot()
  {
    return this.isRoot;
  }
  
  public boolean isLevel1()
  {
    return this.isLevel1;
  }
  
  public boolean isLeaf()
  {
    return super.isFile();
  }
}


/* Location:           C:\Users\Usuario\Downloads\CodeAnalyzer-0.7.0.jar
 * Qualified Name:     CodeSetTreeModel.FileNode
 * JD-Core Version:    0.7.0.1
 */