package herramienta;

import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.stage.Stage;

/**
 * @author Grupo N�mero 6
 *
 */
public class HerramientaDeTestingJFX extends Application {

	public static void main(String[] args) {
		launch(args);
	}

	    public void start(Stage primaryStage) {
	        try {
	            Accordion page = (Accordion) FXMLLoader.load(HerramientaDeTestingJFX.class.getResource("HerramientaTesting.fxml"));
	            Scene scene = new Scene(page);
	            primaryStage.setScene(scene);
	            primaryStage.setTitle("Herramienta de testing - Grupo 6");
	            primaryStage.show();
	        } catch (Exception ex) {
	            Logger.getLogger(HerramientaDeTestingJFX.class.getName()).log(Level.SEVERE, null, ex);
	        }
	    }

}
