package herramienta;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FuncionesDeTesting {

	/**
	 * Valida que el archivo le�do sea formato Java.
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	public static boolean esArchivoJava(File file) {
		return file == null ? false : file.getName().endsWith(".java") ? true
				: false;
	}

	/**
	 * Lee un archivo f�sico y devuelve el contenido en memoria.
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	public static Resultado procesarArchivo(File file) {

		FileReader fr = null;
		BufferedReader br = null;
		Resultado resultado = new Resultado();

		try {

			fr = new FileReader(file);
			br = new BufferedReader(fr);

			String linea;
			long cantidadLineasCodigo = 0;
			long cantidadLineasCodigoComentadas = 0;

			while ((linea = br.readLine()) != null) {
				cantidadLineasCodigo++;
				
				if(esLineaComentada(linea))
					cantidadLineasCodigoComentadas++;
					
			}
			
			resultado.setCantidadLineasCodigo(cantidadLineasCodigo);
			resultado.setCantidadLineasCodigoComentadas(cantidadLineasCodigoComentadas);
			
			br.close();
			fr.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return resultado;
	}

	/**
	 * Indica si una l�nea de c�digo es comentada
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	public static boolean esLineaComentada(String linea) {
				
		if(linea == null)
			return false;
		
		linea = eliminarEspacios(linea);
		
		return linea.startsWith("/") || linea.endsWith("/") || linea.startsWith("*") ;
	}
	
	/**
	 * Elimina los espacios en blanco de una l�nea
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	public static String eliminarEspacios(String linea) {
		return linea.replace(" ","");
	}
	
	/**
	 * Cuenta la cantidad de l�neas de c�digo comentadas de un archivo fuente.
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	public static long contarLineasDeCodigoComentadas() {
		return 0;
	}

	/**
	 * Cuenta el porcentaje de l�neas de c�digo comentadas de un archivo fuente.
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	public static long calcularPorcentajeLineasDeCodigoComentadas() {
		return 0;
	}

	/**
	 * Calcula la Complejidad Ciclom�tica de un algoritmo.
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	public static long calcularComplejidadCiclom�tica() {
		return 0;
	}

	/**
	 * Calcula el Fan In de una funci�n.
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	public static long calcularFanIn() {
		return 0;
	}

	/**
	 * Calcula el Fan Out de una funci�n.
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	public static long calcularFanOut() {
		return 0;
	}

	/**
	 * Calcula la longitud de un c�digo seg�n el m�todo de Healsted.
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	public static long calcularHealstedLongitud() {
		return 0;
	}

	/**
	 * Calcula el vol�men de un c�digo seg�n el m�todo de Healsted.
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	public static long calcularHealstedVolumen() {
		return 0;
	}
}
