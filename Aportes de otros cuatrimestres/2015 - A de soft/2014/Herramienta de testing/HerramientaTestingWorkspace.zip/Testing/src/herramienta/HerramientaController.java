package herramienta;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.Initializable;
import javafx.scene.control.Button;



public class HerramientaController implements Initializable{

	public void initialize(URL arg0, ResourceBundle arg1) {
				
	}
	
	Button agregarButton;
	
	public void agregarButtonClick(){
//		System.out.println("Clickeado");
//		System.out.println("Clickeado2");
	}
	

}
