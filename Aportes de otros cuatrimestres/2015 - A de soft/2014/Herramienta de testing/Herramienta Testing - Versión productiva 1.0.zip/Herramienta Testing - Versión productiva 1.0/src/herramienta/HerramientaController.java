package herramienta;

import java.io.File;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.List;
import java.util.ResourceBundle;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class HerramientaController implements Initializable {

	@FXML
	TreeView<Archivo> arbolDirectorios = new TreeView<Archivo>();

	@FXML
	TreeView<Resultado> arbolMetodos = new TreeView<Resultado>();

	@FXML
	TextArea codigoFuenteTextArea = new TextArea();

	@FXML
	Text resultadoLineasTotales = new Text();
	
	@FXML
	Text resultadoLineasComentadas = new Text();
	
	@FXML
	Text resultadoPorcentajeLineasTotales = new Text();
	
	@FXML
	Text resultadoComplejidadCiclomatica = new Text();
	
	@FXML
	Text resultadoFanIn = new Text();
	
	@FXML
	Text resultadoFanOut = new Text();
	
	@FXML
	Text resultadoHealsteadLongitud = new Text();
	
	@FXML
	Text resultadoHealsteadVolumen = new Text();
	
	public void initialize(URL arg0, ResourceBundle arg1) {

	}

	Button agregarButton;

	public void agregarButtonClick() {

	}

	@FXML
	public void seleccionarDirectorio() {

		// Abro ventana de selecci�n de archivos.
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Seleccione un directorio o los archivos a analizar:");
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Archivos JAVA", "*.java"));

		// Bajo los archivos seleccionados a una lista.
		List<File> listaArchivosSeleccionados = fileChooser.showOpenMultipleDialog(new Stage());

		// Recorro la lista de archivos obtenidos, los bajo cada uno a un nodo y lleno el objeto �rbol de la vista.
		if (listaArchivosSeleccionados != null) {

			TreeItem<Archivo> directorioRaiz = new TreeItem<Archivo>();

			for (File file : listaArchivosSeleccionados) {
				Archivo archivo = new Archivo(file, file.getName());
				TreeItem<Archivo> item = new TreeItem<Archivo>(archivo);
				directorioRaiz.getChildren().add(item);
			}

			directorioRaiz.setExpanded(true);
			setearEventosSobreArchivo();
			arbolDirectorios.setRoot(directorioRaiz);
			arbolDirectorios.setShowRoot(false);
		}

	}

	/**
	 * Setea el comportamiento que habr� sobre cada item del �rbol de archivos.
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	private void setearEventosSobreArchivo() {

		arbolDirectorios.setOnMouseClicked(new EventHandler<MouseEvent>() {

			public void handle(MouseEvent mouseEvent) {
				
				if (mouseEvent.getClickCount() == 1) {

					TreeItem<Resultado> arbolMetodosRaiz = new TreeItem<Resultado>();
					TreeItem<Archivo> item = arbolDirectorios.getSelectionModel().getSelectedItem();
					
					List<Resultado> listaMetodos = FuncionesDeTesting.leerMetodos(item.getValue().getFile());

					for (Resultado metodo : listaMetodos) {
						TreeItem<Resultado> metodoItem = new TreeItem<Resultado>(metodo);
						arbolMetodosRaiz.getChildren().add(metodoItem);
					}

					setearEventosSobreM�todo();
					arbolMetodosRaiz.setExpanded(true);
					arbolMetodos.setRoot(arbolMetodosRaiz);
					arbolMetodos.setShowRoot(false);
				}
			}
		});
	}

	/**
	 * Setea el comportamiento que habr� sobre cada item del �rbol de m�todos.
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	private void setearEventosSobreM�todo() {

		arbolMetodos.setOnMouseClicked(new EventHandler<MouseEvent>() {

			public void handle(MouseEvent mouseEvent) {
				if (mouseEvent.getClickCount() == 1) {

					DecimalFormat df = new DecimalFormat("#.##");
					
					TreeItem<Resultado> item = arbolMetodos.getSelectionModel().getSelectedItem();
					codigoFuenteTextArea.setText(item.getValue().getCodigoMetodo());
					resultadoLineasTotales.setText(String.valueOf(item.getValue().getCantidadLineasCodigo()));
					resultadoLineasComentadas.setText(String.valueOf(item.getValue().getCantidadLineasCodigoComentadas()));
					resultadoPorcentajeLineasTotales.setText(df.format(item.getValue().getPorcentajeLineasCodigoComentadas()) + "%");
					resultadoComplejidadCiclomatica.setText(String.valueOf(item.getValue().getComplejidadCiclomatica()));
					resultadoFanIn.setText(String.valueOf(FuncionesDeTesting.calcularFanIn(item.getValue().getCodigoMetodo(), item.getValue().getNombreMetodo())));
					resultadoFanOut.setText(String.valueOf(FuncionesDeTesting.calcularFanOut(item.getValue().getNombreMetodo())));
					resultadoHealsteadLongitud.setText(String.valueOf(FuncionesDeTesting.getHalstedLongitud()));
					resultadoHealsteadVolumen.setText(df.format(FuncionesDeTesting.getHalstedVolumen()));

				}
			}
		});
	}
}
