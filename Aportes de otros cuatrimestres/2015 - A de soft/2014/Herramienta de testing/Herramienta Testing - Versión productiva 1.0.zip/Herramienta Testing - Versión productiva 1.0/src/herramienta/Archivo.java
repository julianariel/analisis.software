package herramienta;

import java.io.File;

/**
 * Pojo que se usa para almacenar los resultados del testeo.
 * 
 * @author Grupo 6
 *
 */
public class Archivo extends File{

	private static final long serialVersionUID = 1L;

	public Archivo(File arg0, String arg1) {
		super(arg0, arg1);
	}		

	public File getFile(){
		return this.getParentFile();
	}
	@Override
	public String toString() {
		return this.getName();
	}
}
