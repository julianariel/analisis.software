package herramienta;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

public class FuncionesDeTesting {

	/**
	 * Lee un archivo f�sico y devuelve los metodos que lo componen
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	private static Set<String> listaMetodos = new HashSet<String>();
	private static List<Resultado> listaResultados = new ArrayList<Resultado>();
	private static long halstedLongitud = 0;
	private static double halstedVolumen = 0;

	/**
	 * @param file
	 * @return
	 */
	public static List<Resultado> leerMetodos(File file) {

		listaMetodos.clear();
		listaResultados.clear();
		FileReader fr = null;
		BufferedReader br = null;
		// List<Resultado> listaResultados = new ArrayList<Resultado>();
		try {

			fr = new FileReader(file);
			br = new BufferedReader(fr);

			String linea;

			while ((linea = br.readLine()) != null) {

				List<String> listaMetodosLeidos = new ArrayList<String>();
				// Si es un m�todo, sigo leyendo el archivo dentro del if y
				// trabaj�ndolo hasta que sea fin de m�todo.
				if (esMetodo(linea)) {

					listaMetodos.add(Resultado.getNombreMetodo(linea));
					listaMetodosLeidos.add(Resultado.getNombreMetodo(linea));
					String cabeceraMetodo = linea.replace("{", "");
					// Este contador servir� para saber cuando empieza y termina
					// un m�todo.
					int contadorLlaves = 0;
					int contadorLineas = 0;
					int contadorComentarios = 0;
					int complejidadCiclomatica = 0;
					// boolean esComentarioMultiLinea = false;
					String codigo = linea + "\n";

					while (((linea = br.readLine()) != null)) {

						codigo += linea + "\n";
						contadorLineas++;
						// Cuento la cantidad de l�neas que son comentario
						if (linea.contains("/*")) {
							while (linea.contains("*"))
								contadorComentarios++;
						}
						// else if (esComentarioMultiLinea) {
						// contadorComentarios++;
						// }
						else if (linea.contains("//")) {
							contadorComentarios++;
						}

						else if (linea.contains("{")) {
							contadorLlaves++;
						} else if (linea.contains("}")) {
							contadorLlaves--;
						} else {

							// Inicio de c�lculo de Complejidad Ciclom�tica
							int contador = 0;
							int comentarioMultiLinea = 0;
							int indice = 0;

							// for (String linea : this.codigo) {
							if (linea.contains("/*")) {
								comentarioMultiLinea = 1;
								if (Pattern.matches(".*(if|while|switch).*(\\/\\*)", linea))
									contador++;
							}

							indice = 0;

							if (comentarioMultiLinea == 0) {
								if (Pattern.matches(".*(\\s*)if(\\s*)(\\(.*\\)).*", linea) && !Pattern.matches(".*(\\/\\/).*if.*", linea))
									contador++;

								if (Pattern.matches(".*(\\s*)while(\\s*)(\\(.*\\)).*", linea) && !Pattern.matches(".*(\\/\\/).*while.*", linea))
									contador++;

								if (Pattern.matches(".*(\\s*)switch(\\s*)(\\(.*\\)).*", linea) && !Pattern.matches(".*(\\/\\/).*switch.*", linea))
									contador++;

								if (Pattern.matches(".*(\\s*)for(\\s*)(\\(.*\\)).*", linea) && !Pattern.matches(".*(\\/\\/).*for.*", linea))
									contador++;

								indice = linea.indexOf("&&");
								while (indice != -1) {
									contador++;
									if (indice + 2 <= linea.length())
										indice += 2;
									if (linea.substring(indice).contains("&&")) {
										indice += linea.substring(indice).indexOf("&&");
									} else
										indice = -1;
								}

								indice = linea.indexOf("||");
								while (indice != -1) {
									contador++;
									if (indice + 2 <= linea.length())
										indice += 2;
									if (linea.substring(indice).contains("||")) {
										indice += linea.substring(indice).indexOf("||");
									} else
										indice = -1;
								}

							} else if (linea.contains("*/")) {
								comentarioMultiLinea = 0;
								if (Pattern.matches(".*(\\*\\/).*(if|while|switch).*", linea))
									contador++;
							}
							// }

							complejidadCiclomatica = contador + 1;
							// Fin de c�lculo de Complejidad Ciclom�tica

						}
						// Si el contador de llaves es -1, significa que termina
						// el m�todo.
						if (contadorLlaves == -1)
							break;

					}

					contadorLineas++;

					Resultado resultado = new Resultado(cabeceraMetodo, codigo);
					resultado.setCantidadLineasCodigo(Long.valueOf(contadorLineas));
					resultado.setCantidadLineasCodigoComentadas(contadorComentarios);
					resultado.setComplejidadCiclomatica(complejidadCiclomatica);

					if (contadorLineas > 0)
						resultado.setPorcentajeLineasCodigoComentadas(((float) contadorComentarios / contadorLineas)*100);

					listaResultados.add(resultado);

				}

			}

			calcularHalstead();
			
			br.close();
			fr.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return listaResultados;
	}

	/**
	 * Lee un archivo f�sico y devuelve el contenido en memoria.
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	// TODO: Borrar
	// public static Resultado procesarArchivo(File file) {
	//
	// FileReader fr = null;
	// BufferedReader br = null;
	// Resultado resultado = new Resultado();
	//
	// try {
	//
	// fr = new FileReader(file);
	// br = new BufferedReader(fr);
	//
	// String linea;
	// long cantidadLineasCodigo = 0;
	// long cantidadLineasCodigoComentadas = 0;
	//
	// while ((linea = br.readLine()) != null) {
	// cantidadLineasCodigo++;
	//
	// if(esLineaComentada(linea))
	// cantidadLineasCodigoComentadas++;
	//
	// }
	//
	// resultado.setCantidadLineasCodigo(cantidadLineasCodigo);
	// resultado.setCantidadLineasCodigoComentadas(cantidadLineasCodigoComentadas);
	//
	// br.close();
	// fr.close();
	//
	// } catch (FileNotFoundException e) {
	// e.printStackTrace();
	// } catch (IOException e) {
	// e.printStackTrace();
	// }
	//
	// return resultado;
	// }

	/**
	 * Indica si una l�nea recibida es m�todo
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	private static boolean esMetodo(String linea) {
		// TODO: Borrar
		// if (linea.equals(""))
		// return false;
		//
		// if (linea.startsWith("//"))
		// return false;
		//
		// if (linea.endsWith("}"))
		// return false;
		//
		// if (linea.contains("class"))
		// return false;

		if ((linea.contains("public") || linea.contains("private") || linea.contains("protected")) && linea.contains("("))
			return true;

		return false;
	}

	/**
	 * Indica si una l�nea de c�digo es comentada
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	public static boolean esLineaComentada(String linea) {

		if (linea == null)
			return false;

		linea = eliminarEspacios(linea);

		return linea.startsWith("/") || linea.endsWith("/") || linea.startsWith("*");
	}

	/**
	 * Elimina los espacios en blanco de una l�nea
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	public static String eliminarEspacios(String linea) {
		return linea.replace(" ", "");
	}

	/**
	 * Verifica si una cadena es una llamada a un m�todo.
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	public static boolean esLlamadaAMetodo(String linea) {
		if (linea.contains(".") && linea.contains("("))
			return true;
		return false;
	}

	// TODO: Borrar
	// /**
	// * Cuenta la cantidad de l�neas de c�digo comentadas de un archivo fuente.
	// *
	// * @author Grupo 6
	// *
	// * @return
	// */
	// public static long contarLineasDeCodigoComentadas() {
	//
	// if (linea.contains("/*")) {
	// comentarioMultiLinea = true;
	// contadorComentarios++;
	// } else if (comentarioMultiLinea) {
	// contadorComentarios++;
	// } else if (linea.contains("//")) {
	// contadorComentarios++;
	// }
	//
	// return 0;
	// }
	//
	// /**
	// * Cuenta el porcentaje de l�neas de c�digo comentadas de un archivo
	// fuente.
	// *
	// * @author Grupo 6
	// *
	// * @return
	// */
	// public static long calcularPorcentajeLineasDeCodigoComentadas() {
	// return 0;
	// }
	//
	// /**
	// * Calcula la Complejidad Ciclom�tica de un algoritmo.
	// *
	// * @author Grupo 6
	// *
	// * @return
	// */
	// private void calcularComplejidadCiclomatica() {
	//
	// }

	/**
	 * Calcula el Fan In de una funci�n.
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	public static long calcularFanIn(String codigo, String nombreMetodo) {

		int contadorLlamadas = 0;
		String[] lineasCodigo = codigo.split("\n");

		for (String linea : lineasCodigo)
			if (esLlamadaAMetodo(linea))
				contadorLlamadas++;

		return contadorLlamadas;
	}

	/**
	 * Calcula el Fan Out de una funci�n.
	 * 
	 * @author Grupo 6
	 * 
	 * @return
	 */
	public static long calcularFanOut(String metodo) {

		// List<String> metodosNoRepetidos = listaMetodos;
		long contador = 0;

		for (Resultado resultado : listaResultados) {

			String[] lineasCodigo = resultado.getCodigoMetodo().split("/n");

			for (String linea : lineasCodigo)
				if (linea.contains(metodo))
					contador++;

		}

		// long contador = 0;
		//
		// for (String metodoLeido : listaMetodos)
		// if (metodoLeido.equals(metodo))
		// contador++;
		//
		return contador;
	}

//	/**
//	 * Calcula la longitud de un c�digo seg�n el m�todo de Healsted.
//	 * 
//	 * @author Grupo 6
//	 * 
//	 * @return
//	 */
//	public static long calcularHealstedLongitud() {
//
//		return 0;
//	}

	private static void calcularHalstead() {
		ArrayList<String> operadores = new ArrayList<String>();
		ArrayList<String> operandos = new ArrayList<String>();
		HashSet<String> operadoresSinRepetidos;
		HashSet<String> operandosSinRepetidos = new HashSet<String>();
		// ArrayList<String> codigoSinCabecera = this.;

		// codigoSinCabecera.remove(0);
		// codigoSinCabecera.remove(codigoSinCabecera.size()-1);

		for (Resultado resultado : listaResultados) {

			String linea = resultado.getCodigoMetodo();
			// for(String linea : resultado.getCodigoMetodo()) {
			for (String cadena : linea.replace("(", " ( ").replace(")", " ) ").replace(",", " , ").split(" ")) {
				if (esOperador(cadena)) {
					operadores.add(cadena);
				} else {
					operandos.add(cadena);
				}
			}
			// }
		}

		operandos = limpiarOperandos(operandos);

		operadoresSinRepetidos = new HashSet<String>(operadores);
		operandosSinRepetidos = new HashSet<String>(operandos);

		int n1 = operadoresSinRepetidos.size();
		int N1 = operadores.size();
		int n2 = operandosSinRepetidos.size();
		int N2 = operandos.size();

		FuncionesDeTesting.setHalstedLongitud(N1 + N2);
		int halsteadVocabulario = n1 + n2;
		FuncionesDeTesting.setHalstedVolumen(FuncionesDeTesting.getHalstedLongitud() * log(halsteadVocabulario, 2));

		// if (n2 > 0) {
		// this.halsteadNivelDificultad = (n1 / 2.0) * (N2 / n2);
		// this.halsteadNivelPrograma = 1 / this.halsteadNivelDificultad;
		// this.halsteadEsfuerzo = this.halsteadVolumen *
		// this.halsteadNivelDificultad;
		// this.halsteadEntendimiento = this.halsteadEsfuerzo / 18.0;
		// }
	}

	/**
	 * @param operador
	 * @return
	 */
	private static boolean esOperador(String operador) {

		final String[] simbolos = { "auto", "extern", "register", "static", "typedef", "virtual", "mutable", "inline", "const", "friend", "volatile", "transient", "final", "break", "case",
				"continue", "default", "do", "if", "else", "enum", "for", "goto", "if", "new", "return", "asm", "operator", "private", "protected", "public", "sizeof", "struct", "switch", "union",
				"while", "this", "namespace", "using", "try", "catch", "throw", "throws", "finally", "strictfp", "instanceof", "interface", "extends", "implements", "abstract", "concrete",
				"const_cast", "static_cast", "dynamic_cast", "reinterpret_cast", "typeid", "template", "explicit", "true", "false", "typename", "!", "!=", "%", "%=", "&", "&&", "||", "&=", "(", ")",
				"{", "}", "[", "]", "*", "*=", "+", "++", "+=", ",", "-", "--", "-=->", ".", "...", "/", "/=", ":", "::", "<", "<<", "<<=", "<=", "=", "==", ">", ">=", ">>", ">>>", ">>=>>>=", "?",
				"^", "^=", "|", "|=", "~", ";", "=&", "#", "##", "~" };

		for (String simbolo : simbolos)
			if (simbolo.equals(operador))
				return true;

		return false;
	}

	/**
	 * @param operandos
	 * @return
	 */
	private static ArrayList<String> limpiarOperandos(ArrayList<String> operandos) {
		boolean esString = false;
		ArrayList<String> string = new ArrayList<String>();
		ArrayList<String> limpio = new ArrayList<String>();

		for (String operando : operandos) {
			if (operando.startsWith("\"") || operando.startsWith("\'")) {
				esString = true;
			}

			if (operando.endsWith("\"") || operando.endsWith("\'")) {
				string.add(operando);
				limpio.add(joinArrayString(string));
				string = new ArrayList<String>();
				esString = false;
			} else if (esString) {
				string.add(operando);
			} else if (!operando.equals("(") && !operando.equals(")") && !operando.equals(",")) {
				limpio.add(operando);
			}
		}

		return limpio;
	}

	/**
	 * @param a
	 * @return
	 */
	private static String joinArrayString(ArrayList<String> a) {
		String j = null;

		for (String s : a) {
			j += s + " ";
		}

		return j.substring(0, j.length() - 1);
	}

	/**
	 * @param x
	 * @param base
	 * @return
	 */
	private static double log(double x, int base) {
		return Math.log(x) / Math.log(base);
	}

	public static long getHalstedLongitud() {
		return halstedLongitud;
	}

	public static void setHalstedLongitud(long halstedLongitud) {
		FuncionesDeTesting.halstedLongitud = halstedLongitud;
	}

	public static double getHalstedVolumen() {
		return halstedVolumen;
	}

	public static void setHalstedVolumen(double halstedVolumen) {
		FuncionesDeTesting.halstedVolumen = halstedVolumen;
	}
}
