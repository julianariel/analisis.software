package herramienta;

/**
 * Pojo que se usa para almacenar los resultados del testeo.
 * 
 * @author Grupo 6
 *
 */
public class Resultado {

	private String cabeceraMetodo;
	private String nombreMetodo;
	private String codigoMetodo;
	private long cantidadLineasCodigo;
	private long cantidadLineasCodigoComentadas;
	private double porcentajeLineasCodigoComentadas;
	private long complejidadCiclomatica;
	private long fanIn;
	private long fanOut;
	private long healsteadLongitud;
	private long healsteadVolumen;
	
	public Resultado(String cabeceraMetodo, String codigoMetodo){
		this.cabeceraMetodo = cabeceraMetodo;
		this.codigoMetodo = codigoMetodo;
		this.nombreMetodo = getNombreMetodo(cabeceraMetodo);
		cantidadLineasCodigo = 0;
		cantidadLineasCodigoComentadas = 0;
		porcentajeLineasCodigoComentadas = 0;
		complejidadCiclomatica = 0;
		fanIn = 0;
		fanOut = 0;
		healsteadLongitud = 0;
		healsteadVolumen = 0;
	}
	
	public String getCabeceraMetodo() {
		return cabeceraMetodo;
	}

	public void setCabeceraMetodo(String cabeceraMetodo) {
		this.cabeceraMetodo = cabeceraMetodo;
	}
	
	public String getCodigoMetodo() {
		return codigoMetodo;
	}

	public void setCodigoMetodo(String codigoMetodo) {
		this.codigoMetodo = codigoMetodo;
	}

	public long getCantidadLineasCodigo() {
		return cantidadLineasCodigo;
	}
	public void setCantidadLineasCodigo(long cantidadLineasCodigo) {
		this.cantidadLineasCodigo = cantidadLineasCodigo;
	}
	public long getCantidadLineasCodigoComentadas() {
		return cantidadLineasCodigoComentadas;
	}
	public void setCantidadLineasCodigoComentadas(
			long cantidadLineasCodigoComentadas) {
		this.cantidadLineasCodigoComentadas = cantidadLineasCodigoComentadas;
	}
	public double getPorcentajeLineasCodigoComentadas() {
		return porcentajeLineasCodigoComentadas;
	}
	public void setPorcentajeLineasCodigoComentadas(double porcentajeLineasCodigoComentadas) {
		this.porcentajeLineasCodigoComentadas = porcentajeLineasCodigoComentadas;
	}
	public long getComplejidadCiclomatica() {
		return complejidadCiclomatica;
	}
	public void setComplejidadCiclomatica(long complejidadCiclomatica) {
		this.complejidadCiclomatica = complejidadCiclomatica;
	}
	public long getFanIn() {
		return fanIn;
	}
	public void setFanIn(long fanIn) {
		this.fanIn = fanIn;
	}
	public long getFanOut() {
		return fanOut;
	}
	public void setFanOut(long fanOut) {
		this.fanOut = fanOut;
	}
	public long getHealsteadLongitud() {
		return healsteadLongitud;
	}
	public void setHealsteadLongitud(long healsteadLongitud) {
		this.healsteadLongitud = healsteadLongitud;
	}
	public long getHealsteadVolumen() {
		return healsteadVolumen;
	}
	public void setHealsteadVolumen(long healsteadVolumen) {
		this.healsteadVolumen = healsteadVolumen;
	}
	public String getNombreMetodo() {
		return nombreMetodo;
	}
	public void setNombreMetodo(String nombreMetodo) {
		this.nombreMetodo = nombreMetodo;
	}
	
	public static String getNombreMetodo(String linea) {
        String anterior = "";
        String[] cabecera = linea.split(" ");
        
	    for (String elemento : cabecera) {
	    	elemento = elemento.trim();
	    	
	    	if (elemento.contains("(")) {
	    		if(elemento.substring(0, elemento.indexOf("(")).isEmpty())
	    			return anterior;
	    		else
	    			return elemento.substring(0, elemento.indexOf("("));
	    	}
	    	
	    	anterior = elemento;
	    }
	    
	    return null;
	}
	
	@Override
	public String toString() {
		return cabeceraMetodo;
	}
}
